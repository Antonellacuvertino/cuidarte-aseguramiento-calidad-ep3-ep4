# Informe final EP5 / EP6


Duoc UC
ISY1102: Seguridad y Calidad en el Desarrollo de Software
Encargo 3 · Evaluación Parcial 5 / Presentación EP6
Informe de seguridad y calidad en el desarrollo de software
Caso: Cuidarte+ · CreaLab SpA
Antonella Cuvertino · QA Lead / DevSecOps Engineer
Docente: LUIS MANUEL YAGI FIGUEROA
Sección: 02V
Carrera: Ingeniería Informática, Desarrollo de Software
Fecha de presentación: 17 de noviembre de 2026
Preparación documental: 17 de noviembre de 2026
CERTIFICADO CON RESERVAS · PRODUCCIÓN BLOQUEADA


## 1. Introducción

Entrega EP5 y defensa EP6 del 17 de noviembre de 2026. Se corrige la contradicción del antecedente: la página 12 declaraba casos proyectados y la página 23 informaba resultados. Ahora registro_maestro_ep5_20261117.json es la única fuente de estados: cada ejecución tiene caso, fecha UTC, obtenido, artefacto e incidencia. Los pendientes no generan conclusiones medidas.

Cuidarte+ (CreaLab SpA) gestiona exámenes, pacientes y documentos clínicos con React, Express y PostgreSQL. Este informe corresponde al Encargo 3 de ISY1102 y apoya la presentación EP6. Se prepara el 17 de noviembre de 2026 para la defensa del 17 de noviembre. El expediente de octubre se conserva como antecedente; esta entrega agrega la campaña comparativa fechada en los JSON FIN-01 a FIN-20.

Nueva campaña: versión original en API 4446 y base cuidarte_final_antes; versión con cambios en API 4447 y base cuidarte_final_despues. PostgreSQL publica 15444; la interfaz de práctica usa 3344. Ambas bases contienen únicamente datos sintéticos. Antes: {'total': 20, 'pass': 8, 'fail': 12, 'blocked': 0}. Después: {'total': 20, 'pass': 15, 'fail': 5, 'blocked': 0}. Las evidencias originales de ambas fases se conservan por separado; el intento inicial bloqueado por timeout se documenta sin contarlo como defecto del negocio.

Dictamen académico solicitado: CERTIFICADO CON RESERVAS. Decisión operativa: BLOQUEADO PARA PRODUCCIÓN. El rótulo no representa certificación oficial, cumplimiento legal integral ni autorización de uso clínico. El informe anterior mantenía no certificado. La nueva campaña acredita mejoras parciales mediante retests, pero persisten reservas que impiden levantar el bloqueo.

El alcance comprende revisión documental, lectura del código y análisis de evidencias locales. Incluye una nueva campaña de 20 pruebas HTTP e integración ejecutada con Node en dos versiones, antes y después de cambios; no se atribuye a Jest, Cypress, ZAP, JMeter ni Actions. Se diferencian resultados confirmados, riesgos de revisión estática, inconsistencias y controles propuestos.

docker-compose.yml declara frontend 3333→80, backend 4444→4000 y PostgreSQL ${PORT_POSTGRES:-15442}→5432. Las variables locales pueden modificar el puerto publicado. La evidencia QA usa API 4445 y base aislada 15443; la interfaz de práctica usa 3334. SonarQube se conserva por separado en 9000 y no forma parte de los tres servicios del Compose original. No se afirma que estos servicios estén actualmente encendidos.

PostgreSQL usa su protocolo, por lo que localhost:5432 no es una interfaz HTTP. En un contenedor localhost designa al propio contenedor; la API debe conectar a la base mediante el nombre de servicio y puerto interno. Separar red, volúmenes y datos sintéticos permite repetir las pruebas sin usar historias clínicas reales.

Los scripts locales de 02_DEMOSTRACION preparan QA y ejecutan cuatro pruebas: login correcto, login incorrecto, acceso entre pacientes y persistencia tras borrado. El último registro tiene 3 PASS y 1 FAIL, distinto del conjunto histórico de 12 verificaciones. No sumar ambas campañas como casos únicos. El arranque y las pruebas deben realizarse antes de grabar; no modificar las evidencias históricas para aparentar resultados actuales.

No se adjuntó la ERS completa en esta solicitud. Los identificadores RF/NFR se heredan de los antecedentes y necesitan ratificación contra la versión docente. No se declara cobertura del 100% de la ERS. La pauta EP5 presenta una referencia interna a Evaluación Parcial 3; se sigue su contenido y la instrucción posterior del docente: informe, diapositivas y video.

La actividad 01-10 indica medico/medico y admin/Admin. Se recrearon y verificaron exclusivamente en QA, con HTTP 200. La app del laboratorio está en 3344; 3333 es el entorno histórico y no se afirma haber verificado su acceso. Un modal de confirmación acredita interacción visual, pero no demuestra baja lógica: FIN-16 consulta la fila después del DELETE.

Ajuste | Antes / contexto | Corrección aplicada

Evidencia | Herramientas listadas como configuradas | Estado por herramienta y artefacto verificable.

SQLi / IDOR | Explotaciones afirmadas sin versión reproducible | No corroborar una SQLi inexistente; limitar el PASS al escenario probado.

Escalamiento | CSV dice éxito; JSON muestra 400 | Reclasificar como riesgo en código, pendiente de retest.

Carga | 200 usuarios JMeter; umbral 450 ms | Lote Node, p95 8.698 ms; criterio histórico <300 ms.

Auditoría | logs_auditoria y cambio exitoso | Tabla auditoria sin IP; cambio de rol no acreditado en JSON.

Normativa | Ley futura presentada como vigente | Corte normativo y aplicación condicionada por sujeto.


## 2. Criterios de calidad

Los criterios siguientes operacionalizan los antecedentes del caso clínico. Los identificadores RF/NFR son heredados, no una transcripción certificada de una ERS completa disponible. Cada criterio se vincula a una prueba y a una condición medible; la severidad determina el orden de corrección, no modifica el resultado observado.

El sistema debe proteger datos de salud, controlar permisos por función y titularidad, conservar integridad, manejar errores sin revelar SQL/credenciales y permitir recuperación de incidentes. La calidad incluye usabilidad, rendimiento, estabilidad, confiabilidad y mantenibilidad; no se reduce a un número del análisis estático.

Corte de consulta: 17 de noviembre de 2026. Ley 19.628: régimen de protección de datos aplicable a la fecha; la información de salud exige tratamiento justificado y resguardo de confidencialidad [L1]. El informe no evalúa integralmente obligaciones sanitarias, contratos ni fichas clínicas; requieren revisión adicional.

Ley 21.719: preparación para su vigencia general del 1 de diciembre de 2026 según la versión oficial consultada [L2]. Se proponen inventario de datos, minimización, gestión de derechos, base de licitud y seguridad por diseño. No se presenta como un régimen general ya vigente. Verificar nuevamente la fecha si cambia el momento de entrega.

Ley 21.663: determinar si CreaLab o su cliente corresponde a institución obligada por servicios esenciales y si existe calificación OIV. La prestación institucional de salud está contemplada; no se infiere automáticamente que todo proveedor es OIV. Un defecto no equivale por sí mismo a un incidente significativo. Para sujetos obligados, la alerta temprana por incidentes significativos tiene plazo máximo de tres horas desde su conocimiento [L3–L4]. El reporte debe respetar las reglas de omisión de datos personales. La falta de IP no determina automáticamente infracción ni multa.

La retención de datos clínicos, logs y respaldos debe conciliarse con finalidad y obligaciones sectoriales. Soft delete no es una política integral de supresión. Docker, SonarQube o un gate verde no demuestran cumplimiento legal. Se requiere evidencia de controles y evaluación del contexto de tratamiento.

Dimensión / referencia | Criterio verificable | Evidencia actual

Adecuación e integridad | La baja conserva fila clínica y marca lógica. | FIN-16 FAIL. Adjuntos de octubre: antecedente, sin retest actual.

Acceso / NFR-SEG-4 | Anónimo y paciente no administran usuarios; médico no escala rol. | FIN-08/09/11/20 PASS tras cambio; FIN-05/06 conservan bloqueo entre pacientes.

Credenciales / NFR-SEG-2 | Hash adaptativo distinto de entrada. | FIN-17 FAIL.

Trazabilidad / RF-5.1 | Origen validado, permisos mínimos y atomicidad. | FIN-13 PASS en su alcance; FIN-14/15 FAIL.

Eficiencia / NFR-PERF-1 | Objetivo histórico <300 ms; acordar p95 para carga. | FIN-18 FAIL; no campaña JMeter actual.

Usabilidad / accesibilidad | Login visible correcto; WCAG exige evaluación completa. | Ver recorrido_ui.json; no certifica WCAG.

Mantenibilidad / confiabilidad | Regresión de operaciones legítimas y rollback. | FIN-10/12 PASS; FIN-15 revela fallo de atomicidad.


## 3. Plan de pruebas

Plan mixto y basado en riesgo. Las automatizaciones históricas ejecutadas corresponden a scripts Node y SonarQube. El pipeline de herramientas adicionales es el diseño objetivo; una corrida ausente permanece pendiente, sin inventar resultados. Se priorizan autorización destructiva, confidencialidad clínica, integridad y auditoría antes de rendimiento y apariencia.


## 3.1 Estrategia de pruebas

Enfoque mixto y basado en riesgo: revisión del código y requisitos; Node e integración; Postman mediante Newman; carga/estrés con JMeter; DAST pasivo con ZAP; SAST con SonarQube y comprobaciones de UI. Las herramientas pesadas se ejecutan por etapas. Cada resultado se vincula al artefacto antes de redactar la conclusión.

El diagrama muestra automatización local. GitHub Actions, WCAG completo y restauración siguen pendientes. Controles transversales: datos sintéticos, roles mínimos, exclusión de JWT, huellas de versión y bloqueo de producción por reservas abiertas. Apoyan confidencialidad, integridad y trazabilidad, sin equivaler a certificación legal.

Entrada: QA autorizado y saludable, datos de prueba, versión identificada y herramientas disponibles. Salida: evidencia completa y cierre verificado de reservas. BLOCKED indica impedimento de entorno; FAIL indica requisito ejercitado e incumplido. Un scanner que termina correctamente no aprueba el producto automáticamente.


## 3.2 Tipos de prueba

Tipo | Objetivo | Casos / alcance

Funcional | Login, validación, alta y baja. | FIN-02/03/10/12/16/19.

Seguridad | Autenticación, roles, titularidad y credenciales. | FIN-04 a 09, 11, 17 y 20.

Integración | Correlacionar HTTP con PostgreSQL y auditoría. | FIN-08 a 17 y 20.

Resiliencia | Rechazo controlado de auditoría y estado posterior. | FIN-15; trigger de QA retirado al finalizar.

Rendimiento | Latencia de una consulta bajo condiciones registradas. | FIN-18; no carga sostenida.

UI / usabilidad | Formulario, mensaje de error y llegada a home. | Playwright cuando conste en recorrido_ui.json; accesibilidad completa pendiente.

Regresión | Mantener casos válidos y negativos tras el parche. | Mismos 20 casos en las dos versiones; FIN-10 verifica admin legítimo.


## 3.3 Criterios de aceptación

PASS exige coincidencia de respuesta, contenido y estado persistido; un 200 aislado no acredita éxito del requisito. FAIL indica incumplimiento del oráculo de prueba, no necesariamente explotación. BLOCKED corresponde a precondiciones fallidas o impedimento del entorno. NOT RUN significa caso diseñado sin ejecución. Inconcluyente se usa en la interpretación técnica de una evidencia que no ejercitó la acción pretendida, sin modificar retrospectivamente el resumen original.

Casos de autorización: sin token → 401; no autorizado → 403 o 404 deliberado que no exponga existencia/datos; fila y permisos intactos. Casos de persistencia: verificar SELECT antes/después. Adjuntos: bytes/hash y control del titular. Auditoría: evento y cambio atómicos con origen validado. Contraseñas: nunca iguales al texto de entrada. Rendimiento: ratificar el umbral histórico antes de ejecutar la nueva campaña.

SQLi requiere demostrar una ruta vulnerable con entradas controladas; no basta encontrar backticks o concatenación de fragmentos de SQL permitidos. IDOR exige evidencia de acceso no autorizado a un objeto específico. Un hotspot SAST requiere revisión; un gate sin condiciones no es criterio de aceptación del producto.


## 3.4 Herramientas utilizadas

Docker y Node.js sostienen el entorno; Visual Studio Code organiza revisión y diff. Postman ejecuta sus colecciones mediante Newman; no se atribuyen clics de GUI. JMeter es la herramienta que generó las muestras actuales de carga, y no se confunde con la ráfaga Node histórica. Responsable de QA y defensa: Antonella Cuvertino.

Los perfiles cortos de la actividad son exclusivamente de demostración QA, no una política de contraseñas para producción. Los scripts registran fecha y artefactos; el video debe mostrar evidencias legibles sin claves de SonarQube ni JWT.

Herramienta | Finalidad | Evidencia

Docker + Node.js | Entorno y automatización de API. | FIN-01 a FIN-20, bases separadas y hashes.

Visual Studio Code | Revisión de código y diferencias. | users.js, requireAdmin.js, validación y migración.

Postman / Newman 6.2.3 | Validación HTTP, permisos y tiempos. | 9 requests /12 aserciones por fase; colección y JSON.

Apache JMeter 5.6.3 | Carga y estrés con muestras reales. | 50/200 usuarios; JMX, JTL y HTML.

OWASP ZAP 2.17.0 | DAST pasivo de respuestas. | Cuatro rutas; alertas JSON y reporte HTML.

SonarQube | SAST y calidad del código. | Estado EJECUTADA; tarea, log, métricas y gate.


## 4. Diseño de casos de prueba

Se distinguen 20 casos de API Node comparados antes/después, casos independientes de UI y diseños especializados de Postman, JMeter, ZAP y SonarQube. Las fichas indican requisito, precondiciones, pasos, esperado, aceptación y datos. El registro maestro determina si cada ejecución tiene evidencia; no se declara que todos los casos estén proyectados.

FIN-15 instala un rechazo temporal de auditoría exclusivamente en QA para comprobar atomicidad y lo retira al terminar. El fallo no queda añadido a la aplicación. FIN-14 modifica y restituye un evento sintético para revisar privilegios. Las pruebas no usan datos clínicos reales.


## 4.1 FIN-01 · Servicio API disponible

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-01 / Servicio API disponible / Disponibilidad

DESCRIPCIÓN | Validar servicio api disponible y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | GET /. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 200 y status=ok

CRITERIO DE ACEPTACIÓN | HTTP 200 y status=ok. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.2 FIN-02 · Login válido

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-02 / Login válido / RF-1.1

DESCRIPCIÓN | Validar login válido y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Login con cuenta sintética y verificar JWT sin mostrarlo. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 200 y JWT verificable

CRITERIO DE ACEPTACIÓN | HTTP 200 y JWT verificable. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.3 FIN-03 · Contraseña incorrecta

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-03 / Contraseña incorrecta / RF-1.1

DESCRIPCIÓN | Validar contraseña incorrecta y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Login con clave incorrecta. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 401 sin JWT

CRITERIO DE ACEPTACIÓN | HTTP 401 sin JWT. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.4 FIN-04 · JWT alterado

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-04 / JWT alterado / NFR-SEG-9

DESCRIPCIÓN | Validar jwt alterado y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Consultar examen con JWT alterado. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 401 sin datos

CRITERIO DE ACEPTACIÓN | HTTP 401 sin datos. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.5 FIN-05 · Paciente B no consulta listado de A

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-05 / Paciente B no consulta listado de A / NFR-SEG-4

DESCRIPCIÓN | Validar paciente b no consulta listado de a y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | GET /examenes/paciente/idA con JWT de B. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 403 sin datos ajenos

CRITERIO DE ACEPTACIÓN | HTTP 403 sin datos ajenos. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.6 FIN-06 · IDOR por identificador de examen

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-06 / IDOR por identificador de examen / NFR-SEG-4

DESCRIPCIÓN | Validar idor por identificador de examen y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | GET /examenes/idA con JWT de B. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 403 o 404; sin diagnosis ajena

CRITERIO DE ACEPTACIÓN | HTTP 403 o 404; sin diagnosis ajena. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.7 FIN-07 · Intento SQLi en login

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-07 / Intento SQLi en login / NFR-SEG

DESCRIPCIÓN | Validar intento sqli en login y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Enviar nombre de usuario con expresión SQL controlada. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 401 sin token; no evade login

CRITERIO DE ACEPTACIÓN | HTTP 401 sin token; no evade login. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.8 FIN-08 · Borrado de usuario sin autenticar

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-08 / Borrado de usuario sin autenticar / NFR-SEG-4 / DEF-006

DESCRIPCIÓN | Validar borrado de usuario sin autenticar y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Crear cuenta descartable; DELETE sin token; SELECT posterior. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 401 y fila conservada

CRITERIO DE ACEPTACIÓN | HTTP 401 y fila conservada. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.9 FIN-09 · Paciente no elimina usuarios

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-09 / Paciente no elimina usuarios / NFR-SEG-4 / DEF-006

DESCRIPCIÓN | Validar paciente no elimina usuarios y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | DELETE de cuenta descartable con JWT paciente; comprobar persistencia. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 403 y fila conservada

CRITERIO DE ACEPTACIÓN | HTTP 403 y fila conservada. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.10 FIN-10 · Admin elimina con auditoría válida

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-10 / Admin elimina con auditoría válida / NFR-SEG-4 / regresión

DESCRIPCIÓN | Validar admin elimina con auditoría válida y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | DELETE de cuenta descartable con admin; verificar fila y auditoría. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 200, fila eliminada y evento con actor numérico

CRITERIO DE ACEPTACIÓN | HTTP 200, fila eliminada y evento con actor numérico. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.11 FIN-11 · Médico no se asigna admin con payload válido

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-11 / Médico no se asigna admin con payload válido / NFR-SEG-4 / DEF-005

DESCRIPCIÓN | Validar médico no se asigna admin con payload válido y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen. Médico con rol médico inicial y payload que contiene nombre_usuario válido más rol_id.

PASOS | PUT perfil propio con nombre_usuario válido + rol_id admin; consultar roles. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 403 y rol médico intacto

CRITERIO DE ACEPTACIÓN | HTTP 403 y rol médico intacto. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.12 FIN-12 · Admin cambia solo rol con payload mínimo

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-12 / Admin cambia solo rol con payload mínimo / RF-5.1 / validación

DESCRIPCIÓN | Validar admin cambia solo rol con payload mínimo y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | PUT cuenta descartable con solo rol_id como admin. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 200 y rol solicitado persistido

CRITERIO DE ACEPTACIÓN | HTTP 200 y rol solicitado persistido. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.13 FIN-13 · Cambio de rol registra IP confiable

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-13 / Cambio de rol registra IP confiable / RF-5.1 / DEF-001

DESCRIPCIÓN | Validar cambio de rol registra ip confiable y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | PUT válido como admin con X-Forwarded-For falso; consultar último evento. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 200 y evento con IP no tomada de encabezado falso

CRITERIO DE ACEPTACIÓN | HTTP 200 y evento con IP no tomada de encabezado falso. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.14 FIN-14 · Auditoría no modificable por rol aplicativo

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-14 / Auditoría no modificable por rol aplicativo / RF-5.1 / inmutabilidad

DESCRIPCIÓN | Validar auditoría no modificable por rol aplicativo y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Crear evento sintético y tratar de modificarlo con la conexión usada por la API. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | UPDATE denegado y evento intacto

CRITERIO DE ACEPTACIÓN | UPDATE denegado y evento intacto. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.15 FIN-15 · Cambio de rol y auditoría son atómicos

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-15 / Cambio de rol y auditoría son atómicos / RF-5.1 / transacción

DESCRIPCIÓN | Validar cambio de rol y auditoría son atómicos y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen. Base QA exclusiva y permiso de preparar/retirar el rechazo controlado; no ejecutar en datos reales.

PASOS | Instalar rechazo de auditoría solo en QA; cambiar rol; comparar; retirar trigger. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | Si falla auditoría, HTTP 500 y rol anterior conservado

CRITERIO DE ACEPTACIÓN | Si falla auditoría, HTTP 500 y rol anterior conservado. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.16 FIN-16 · Examen conserva fila tras baja

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-16 / Examen conserva fila tras baja / RF-3.3 / DEF-003

DESCRIPCIÓN | Validar examen conserva fila tras baja y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Insertar examen sintético; DELETE como admin; SELECT posterior. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 200 y fila con marca lógica

CRITERIO DE ACEPTACIÓN | HTTP 200 y fila con marca lógica. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.17 FIN-17 · Registro persiste hash de contraseña

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-17 / Registro persiste hash de contraseña / NFR-SEG-2 / DEF-002

DESCRIPCIÓN | Validar registro persiste hash de contraseña y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Registro vía API; comprobar campo en DB sin imprimirlo; probar login. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | 201 y hash adaptativo, distinto a entrada

CRITERIO DE ACEPTACIÓN | 201 y hash adaptativo, distinto a entrada. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.18 FIN-18 · Consulta cumple objetivo histórico de latencia

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-18 / Consulta cumple objetivo histórico de latencia / NFR-PERF-1 / DEF-004

DESCRIPCIÓN | Validar consulta cumple objetivo histórico de latencia y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | Medir GET /examenes; no confundir consulta aislada con carga sostenida. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 200 y menos de 300 ms

CRITERIO DE ACEPTACIÓN | HTTP 200 y menos de 300 ms. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.19 FIN-19 · Campos obligatorios de examen

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-19 / Campos obligatorios de examen / RF-3.1

DESCRIPCIÓN | Validar campos obligatorios de examen y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | POST /examenes {} con médico; contar filas antes y después. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 400 y sin nueva fila

CRITERIO DE ACEPTACIÓN | HTTP 400 y sin nueva fila. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.20 FIN-20 · Paciente no crea una cuenta admin

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | FIN-20 / Paciente no crea una cuenta admin / NFR-SEG-4 / cobertura adicional

DESCRIPCIÓN | Validar paciente no crea una cuenta admin y comparar comportamiento entre versiones.

PRECONDICIONES | Fixture sintético preparado; API saludable; mismo caso en ambas fases. La identidad y el token se obtienen en ejecución y no se imprimen.

PASOS | POST /usuarios con paciente y rol_id admin; verificar persistencia. Ejecutar la misma secuencia en antes y despues; conservar ambos JSON y comparar.

RESULTADO ESPERADO | HTTP 403 y ninguna cuenta creada

CRITERIO DE ACEPTACIÓN | HTTP 403 y ninguna cuenta creada. No cambiar el criterio para convertir un FAIL en PASS.

DATOS DE PRUEBA | Cuentas qa_final_admin / medico / a / b y registros descartables del fixture; IDs dinámicos. Contraseñas y JWT no se imprimen. Ver preparar_datos.cjs y campana.cjs.


## 4.21 UI-01 · Login incorrecto visible

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | UI-01 / Login incorrecto visible / RF-1.1 y usabilidad

DESCRIPCIÓN | Recorrido UI adicional sobre la versión con cambios; no es comparación antes/después.

PRECONDICIONES | API 4447 y web 3344 disponibles; cuenta QA; navegador Edge/Chromium controlado por Playwright.

PASOS | Abrir /login; completar usuario sintético; enviar clave incorrecta para UI-01/03 y correcta para UI-02; observar HTTP, mensaje, número de avisos y URL.

RESULTADO ESPERADO | HTTP 401 y aviso visible de credenciales inválidas.

CRITERIO DE ACEPTACIÓN | HTTP 401 y aviso visible de credenciales inválidas.

DATOS DE PRUEBA | admin/Admin para administrador y medico/medico para médico, recreados solo en QA; JWT no se imprime.


## 4.22 UI-03 · Aviso de error no duplicado

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | UI-03 / Aviso de error no duplicado / RF-1.1 y usabilidad

DESCRIPCIÓN | Recorrido UI adicional sobre la versión con cambios; no es comparación antes/después.

PRECONDICIONES | API 4447 y web 3344 disponibles; cuenta QA; navegador Edge/Chromium controlado por Playwright.

PASOS | Abrir /login; completar usuario sintético; enviar clave incorrecta para UI-01/03 y correcta para UI-02; observar HTTP, mensaje, número de avisos y URL.

RESULTADO ESPERADO | Un único aviso de error para un intento de login incorrecto.

CRITERIO DE ACEPTACIÓN | Un único aviso de error para un intento de login incorrecto.

DATOS DE PRUEBA | admin/Admin para administrador y medico/medico para médico, recreados solo en QA; JWT no se imprime.


## 4.23 UI-02 · Login correcto y home

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | UI-02 / Login correcto y home / RF-1.1 y usabilidad

DESCRIPCIÓN | Recorrido UI adicional sobre la versión con cambios; no es comparación antes/después.

PRECONDICIONES | API 4447 y web 3344 disponibles; cuenta QA; navegador Edge/Chromium controlado por Playwright.

PASOS | Abrir /login; completar usuario sintético; enviar clave incorrecta para UI-01/03 y correcta para UI-02; observar HTTP, mensaje, número de avisos y URL.

RESULTADO ESPERADO | HTTP 200 y navegación visible a /home.

CRITERIO DE ACEPTACIÓN | HTTP 200 y navegación visible a /home.

DATOS DE PRUEBA | admin/Admin para administrador y medico/medico para médico, recreados solo en QA; JWT no se imprime.


## 4.24 Colección Postman y aserciones

Campo | Definición

ID / nombre / requerimiento | PM-01 a PM-09 · Autenticación, permisos y latencia · RF-1.1 / NFR-SEG-4 / NFR-PERF-1

Descripción | Ejecutar la herramienta y evaluar su criterio, con alcance explícito.

Precondiciones | APIs 4446/4447; perfiles de actividad y dos objetivos descartables por fase.

Pasos | Ejecutar la colección: health, login admin, clave incorrecta, login médico, cambio de rol propio, cambio admin, consulta/latencia, DELETE anónimo e intento SQLi en login.

Resultado esperado / aceptación | Doce aserciones de la colección: 200 en flujo legítimo, 401/403 en denegación y latencia <300 ms.

Datos de prueba | Colección v2.1 y entornos en herramientas/Postman. JWT en memoria del runner; no se exporta.


## 4.25 JM-01 · carga_50

Campo | Definición

ID / nombre / requerimiento | JM-01 · carga_50 · NFR-PERF-1

Descripción | Ejecutar la herramienta y evaluar su criterio, con alcance explícito.

Precondiciones | API 4447 y JWT privado; ejecución CLI en QA.

Pasos | Ejecutar JMX en modo no gráfico y conservar JTL, consola y HTML.

Resultado esperado / aceptación | p95 <300 ms y cero errores HTTP; registrar máximo de hilos observado.

Datos de prueba | 50 hilos, rampa 10 s, duración programada 45 s, pausa 1 s.


## 4.26 JM-02 · estres_200

Campo | Definición

ID / nombre / requerimiento | JM-02 · estres_200 · NFR-PERF-1

Descripción | Ejecutar la herramienta y evaluar su criterio, con alcance explícito.

Precondiciones | API 4447 y JWT privado; ejecución CLI en QA.

Pasos | Ejecutar JMX en modo no gráfico y conservar JTL, consola y HTML.

Resultado esperado / aceptación | p95 <300 ms y cero errores HTTP; registrar máximo de hilos observado.

Datos de prueba | 200 hilos, rampa 20 s, duración programada 60 s, pausa 1 s.


## 4.27 DAST pasivo con ZAP

Campo | Definición

ID / nombre / requerimiento | ZAP-01 · Cabeceras y respuestas · Seguridad HTTP

Descripción | Ejecutar la herramienta y evaluar su criterio, con alcance explícito.

Precondiciones | ZAP local, QA y cuatro rutas conocidas.

Pasos | Pasar las solicitudes por ZAP, esperar cola pasiva cero y exportar alertas/HTML.

Resultado esperado / aceptación | Análisis finalizado con alertas revisables; no implica DAST activo ni seguridad completa.

Datos de prueba | /, /openapi.json, /docs/ y /examenes; JWT QA solo para la última.


## 4.28 SAST del código actual

Campo | Definición

ID / nombre / requerimiento | SAST-01 · Calidad y patrones estáticos · Mantenibilidad / seguridad

Descripción | Ejecutar la herramienta y evaluar su criterio, con alcance explícito.

Precondiciones | Servidor UP, token privado y fuente actual BACKEND/src + FRONTEND/src.

Pasos | Ejecutar scanner oficial; esperar CE; exportar métricas, issues, hotspots y gate.

Resultado esperado / aceptación | Tarea SUCCESS para análisis ejecutado; interpretar gate y defectos dinámicos por separado.

Datos de prueba | Proyecto cuidarte-ep5-20261117; sin LCOV importado.


## 4.29 UI-04 · Perfil médico de la actividad

Campo | Definición

ID / nombre / requerimiento | UI-04 · Login y llegada a home médico · RF-1.1 / UI

Descripción | Ejecutar la herramienta y evaluar su criterio, con alcance explícito.

Precondiciones | App QA 3344 disponible; cuenta medico recreada en QA.

Pasos | Abrir /login; ingresar medico/medico; verificar HTTP 200 y navegación a /home.

Resultado esperado / aceptación | HTTP 200 y pantalla home visible; no equivale a probar todo el flujo clínico.

Datos de prueba | Credenciales de actividad; captura 03b_app_medico.png y recorrido_ui.json.


## 5. Ejecución de pruebas

Campaña real antes/después sobre bases QA distintas. Cada JSON conserva fecha UTC, entorno, resultados por caso y hashes de los archivos relevantes. Un exit code 1 del runner indica FAIL de las aserciones; exit code 2 indica bloqueo de precondiciones. No implica automáticamente que el servicio completo esté caído.


## 5.1 Resumen de ejecución

El registro distingue unidades: casos Node, aserciones Postman, usuarios/muestras JMeter y alertas ZAP no se suman en un porcentaje global. La campaña Node del 16 de noviembre conserva sus fechas reales. Las ejecuciones especializadas del 17 se muestran separadas; octubre queda como antecedente.

Node compara 20 casos: 8 PASS/12 FAIL antes y 15 PASS/5 FAIL después, con siete mejoras y ninguna regresión en los PASS iniciales. Postman repite nueve solicitudes y doce aserciones por fase: 8/12 aprobadas antes, 11/12 después. Persiste el incumplimiento de latencia.

Un arranque de herramienta bloqueado se conserva como incidencia de entorno; no se transforma en resultado de aplicación. Los pendientes WCAG completo, CI/CD y restauración no tienen conclusiones de cumplimiento. Las métricas nuevas de SonarQube, si su tarea finaliza, reemplazan la referencia histórica en el análisis actual.

Conjunto | Unidad y fecha | Resultado

Node antes / después | 20 casos ×2 ·16 nov | 8 PASS/12 FAIL →15 PASS/5 FAIL.

Postman antes / después | 12 aserciones ×2 ·17 nov | 8 PASS/4 FAIL →11 PASS/1 FAIL.

JMeter | 50/200 usuarios ·17 nov | Dos perfiles; ver muestras y p95 en 5.2.2.

ZAP pasivo | Cuatro rutas ·17 nov | COMPLETADA CON ALERTAS

SonarQube | Código actual ·17 nov | SUCCESS

UI | Casos independientes | Fecha y estado en recorrido_ui.json.

Pendientes | Sin ejecución acreditada | WCAG completo, Actions, restauración y DAST activo exhaustivo.


## 5.2 Detalle de ejecución de casos

Ejecución antes UTC: 2026-11-16T04:35:48.548Z; después UTC: 2026-11-16T04:54:21.436Z. La fecha individual está en date_utc de cada caso. Ejecutor técnico: automatización asistida Node; responsable de revisión y defensa: Antonella Cuvertino. No se afirma que una automatización sea una ejecución manual ya efectuada por la estudiante.

Evidencias: resultados/antes.json y resultados/despues.json. Los snapshots y el diff identifican qué código cambió. Las capturas del reporte se rotulan como reporte generado de esos JSON; las capturas de login/home provienen del navegador real. La guía 04 indica qué debe capturarse y cómo explicar cada evidencia.

Caso / requisito | Antes → después / evidencia | Interpretación

FIN-01
Servicio API disponible
Disponibilidad | PASS: HTTP=200; ms=501
PASS: HTTP=200; ms=170
JSON: results[0] | CONTROL CONSERVADO

FIN-02
Login válido
RF-1.1 | PASS: HTTP=200
PASS: HTTP=200
JSON: results[1] | CONTROL CONSERVADO

FIN-03
Contraseña incorrecta
RF-1.1 | PASS: HTTP=401; ms=26
PASS: HTTP=401; ms=15
JSON: results[2] | CONTROL CONSERVADO

FIN-04
JWT alterado
NFR-SEG-9 | PASS: HTTP=401; ms=44
PASS: HTTP=401; ms=18
JSON: results[3] | CONTROL CONSERVADO

FIN-05
Paciente B no consulta listado de A
NFR-SEG-4 | PASS: HTTP=403; ms=47
PASS: HTTP=403; ms=71
JSON: results[4] | CONTROL CONSERVADO

FIN-06
IDOR por identificador de examen
NFR-SEG-4 | PASS: HTTP=404; ms=93
PASS: HTTP=404; ms=102
JSON: results[5] | CONTROL CONSERVADO

FIN-07
Intento SQLi en login
NFR-SEG | PASS: HTTP=401; ms=24
PASS: HTTP=401; ms=33
JSON: results[6] | CONTROL CONSERVADO

FIN-08
Borrado de usuario sin autenticar
NFR-SEG-4 / DEF-006 | FAIL: HTTP=200; ms=65; filas posteriores=0
PASS: HTTP=401; ms=7; filas posteriores=1
JSON: results[7] | CORREGIDO

FIN-09
Paciente no elimina usuarios
NFR-SEG-4 / DEF-006 | FAIL: HTTP=500; ms=93; filas posteriores=0
PASS: HTTP=403; ms=17; filas posteriores=1
JSON: results[8] | CORREGIDO

FIN-10
Admin elimina con auditoría válida
NFR-SEG-4 / regresión | FAIL: HTTP=500; ms=207; filas posteriores=0; IP evento=ausente
PASS: HTTP=200; ms=41; filas posteriores=0; IP evento=ausente
JSON: results[9] | CORREGIDO

FIN-11
Médico no se asigna admin con payload válido
NFR-SEG-4 / DEF-005 | FAIL: HTTP=200; ms=271; roles posteriores=['admin']
PASS: HTTP=403; ms=20; roles posteriores=['medico']
JSON: results[10] | CORREGIDO

FIN-12
Admin cambia solo rol con payload mínimo
RF-5.1 / validación | FAIL: HTTP=400; ms=20; roles posteriores=['paciente']
PASS: HTTP=200; ms=62; roles posteriores=['medico']
JSON: results[11] | CORREGIDO

FIN-13
Cambio de rol registra IP confiable
RF-5.1 / DEF-001 | FAIL: HTTP=200; roles posteriores=['medico']; IP evento=ausente
PASS: HTTP=200; roles posteriores=['medico']; IP evento=::ffff:127.0.0.1
JSON: results[12] | CORREGIDO EN ESTE ALCANCE

FIN-14
Auditoría no modificable por rol aplicativo
RF-5.1 / inmutabilidad | FAIL: UPDATE denegado=False; filas modificadas=1
FAIL: UPDATE denegado=False; filas modificadas=1
JSON: results[13] | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN

FIN-15
Cambio de rol y auditoría son atómicos
RF-5.1 / transacción | FAIL: HTTP=500; roles posteriores=['medico']
FAIL: HTTP=500; roles posteriores=['medico']
JSON: results[14] | ABIERTO · CORRECCIÓN PARCIAL DE AUDITORÍA

FIN-16
Examen conserva fila tras baja
RF-3.3 / DEF-003 | FAIL: HTTP=200; ms=294; filas posteriores=0; marca lógica=False
FAIL: HTTP=200; ms=144; filas posteriores=0; marca lógica=False
JSON: results[15] | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN

FIN-17
Registro persiste hash de contraseña
NFR-SEG-2 / DEF-002 | FAIL: HTTP=201; hash adaptativo=False; igual a entrada=True
FAIL: HTTP=201; hash adaptativo=False; igual a entrada=True
JSON: results[16] | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN

FIN-18
Consulta cumple objetivo histórico de latencia
NFR-PERF-1 / DEF-004 | FAIL: HTTP=200; latencia ms=5035
FAIL: HTTP=200; latencia ms=5067
JSON: results[17] | ABIERTO · CAUSA IDENTIFICADA

FIN-19
Campos obligatorios de examen
RF-3.1 | PASS: HTTP=400; ms=5027
PASS: HTTP=400; ms=5033
JSON: results[18] | CONTROL CONSERVADO

FIN-20
Paciente no crea una cuenta admin
NFR-SEG-4 / cobertura adicional | FAIL: HTTP=201; ms=50; cuentas creadas=1
PASS: HTTP=403; ms=12; cuentas creadas=0
JSON: results[19] | CORREGIDO

UI-01 · Login incorrecto visible | PASS · {"id": "UI-01", "status": "PASS", "http": 401, "visible_message": "Credenciales inválidas"} | Recorrido UI separado · 2026-11-17T18:04:25.050Z

UI-03 · Aviso de error no duplicado | FAIL · {"id": "UI-03", "status": "FAIL", "expected_messages": 1, "observed_messages": 2} | Recorrido UI separado · 2026-11-17T18:04:25.050Z

UI-02 · Login correcto y home | PASS · {"id": "UI-02", "status": "PASS", "http": 200, "url": "http://127.0.0.1:3344/home"} | Recorrido UI separado · 2026-11-17T18:04:25.050Z


## 5.2.0 Credenciales de actividad y recorrido UI

Las credenciales declaradas en la actividad se recrearon solo en QA. La verificación HTTP está en credenciales_actividad.json; el recorrido visible conserva su propia fecha en recorrido_ui.json. El perfil interno qa_final de los scripts no debe confundirse con el login manual admin/Admin o medico/medico.

Caso / fecha UTC | Obtenido | Evidencia / incidencia

UI-01 · 2026-11-17T18:04:25.050Z | PASS · Login incorrecto visible · HTTP 401 | resultados/recorrido_ui.json; capturas 01 a 03b. Sin incidencia nueva

UI-03 · 2026-11-17T18:04:25.050Z | FAIL · Aviso de error no duplicado · HTTP — | resultados/recorrido_ui.json; capturas 01 a 03b. DEF-UI-01: dos avisos

UI-02 · 2026-11-17T18:04:25.050Z | PASS · Login correcto y home · HTTP 200 | resultados/recorrido_ui.json; capturas 01 a 03b. Sin incidencia nueva

UI-04 · 2026-11-17T18:04:25.050Z | PASS · Login médico de la actividad y home · HTTP 200 | resultados/recorrido_ui.json; capturas 01 a 03b. Sin incidencia nueva


## 5.2.1 Postman ejecutado con Newman

Nueve solicitudes y doce aserciones por fase son unidades diferentes. La exportación excluye JWT y cuerpos de login. La colección es importable a Postman; esta evidencia corresponde al runner Newman.

Caso / fase / fecha UTC | Obtenido | Evidencia / incidencia

PM-01 · antes
2026-11-17T17:25:20.129Z | HTTP 200; 96 ms. PASS en sus aserciones | resultados/postman_antes.json
Sin incidencia nueva

PM-02 · antes
2026-11-17T17:25:20.129Z | HTTP 200; 175 ms. PASS en sus aserciones | resultados/postman_antes.json
Sin incidencia nueva

PM-03 · antes
2026-11-17T17:25:20.129Z | HTTP 401; 25 ms. PASS en sus aserciones | resultados/postman_antes.json
Sin incidencia nueva

PM-04 · antes
2026-11-17T17:25:20.129Z | HTTP 200; 36 ms. PASS en sus aserciones | resultados/postman_antes.json
Sin incidencia nueva

PM-05 · antes
2026-11-17T17:25:20.129Z | HTTP 200; 77 ms. FAIL: Cambio de rol denegado: 403 | resultados/postman_antes.json
DEF-005

PM-06 · antes
2026-11-17T17:25:20.129Z | HTTP 400; 11 ms. FAIL: Actualización permitida: 200 | resultados/postman_antes.json
Validación rol_id

PM-07 · antes
2026-11-17T17:25:20.129Z | HTTP 200; 5071 ms. FAIL: Latencia menor de 300 ms | resultados/postman_antes.json
DEF-004

PM-08 · antes
2026-11-17T17:25:20.129Z | HTTP 200; 24 ms. FAIL: Autenticación requerida: 401 | resultados/postman_antes.json
DEF-006

PM-09 · antes
2026-11-17T17:25:20.129Z | HTTP 401; 12 ms. PASS en sus aserciones | resultados/postman_antes.json
Sin incidencia nueva

PM-01 · despues
2026-11-17T17:25:26.373Z | HTTP 200; 38 ms. PASS en sus aserciones | resultados/postman_despues.json
Sin incidencia nueva

PM-02 · despues
2026-11-17T17:25:26.373Z | HTTP 200; 118 ms. PASS en sus aserciones | resultados/postman_despues.json
Sin incidencia nueva

PM-03 · despues
2026-11-17T17:25:26.373Z | HTTP 401; 10 ms. PASS en sus aserciones | resultados/postman_despues.json
Sin incidencia nueva

PM-04 · despues
2026-11-17T17:25:26.373Z | HTTP 200; 35 ms. PASS en sus aserciones | resultados/postman_despues.json
Sin incidencia nueva

PM-05 · despues
2026-11-17T17:25:26.373Z | HTTP 403; 43 ms. PASS en sus aserciones | resultados/postman_despues.json
DEF-005

PM-06 · despues
2026-11-17T17:25:26.373Z | HTTP 200; 42 ms. PASS en sus aserciones | resultados/postman_despues.json
Validación rol_id

PM-07 · despues
2026-11-17T17:25:26.373Z | HTTP 200; 5035 ms. FAIL: Latencia menor de 300 ms | resultados/postman_despues.json
DEF-004

PM-08 · despues
2026-11-17T17:25:26.373Z | HTTP 401; 4 ms. PASS en sus aserciones | resultados/postman_despues.json
DEF-006

PM-09 · despues
2026-11-17T17:25:26.373Z | HTTP 401; 9 ms. PASS en sus aserciones | resultados/postman_despues.json
Sin incidencia nueva


## 5.2.2 JMeter: carga y estrés reales

Los HTML proceden de JTL reales. Cero errores HTTP no implica cumplimiento de latencia. El token es compartido y el escenario consulta una operación; no acredita capacidad productiva prolongada ni 200 cuentas clínicas distintas.

Perfil / fecha UTC | Medición real | Resultado / evidencia

JM-01 · 2026-11-17T17:26:38.747393+00:00 | Hilos configurados 50, observados 50; 350 muestras; p95 5031 ms; errores HTTP 0 | FAIL · DEF-004
herramientas\JMeter\carga_50_20261117_172638

JM-02 · 2026-11-17T17:27:35.492200+00:00 | Hilos configurados 200, observados 200; 1727 muestras; p95 5034 ms; errores HTTP 0 | FAIL · DEF-004
herramientas\JMeter\estres_200_20261117_172638


## 5.2.3 ZAP: alertas y alcance

Fecha UTC: 2026-11-17T17:39:11.177872+00:00. Estado EJECUTADA. 15 instancias y 6 tipos de alerta; cola pasiva restante: 0. Evidencia: herramientas/ZAP/reporte_zap.html y alertas_zap.json.

La alerta Modern Web Application es informativa. CORS wildcard no elimina la autenticación JWT por sí solo; CSP/clickjacking en /docs/ deben valorarse en esa superficie. DAST activo exhaustivo sigue pendiente.

Alerta / riesgo | Evidencia | Tratamiento

10020 · Missing Anti-clickjacking Header
Medium | http://127.0.0.1:4447/docs/
 | Revisar alcance; endurecer cabeceras/CORS aplicables y retestar. No se afirma explotación.

10098 · Cross-Domain Misconfiguration
Medium | http://127.0.0.1:4447/examenes
Access-Control-Allow-Origin: * | Revisar alcance; endurecer cabeceras/CORS aplicables y retestar. No se afirma explotación.

10038 · Content Security Policy (CSP) Header Not Set
Medium | http://127.0.0.1:4447/docs/
 | Revisar alcance; endurecer cabeceras/CORS aplicables y retestar. No se afirma explotación.

10109 · Modern Web Application
Informational | http://127.0.0.1:4447/docs/
<script src="./swagger-ui-bundle.js"> </script> | Informativa: no requiere corrección de seguridad.

10021 · X-Content-Type-Options Header Missing
Low | http://127.0.0.1:4447/examenes
 | Revisar alcance; endurecer cabeceras/CORS aplicables y retestar. No se afirma explotación.

10037 · Server Leaks Information via "X-Powered-By" HTTP Response Header Field(s)
Low | http://127.0.0.1:4447/examenes
X-Powered-By: Express | Revisar alcance; endurecer cabeceras/CORS aplicables y retestar. No se afirma explotación.


## 5.2.4 SonarQube: resultado del análisis de cierre

Fecha UTC: 2026-11-17T18:15:04.161204+00:00. Estado EJECUTADA; tarea SUCCESS; proyecto cuidarte-ep5-20261117. Métricas actuales: {"bugs": "1", "code_smells": "72", "security_hotspots_reviewed": "0.0", "duplicated_lines_density": "14.4", "vulnerabilities": "0", "security_hotspots": "3", "ncloc": "10178", "coverage": "0.0"}

Gate exportado: {"status": "OK", "conditions": [], "periods": [], "ignoredConditions": false, "caycStatus": "compliant"}. No autoriza producción por sí solo. Sin LCOV no existe cobertura importada; los hotspots requieren revisión y los smells expresan mantenibilidad.

57 archivos JS y fuentes actuales BACKEND/src + FRONTEND/src; sin LCOV. CE del servidor confirma SUCCESS. El cliente agotó su timeout; la recuperación se documenta. issues.json solicita BUG, no todos los code smells; las métricas sí incluyen el total de la categoría.

Evidencias en herramientas/SonarQube: scanner.log, tarea.json, metricas.json, issues.json (consulta BUG), hotspots.json y quality_gate.json. Se conserva el aviso de compatibilidad del analizador con Node 22 y se propone actualizar el stack SAST compatible antes de CI; no se recomienda degradar producción a versiones obsoletas.


## 5.3 Criticidad de incidentes

Severidad expresa impacto en el sistema clínico; prioridad expresa orden de atención. Un riesgo crítico potencial se distingue de un incidente explotado. La pérdida de integridad o confidencialidad puede ser crítica aunque el sistema siga respondiendo. El nivel no se deduce automáticamente de una ley, una multa o un código HTTP.

Nivel | Descripción / impacto | Evidencia requerida

CRÍTICO | Acción no autorizada destructiva o compromiso grave de información clínica; bloquea liberación. | Reproducción controlada y persistencia/privilegio afectado. Si solo hay código, indicar riesgo pendiente.

GRAVE | Pérdida de trazabilidad, integridad parcial, credenciales expuestas o rendimiento fuera del requisito. | Dato persistido, esquema o métrica que incumple el criterio y contexto.

MODERADO | Defecto secundario con impacto limitado y alternativa operativa segura. | Caso reproducible y alcance limitado.

LEVE | Apariencia o texto sin afectar seguridad ni operación esencial. | Captura o evidencia visual contextualizada.


## 5.3.1 Estado de los incidentes tras el retest

Caso | Estado demostrado | Impacto / prioridad

FIN-08 | CORREGIDO | CRÍTICO / P0

FIN-09 | CORREGIDO | CRÍTICO / P0

FIN-10 | CORREGIDO | GRAVE / P1

FIN-11 | CORREGIDO | CRÍTICO / P0

FIN-12 | CORREGIDO | GRAVE / P1

FIN-13 | CORREGIDO EN ESTE ALCANCE | GRAVE / P1

FIN-14 | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN | GRAVE / P1

FIN-15 | ABIERTO · CORRECCIÓN PARCIAL DE AUDITORÍA | GRAVE / P1

FIN-16 | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN | GRAVE / P1

FIN-17 | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN | GRAVE / P0

FIN-18 | ABIERTO · CAUSA IDENTIFICADA | GRAVE / P1

FIN-20 | CORREGIDO | CRÍTICO / P0


## 6. Propuesta de mejora

Se corrigió código y se repitieron los mismos casos. CORREGIDO significa que el caso definido pasa en la versión posterior, no que desaparece todo riesgo del subsistema. ABIERTO no significa imposible de arreglar: distingue lo no abordado y el alcance parcial de la intervención. No se dejaron fallos artificiales ni se alteraron criterios para mantener o mejorar cifras.

ID / nombre | Estado tras retest | Propuesta de remediación / evidencia de cierre

FIN-08 · Borrado de usuario sin autenticar | CORREGIDO | DELETE se ejecutaba antes de autenticar. Se exige sesión y admin antes de mutar; el retest verifica 401 y fila intacta.

FIN-09 · Paciente no elimina usuarios | CORREGIDO | No había control de rol. Además, se enviaba un nombre de usuario a una columna BIGINT de auditoría: podía borrar y luego fallar. El retest exige 403 y fila intacta.

FIN-10 · Admin elimina con auditoría válida | CORREGIDO | La auditoría recibía nombreUsuario en vez de usuarioId. Se usa el ID numérico y una transacción para borrado más evento; el admin debe conservar su operación legítima.

FIN-11 · Médico no se asigna admin con payload válido | CORREGIDO | isAdminOrMedico permitía que un médico modificara su propio rol. Se restringe a isAdmin y se comprueba el rol posterior con un payload válido.

FIN-12 · Admin cambia solo rol con payload mínimo | CORREGIDO | rol_id no estaba declarado en updateUserSchema. Se declara como entero positivo; deja de rechazarse la solicitud legítima antes de llegar a autorización.

FIN-13 · Cambio de rol registra IP confiable | CORREGIDO EN ESTE ALCANCE | Se agrega ip_origen INET y se registra req.ip para el evento de actualización médica. Con trust proxy desactivado no se cree el encabezado XFF de prueba. No demuestra trazabilidad detrás de cualquier proxy ni de todas las rutas.

FIN-14 · Auditoría no modificable por rol aplicativo | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN | El rol configurado para QA conserva permisos para modificar auditoria. Agregar IP no cambia privilegios. Se necesita un rol aplicativo mínimo distinto del propietario, migraciones separadas y política de integridad/retención; no se revocan permisos a ciegas durante esta campaña.

FIN-15 · Cambio de rol y auditoría son atómicos | ABIERTO · CORRECCIÓN PARCIAL DE AUDITORÍA | La ruta de cambio de rol sigue usando pool.query separados sin transacción. Al rechazar controladamente el evento en QA, el rol ya cambió. Requiere client único + BEGIN/COMMIT/ROLLBACK para todo el flujo; no se afirma que el parche IP resuelva atomicidad.

FIN-16 · Examen conserva fila tras baja | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN | DELETE elimina físicamente examen_medico. Una baja lógica exige migración y actualizar listados, consultas, descargas y conservación. Cambiar solo DELETE no constituye una solución consistente.

FIN-17 · Registro persiste hash de contraseña | ABIERTO · NO ABORDADO EN ESTA ITERACIÓN | Registro persiste la clave en texto claro y login la compara directamente. Corregir exige hashing en alta/cambio, verificación segura y migración o reseteo de cuentas existentes. No basta cifrar una fila del fixture ni cambiar el test.

FIN-18 · Consulta cumple objetivo histórico de latencia | ABIERTO · CAUSA IDENTIFICADA | GET /examenes tiene delayMiddleware(5000), que añade cinco segundos. El resultado incumple <300 ms. Un índice o un pool mayor no elimina esa espera; retirar simulación y repetir carga es el siguiente cambio propuesto, no una imposibilidad técnica.

FIN-20 · Paciente no crea una cuenta admin | CORREGIDO | POST /usuarios autenticaba pero no exigía admin, permitiendo crear una cuenta privilegiada. Se agrega requireAdmin antes de validación e inserción; el paciente debe recibir 403 sin nueva fila.


## 6.1 Cambios aplicados y límites

users.js: requireAdmin en alta y borrado; consulta de roles actuales en base; solo isAdmin puede modificar rol_id. El esquema de validación declara rol_id positivo. El borrado administrativo usa usuarioId numérico y una conexión con transacción para fila y evento. FIN-08/09/10/11/12/20 verifican permisos y regresión del flujo legítimo.

Migración 001_auditoria_ip.sql y nuevo esquema: columna ip_origen INET. El evento de actualización médica registra req.ip sin confiar en X-Forwarded-For arbitrario. FIN-13 verifica ese alcance directo. Los demás eventos no se declaran completos. FIN-14/15 muestran que la auditoría todavía tiene problemas de privilegios y atomicidad del cambio de rol; la transacción implementada en DELETE no se generaliza falsamente a PUT.

El primer intento posterior dio 14 PASS y 6 FAIL: la columna existía, pero se había modificado el registro de la rama empresa y no la médica. Se conserva despues_intento1_ip_incompleta.json. Se corrigió la rama ejercitada y se repitieron los 20 casos, sin alterar el resultado esperado. La rama de empresas no recibió cobertura funcional en esta campaña; los controles nuevos requieren revisión adicional antes de usar un contexto multiempresa.

No se modificaron hash de contraseñas, baja lógica ni demora intencional. Sus correcciones requieren un cambio coherente y retests propios; la matriz describe la propuesta. Los tres servicios técnicos pueden responder mientras una funcionalidad incumple el requisito. En particular, el 500 previo de DELETE no significaba que la fila no cambiara.

El paquete de código exportado omite credenciales, .env, node_modules, logs y datos de pacientes. La configuración de conexión requiere DATABASE_URL. La versión anterior completa se conserva localmente y las fuentes comparables se acompañan de huellas; no se ejecutan contenedores contra datos reales.

Hallazgo adicional UI-03, LEVE y abierto: se observan dos avisos de credenciales inválidas en un solo intento. FRONTEND/src/lib/api.jsx muestra toast.error en el interceptor y pages/auth/Login.jsx vuelve a mostrarlo en catch. Se propone centralizar el aviso en una sola capa y repetir el caso; el frontend no se modificó durante esta iteración. UI-01 y UI-02 pasan. Este hallazgo no cambia el total API.


## 6.2 Rendimiento y accesibilidad: interpretación del retest

JMeter sí ejecutó carga y estrés reales en la versión posterior: una operación GET /examenes con token QA compartido. El JTL registra hilos observados, duración y muestras. No equivale a todas las tareas clínicas ni a 200 cuentas distintas.

El p95 ronda cinco segundos, coherente con delayMiddleware(5000). Cero errores HTTP no satisface la latencia. El objetivo histórico <300 ms debe ratificarse con la ERS; no se sustituye por 450 ms sin acuerdo. WCAG 2.1 AA completo sigue pendiente: el login visual no demuestra todos los criterios A/AA.


## 6.3 Plan de mantenimiento y mejora continua

Plan de preservación de calidad: las frecuencias son una propuesta del equipo, no plazos legales. Cada defecto se gestiona con responsable, impacto, prioridad, versión afectada, cambio implementado, evidencia anterior/posterior y aprobación. No se cierra por modificar código sin repetir el caso que fallaba.

Definition of Done propuesta: cero fallos críticos de autorización y persistencia; credenciales protegidas; auditoría transaccional; riesgos SQLi/IDOR revisados; hotspots evaluados; reportes SCA/DAST sin riesgos de bloqueo sin resolver; cobertura y rendimiento acordados cumplidos. Si una herramienta no se ejecuta, el gate queda bloqueado o requiere una excepción explícita documentada; nunca se inventa un PASS.

Frecuencia / disparador | Acción y responsable | Evidencia / respuesta

Cada PR / push | Antonella: CI, pruebas, SAST/SCA y secretos | Reportes por commit; bloquear fallos críticos.

Semanal | Antonella + desarrollo: nuevas CVE y dependencias | Triage y parche priorizado; regresión.

Cada release | Antonella: E2E, autorización, DAST y carga representativa | Acta de gate y aprobación del producto.

Mensual | Operaciones + equipo: restauración aislada | Integridad restaurada; registrar RPO/RTO medidos, metas por acordar.

Trimestral | Antonella: roles, retención, accesibilidad e imágenes | Revisión de accesos, política, WCAG y componentes soportados.

Incidente / cambio legal | Responsable institucional + cumplimiento | Contener, preservar evidencia, evaluar reporte y actualizar controles.


## 6.4 Dictamen y trazabilidad docente

CERTIFICADO CON RESERVAS como denominación académica solicitada; producción sigue BLOQUEADA. Se acredita una mejora de los casos que cambiaron a PASS, pero no el cierre de las reservas de auditoría, persistencia, contraseñas y rendimiento. No es una certificación legal.

Feedback aplicado: cada caso identifica requisito, evidencia, causa, prioridad y siguiente acción. La exposición de Antonella debe mostrar un FAIL inicial, el diff, el retest correspondiente y al menos un FAIL persistente explicado con su causa; no solo enumerar herramientas.

Entrega: informe, diapositivas y video individual de Antonella Cuvertino, Duoc UC, Ingeniería Informática, Desarrollo de Software, sección 02V, docente Luis Manuel Yagi Figueroa, defensa 17 noviembre 2026. El video sigue pendiente de grabación por la estudiante.

Indicador | Ubicación | Evidencia

IE1 · enfoques | 3.2–3.4 | HTTP/integración, SAST histórico y límites.

IE3 · diagramas | 3.1 | Pipeline propuesto rotulado.

IE5 · ejecución | 4 y 5 | 20 casos antes/después, JSON y retests.

IE7 · mantenimiento | 6.3 | Responsables, frecuencia y cierre.

IE9 · documentación | 5–6 y guía 04 | Recorrido, capturas, causa y mitigación.

[L1] Ley 19.628, versión aplicable antes del cambio de régimen. https://www.bcn.cl/leychile/navegar?idNorma=141599&idVersion=2026-11-16

[L2] Ley 21.719, disposiciones y vigencia diferida. https://www.bcn.cl/leychile/navegar?f=2026-12-01&i=1209272

[L3] Ley 21.663, ámbito, deberes e incidentes. https://www.bcn.cl/leychile/navegar?i=1202434

[L4] ANCI: obligación de reportar incidentes significativos. https://anci.gob.cl/noticias/obligacion-de-reportar/

[T1] node-postgres: consultas parametrizadas y prepared statements. https://node-postgres.com/features/queries

[T2] Express: configuración segura detrás de proxies. https://expressjs.com/en/guide/behind-proxies/

[T3] OWASP Top 10:2021, A01 Broken Access Control. https://top10.owasp.org/2021/A01_2021-Broken_Access_Control/

[T4] W3C: WCAG 2.1, conformidad nivel AA. https://www.w3.org/TR/2023/REC-WCAG21-20230921/

[T5] GitHub: runners propios y conectividad. https://docs.github.com/en/actions/reference/runners/self-hosted-runners

[T6] ISO/IEC 25010:2011, modelo empleado en los antecedentes. https://www.iso.org/standard/35733.html

[T7] Apache JMeter: ejecución no gráfica y resultados. https://jmeter.apache.org/usermanual/get-started.html

[T8] OWASP ZAP: baseline pasivo y límites. https://www.zaproxy.org/docs/docker/baseline-scan/