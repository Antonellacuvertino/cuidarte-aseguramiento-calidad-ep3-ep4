## Guion para video y defensa · Cuidarte+

Antonella Cuvertino · Duoc UC · ISY1102 · Sección 02V · 17 noviembre 2026

## Qué exige la pauta y qué es una recomendación

La pauta EP6 indica: “10 minutos de defensa del trabajo efectuado, más 5 minutos para responder preguntas”. El mensaje adicional del docente solicita informe, presentación y video con participación de los integrantes. No establece una duración independiente ni un formato específico para el video. Por ello, este guion propone una grabación cercana a 10 minutos, siguiendo la duración de la defensa; no convierte esa recomendación en una nueva exigencia del docente.

La pauta exige mostrar y explicar evidencias ejecutadas: logs, reportes o flujos. No especifica que deban repetirse todas las pruebas en vivo ni obliga a mostrar una cámara superpuesta. La modalidad recomendada es tu voz y cámara, junto con la presentación que incorpora capturas reales. Señala el dato y explica el requisito, el resultado y la decisión. Una demostración breve en la PC es opcional. Los cinco minutos de preguntas corresponden a la defensa; no necesitas agregarlos al video salvo una indicación posterior del profesor.

## Dónde está cada criterio EP6

Herramientas y finalidad (30%): láminas 2, 3, 7 y 8. Diagrama y controles/normativa (14%): láminas 2 y 9. Evidencias e impacto de la automatización (24%): láminas 3 a 8. Mantenimiento (20%): lámina 10. Recursos visuales (12%): comparativas y capturas incorporadas. Estos porcentajes corresponden a los indicadores de la pauta de presentación.

## Cómo organizar la grabación

1. Abre el PDF de presentación en modo pantalla completa. La guía es para ensayar y no debe verse como si fuera una diapositiva.

2. Coloca tu cámara en una esquina que no tape cifras ni capturas; si el programa lo permite, usa una ventana pequeña. Mantén voz clara y mira a la cámara al saludar y concluir.

3. Graba una prueba de 20 segundos y revisa audio y legibilidad. No muestres contraseñas, tokens, archivos .env ni accesos privados de SonarQube.

4. Durante la exposición muestra cada evidencia ya incluida. Puedes decir “esta captura corresponde a la ejecución registrada”, en vez de afirmar que estás corriendo la prueba en ese momento.

5. Ensaya una vez con cronómetro. Los intervalos son orientativos: ajusta pausas y señala resultados sin leer deprisa. No hay una medición real de ahorro manual; explica repetibilidad y trazabilidad sin inventar porcentajes.

6. Revisa el video completo antes de entregarlo. Entrega informe 01 con evidencias, presentación 02 y tu grabación. La guía 03 es material personal de preparación.

## ¿Debo mostrar mi PC ejecutando pruebas?

Puedes cumplir mostrando la presentación y explicando sus reportes legibles. Para reforzar la evidencia, también puedes abrir durante unos segundos un reporte original, sin volver a ejecutar una carga o un escaneo. Eso es mostrar resultados guardados, no una nueva ejecución. No necesitas iniciar JMeter, ZAP o SonarQube durante el video.

## Demostración opcional, 20–30 segundos

Si prefieres mostrar una ejecución real, utiliza solamente un intento de login incorrecto en el laboratorio QA. En Postman importa herramientas/Postman/Cuidarte_EP5.postman_collection.json y selecciona el entorno despues.postman_environment.json. Revisa que base apunte a http://127.0.0.1:4447. Selecciona PM-03, verifica en la colección que sea el intento de clave incorrecta, pulsa Send y muestra HTTP 401 y Test Results. Haz primero una prueba fuera de la grabación. No ejecutes la colección completa ni operaciones de borrado durante esa demostración. Si el entorno no está disponible, omite la demostración y utiliza las evidencias incorporadas; no presentes un bloqueo del entorno como resultado de esa prueba.

Frase para la demostración: “Ahora muestro un intento de acceso con contraseña incorrecta en el entorno de prueba. El requisito es rechazar las credenciales inválidas. La respuesta es cuatrocientos uno, por lo que este intento no obtiene acceso. Esta ejecución breve complementa los reportes de la campaña anterior”. Si eliges hacerlo, reemplaza parte de la explicación de la lámina 3 para mantenerte cerca de diez minutos.

Si necesitas abrir la app para explicar el contexto: http://127.0.0.1:3344/login. Los perfiles de demostración de la actividad son admin / Admin y medico / medico, exclusivamente en QA. No es necesario hacer un login válido frente a cámara. Para repetir campañas completas, usa los scripts del laboratorio fuera de la grabación y conserva sus nuevas fechas sin sustituir los resultados históricos del informe.

## Guion literal por diapositiva · 1124 palabras

Lee solo el texto marcado como “Qué decir”. Las instrucciones de pantalla son para ti y no se pronuncian. El tiempo final depende de tu ritmo y de las pausas; compruébalo con un ensayo grabado. No agregues el banco de preguntas al video si el docente no lo solicitó.


---

## Lámina 1. Cuidarte+ · evaluación de seguridad y calidad

Tiempo orientativo: 00:00–00:45

## Qué mostrar — no leer en voz alta

Comparte la lámina 1 y mantén tu cámara en una esquina libre. Mira a la cámara durante el saludo. No necesitas iniciar sesión en vivo.

## Qué decir

Buenos días, profesor. Mi nombre es Antonella Cuvertino y presentaré la evaluación de seguridad y calidad de Cuidarte+, un sistema de gestión de exámenes y fichas médicas. El objetivo fue comprobar qué funcionaba, qué errores existían y qué cambió después de una primera etapa de correcciones. Trabajé con datos sintéticos y dos versiones separadas del laboratorio. En esta presentación explicaré los requisitos evaluados, sus evidencias y las mejoras pendientes. Mi recomendación final es mantener bloqueada la liberación a producción, porque aún existen riesgos relevantes para la información clínica.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 2. Estrategia: probar, corregir y volver a comprobar

Tiempo orientativo: 00:45–01:40

## Qué mostrar — no leer en voz alta

Señala el diagrama de izquierda a derecha. Detente en la revisión final de evidencias y menciona qué partes siguen pendientes.

## Qué decir

Mi estrategia fue basada en riesgo: prioricé acciones capaces de eliminar información o aumentar privilegios. El diagrama muestra cómo relacioné el código y los datos de prueba con los controles automatizados. Primero preparé el laboratorio; después ejecuté la versión original, revisé los fallos, apliqué cambios acotados y repetí los mismos casos. Las pruebas de API verificaron tanto las respuestas como el estado en PostgreSQL. Complementé el análisis con SonarQube, ZAP y JMeter. La automatización permite repetir los controles con el mismo criterio y conservar resultados comparables. No medí un ahorro de tiempo frente a una ejecución manual. Este flujo se ejecutó localmente; su integración en GitHub Actions es una propuesta pendiente.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 3. Herramientas: qué pregunta responde cada una

Tiempo orientativo: 01:40–02:40

## Qué mostrar — no leer en voz alta

Muestra los dos indicadores de Postman. No hace falta abrir seis programas. Si decides hacer una demostración, reserva solo 20–30 segundos para la solicitud de contraseña incorrecta indicada al final de la guía.

## Qué decir

Cada herramienta aportó una evidencia diferente. Docker y Node.js permitieron ejecutar el laboratorio y automatizar pruebas HTTP e integración. En Visual Studio Code revisé las rutas y los cambios. Las colecciones de Postman se ejecutaron con Newman, que es su herramienta de línea de comandos: cada fase tuvo nueve solicitudes y doce aserciones. Antes aprobaron ocho aserciones y después once; siguió fallando el tiempo de respuesta. JMeter evaluó carga y estrés; ZAP observó la aplicación en ejecución mediante análisis pasivo; SonarQube revisó el código sin ejecutar los recorridos de negocio. Estas herramientas se complementan. No presento resultados de Jest, Cypress ni un escaneo específico de dependencias, porque no forman parte de las ejecuciones acreditadas.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 4. Resultado comparativo: siete casos mejoraron

Tiempo orientativo: 02:40–03:30

## Qué mostrar — no leer en voz alta

Señala los segmentos verdes y rojos de las barras. Son resultados guardados, no una ejecución nueva durante la grabación.

## Qué decir

La comparación principal utiliza veinte casos únicos, repetidos en dos versiones. En la versión original obtuve ocho aprobados y doce fallidos. Después de los cambios, quince aprobaron y cinco siguieron fallando. Siete casos mejoraron y los ocho que ya aprobaban se mantuvieron. Esto demuestra una mejora dentro del alcance probado, pero no una aprobación general del producto. Tampoco sumo estos resultados con las aserciones de Postman, las muestras de JMeter o las alertas de ZAP, porque son unidades diferentes. Los archivos conservan la fecha y el resultado individual de cada caso.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 5. Permisos: un borrado sin sesión quedó bloqueado

Tiempo orientativo: 03:30–04:40

## Qué mostrar — no leer en voz alta

Señala primero el resultado original y después el retest en la captura. Explica la fila conservada. No es necesario ejecutar una operación de borrado en vivo.

## Qué decir

Este ejemplo muestra por qué no basta con mencionar una herramienta. El requisito es que solo un administrador pueda gestionar usuarios. En FIN-08 envié una solicitud de borrado sin token. La versión original respondió doscientos y la consulta posterior confirmó que la cuenta sintética había desaparecido. La causa era la falta del control de acceso antes de modificar los datos. Se incorporó requireAdmin y el retest devolvió cuatrocientos uno, conservando la fila. Priorizo este defecto por el riesgo de pérdida de información sin identificar al actor. También se verificó que un paciente no pudiera borrar usuarios y que un médico no pudiera asignarse el rol administrador. La operación legítima del administrador se comprobó por separado para evitar que la corrección bloqueara todo el servicio.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 6. Auditoría: registrar la IP fue una mejora parcial

Tiempo orientativo: 04:40–05:50

## Qué mostrar — no leer en voz alta

Muestra el FAIL persistente. Señala que el cambio de rol quedó aplicado pese al fallo del registro de auditoría.

## Qué decir

En auditoría se agregó la IP al evento de cambio de rol. FIN-13 comprobó que, en la conexión directa evaluada, se registró la dirección de conexión y no el encabezado falso enviado en la prueba. Sin embargo, esa mejora no resuelve toda la trazabilidad. FIN-14 mostró que el rol usado en QA aún podía modificar eventos. En FIN-15 provoqué de forma controlada un rechazo de auditoría: el cambio de rol quedó aplicado y no se revirtió. La causa es que ambas operaciones no forman una única transacción. La propuesta es usar una sola conexión con confirmación o rollback, y limitar los permisos sobre auditoría. Estos errores siguen abiertos y necesitan un nuevo cambio y su retest; no son imposibles de corregir.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 7. Rendimiento: responder sin error no basta

Tiempo orientativo: 05:50–06:50

## Qué mostrar — no leer en voz alta

Señala el p95 y el número de muestras. El resultado HTTP exitoso del reporte no equivale a aprobar el objetivo de latencia.

## Qué decir

Con JMeter ejecuté carga de cincuenta usuarios y estrés de doscientos usuarios virtuales. Los percentiles noventa y cinco fueron cinco mil treinta y un milisegundos y cinco mil treinta y cuatro milisegundos. No hubo errores HTTP, pero ambos perfiles incumplieron el objetivo histórico de menos de trescientos milisegundos. El percentil noventa y cinco indica que aproximadamente el noventa y cinco por ciento de las respuestas quedó en ese tiempo o por debajo. En el código existe una espera artificial de cinco segundos, coherente con la medición. Un índice no elimina esa espera. Propongo retirarla del entorno objetivo y repetir las pruebas. El alcance fue una operación con token compartido, no doscientas cuentas clínicas ni una jornada completa de trabajo.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 8. Seguridad: interpretar alertas y métricas

Tiempo orientativo: 06:50–08:00

## Qué mostrar — no leer en voz alta

Muestra el resumen de métricas exportadas y explica la limitación del gate. Son datos del análisis guardado, no una captura del panel ni una ejecución nueva.

## Qué decir

ZAP detectó quince instancias agrupadas en seis tipos de alerta sobre cuatro rutas. Las alertas requieren revisar su contexto: por ejemplo, una política CORS permisiva o la ausencia de cabeceras no demuestra automáticamente una intrusión. El análisis fue pasivo; una evaluación activa exhaustiva queda pendiente. SonarQube finalizó con un bug, setenta y dos code smells y tres hotspots. Los smells orientan mejoras de mantenibilidad y los hotspots requieren revisión de seguridad. El analizador clasificó cero vulnerabilidades, pero esto no elimina los defectos que demostraron las pruebas de API. Además, el Quality Gate aparece en verde con una lista vacía de condiciones y no se importó cobertura LCOV. Por estas razones no utilizo ese resultado como autorización para producción ni como prueba de seguridad completa.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 9. Calidad y normativa: del criterio al control

Tiempo orientativo: 08:00–09:00

## Qué mostrar — no leer en voz alta

Relaciona cada norma con un control. No leas números de artículos ni afirmes una certificación legal.

## Qué decir

Relacioné los resultados con criterios de calidad y protección de datos. En ISO dos cinco cero uno cero consideré la adecuación funcional, seguridad, confiabilidad y desempeño. Para la información clínica, la Ley diecinueve mil seiscientos veintiocho es la referencia aplicable al corte de esta entrega; por eso utilicé datos sintéticos y prioricé permisos y confidencialidad. También preparé medidas para la transición a la Ley veintiún mil setecientos diecinueve, cuya vigencia general está prevista para el primero de diciembre de dos mil veintiséis. Respecto de la Ley de Ciberseguridad, se debe determinar el ámbito aplicable a la organización y establecer gestión de incidentes. Estas pruebas respaldan controles concretos, pero no acreditan cumplimiento legal integral ni conformidad completa con WCAG.

## Transición

Pasa a la siguiente lámina después de terminar esta explicación.


---

## Lámina 10. Decisión y siguiente iteración

Tiempo orientativo: 09:00–10:00

## Qué mostrar — no leer en voz alta

Vuelve a mirar a la cámara para la conclusión. Termina la grabación después de agradecer; el banco de preguntas es material para ensayar.

## Qué decir

La siguiente iteración debe priorizar el hash de contraseñas, los permisos de auditoría y el rollback del cambio de rol. También debe implementar una baja lógica coherente y resolver la latencia. Cada corrección necesita repetir el caso afectado y comprobar que no rompe los escenarios que ya funcionaban. Para mantener la calidad propongo regresión en cada cambio, revisión semanal de dependencias y pruebas periódicas de carga y restauración. Quedan pendientes, entre otros, GitHub Actions, WCAG completo y la evaluación activa exhaustiva. En conclusión, hubo una mejora de ocho a quince casos aprobados, pero persisten riesgos. Mi dictamen académico es certificado con reservas y recomiendo mantener bloqueada la producción hasta verificar su cierre. Muchas gracias.

## Transición

Mira a la cámara, agradece y detén la grabación.

## Banco de preguntas para ensayar la defensa

## ¿Debías arreglar todos los errores para aprobar?

El objetivo es evaluar, justificar y verificar las mejoras. Un defecto abierto debe tener evidencia, causa, impacto y acción propuesta. No se convierte en aprobado por documentarlo; las reservas relevantes mantienen bloqueada la producción.

## ¿Cómo demuestras que el borrado sin sesión se corrigió?

FIN-08 pasó de HTTP 200 y cero filas a HTTP 401 y una fila conservada. Se añadió control de administrador antes de la operación. FIN-10 comprobó además que el administrador mantiene su operación legítima.

## ¿Un Quality Gate verde significa que el sistema es seguro?

No. El gate observado no tiene condiciones. El análisis no reemplaza controles de negocio, pruebas dinámicas ni la revisión de hotspots. Las pruebas demostraron riesgos que siguen abiertos.

## ¿Por qué JMeter falla si todas las peticiones fueron exitosas?

El éxito HTTP y la latencia son criterios diferentes. Hubo cero errores HTTP, pero p95 cercano a cinco segundos frente al objetivo histórico menor a 300 ms. El resultado incumple ese criterio de desempeño.

## ¿Agregar la IP resuelve la auditoría?

Resuelve el caso de IP de la ruta y conexión evaluadas. No elimina los permisos de modificación ni garantiza atomicidad. FIN-14 y FIN-15 siguen fallando. Un proxy también requiere una política explícita de confianza.

## ¿Confirmaste SQLi o IDOR?

No confirmé SQLi en el archivo y línea del planteamiento inicial. El intento de login fue rechazado y los escenarios de acceso entre pacientes también se bloquearon. La conclusión se limita a esas pruebas; no demuestra ausencia de riesgos en todos los recursos.

## ¿Está implementado todo el pipeline de GitHub Actions?

No. La campaña acreditada es local. Actions, Jest, Cypress y SCA son ampliaciones del plan sin una corrida acreditada aquí. La siguiente etapa debe integrar servicios, secretos protegidos, reportes y condiciones de bloqueo por versión.

## ¿El informe certifica el cumplimiento de las leyes chilenas?

No. Relaciona controles técnicos con protección de datos y ciberseguridad. Al corte del 17 de noviembre se distingue el régimen aplicable de la transición de la Ley 21.719. La evaluación legal completa requiere revisar el tratamiento y el ámbito de la organización.

## Fuente de los requisitos de exposición

EP6_ISY1102_Estudiante Presentación.docx, apartados Descripción, Consideraciones para la presentación e indicadores IE2, IE4, IE6, IE8 e IE10. Instrucción adicional del docente proporcionada por la estudiante: entrega de informe, diapositivas y video. Las sugerencias de cámara, demostración y distribución por minuto de esta guía son recomendaciones prácticas.
