# Guion de defensa y video

10 minutos + 5 minutos de preguntas.


## 1. Cuidarte+ | decisión de liberación
Antonella · 00:00–01:00

- Antonella Cuvertino · Duoc UC · Ingeniería Informática, Desarrollo de Software.

- 20 casos en versión original y versión con cambios.

- Pruebas → causa → corrección → retest → pendientes.

- Producción BLOQUEADA: mejorar no equivale a cerrar todas las reservas.

Visual: Tarjeta de decisión con bloqueo de producción y responsable individual.

Buenos días. Soy Antonella Cuvertino. Presento una campaña real de pruebas de Cuidarte+, comparando la versión original y una versión con correcciones. El objetivo no es convertir todos los tests en verde, sino validar requisitos, explicar fallos, intentar cambios justificados y comprobar sus efectos. Incorporé el feedback del profesor: señalaré requisito, evidencia y prioridad. Diseñé veinte casos y la automatización asistida los ejecutó en dos bases QA con datos sintéticos. Mostraré resultados que mejoran y otros que permanecen abiertos. Los informes y capturas distinguen evidencia medida de controles todavía propuestos. El dictamen académico mantiene producción bloqueada hasta resolver y verificar las reservas.


## 2. Arquitectura y alcance de la evidencia
Antonella · 01:00–02:00

- App QA: http://127.0.0.1:3344/login.

- Actividad: admin / Admin y medico / medico; mayúsculas exactas.

- APIs antes 4446 / después 4447; PostgreSQL QA 15444.

- Cuentas recreadas solo en QA; 3333 es el entorno histórico.

Visual: Diagrama de cuatro nodos con puertos de host y contenedor diferenciados.

Para comparar preparé dos bases independientes en el mismo PostgreSQL de laboratorio, publicado en el puerto quince mil cuatrocientos cuarenta y cuatro. La API original corre en cuatro cuatro cuatro seis y la corregida en cuatro cuatro cuatro siete. Ambas reciben los mismos roles y datos sintéticos. La interfaz de práctica usa tres tres cuatro cuatro y apunta a la corregida. El snapshot anterior se conserva, así que no confundimos resultados antes y después ni probamos sobre historias clínicas reales. La primera corrida quedó bloqueada por timeout durante presión de memoria; la conservé como incidencia de entorno y repetí sin alterar el criterio. Los JSON identifican fecha, entorno y código.


## 3. Automatización local y trazabilidad
Antonella · 02:00–03:00

- Snapshot + requisitos + datos QA → Node / Postman.

- JMeter → ZAP pasivo → SonarQube del código actual.

- Cada resultado enlaza fecha, artefacto e incidencia.

- Gate humano: reservas abiertas bloquean producción.

Visual: Flujo por etapas con gate que conecta permisos, datos sintéticos y trazabilidad.

El diagrama representa la automatización local. Se fijó la versión del código y se prepararon datos sintéticos. Node y Postman validaron respuestas, permisos y persistencia; JMeter midió carga y estrés; ZAP examinó respuestas en ejecución y SonarQube analiza patrones del código. Cada resultado se enlaza a su fecha, artefacto e incidencia antes de redactar conclusiones. Los datos sintéticos y la exclusión de tokens protegen confidencialidad; las consultas posteriores permiten evaluar integridad. Este flujo se ejecutó por etapas para controlar recursos del equipo. GitHub conserva el trabajo, pero Actions sigue como propuesta. La decisión final es humana y mantiene producción bloqueada por defectos abiertos.


## 4. Herramientas: propósito y evidencia
Antonella · 03:00–04:00

- Docker / Node: entorno; VS Code: revisión y diff.

- Postman / Newman: 9 requests y 12 aserciones por fase.

- JMeter: carga 50 y estrés 200; JMX, JTL y HTML.

- ZAP pasivo y SonarQube: alertas / calidad con alcance explícito.

Visual: Matriz de seis herramientas: función, evidencia esperada y estado.

Las herramientas cumplen funciones distintas. Docker y Node sostienen el entorno; Visual Studio Code permite revisar el cambio. Postman mediante Newman ejecutó nueve solicitudes y doce aserciones por fase. No son doce casos distintos. JMeter produjo muestras bajo cincuenta y doscientos hilos virtuales. ZAP examinó respuestas de cuatro rutas, una autenticada; el análisis fue pasivo, no un ataque activo exhaustivo. SonarQube analiza el código actual y no reemplaza la autorización de negocio. Las exportaciones tienen fecha y ruta dentro del ZIP. Automatizar permite repetir el conjunto y conservar evidencia de manera consistente; no afirmo un ahorro porcentual de tiempo manual que no haya medido.


## 5. Resultados reales: antes y después
Antonella · 04:00–05:00

- Node: 20 casos; 8 PASS/12 FAIL →15 PASS/5 FAIL.

- Postman: 12 aserciones; 8 PASS/4 FAIL →11 PASS/1 FAIL.

- Se mantienen criterios; siete mejoras en la campaña Node.

- Registro único: ejecutados con evidencia; pendientes sin conclusiones.

Visual: Indicadores API y SAST con nota sobre gate y discrepancia documental.

La comparación Node conserva veinte casos y sus fechas del dieciséis de noviembre: antes hubo ocho aprobados y doce fallidos; después, quince aprobados y cinco fallidos. Son siete casos que mejoraron, no siete vulnerabilidades diferentes. Hoy Postman corroboró permisos y autenticación con nueve solicitudes y doce aserciones por fase. Pasó de ocho a once aserciones aprobadas; la latencia sigue fallando. Esas unidades no se suman en un porcentaje global. El registro maestro identifica qué se ejecutó, cuándo, qué se obtuvo y qué archivo lo demuestra. De esta manera resuelvo la contradicción entre pruebas proyectadas y resultados medidos del informe anterior. Lo pendiente permanece sin conclusión de ejecución.


## 6. Permisos: defecto, parche y regresión
Antonella · 05:00–06:00

- FIN-08: borrado anónimo 200 y fila eliminada → exigir 401 e intacta.

- FIN-11: médico obtiene admin → exigir 403 y rol conservado.

- FIN-20: paciente crea admin → exigir 403 y sin nueva cuenta.

- FIN-10: admin legítimo sigue operando y registra su ID numérico.

Visual: Matriz estado / prioridad / corrección / criterio de cierre.

El requisito NFR de control de acceso se valida con acciones concretas. En FIN ocho, el anónimo eliminó una cuenta y recibió doscientos. El parche agrega autenticación y rol administrador antes de mutar; el retest debe responder cuatrocientos uno y conservar la fila. FIN once demostró que el médico podía asignarse admin al enviar un perfil válido. Se restringió la edición de roles a administradores y se verificó el rol posterior. FIN veinte detectó otra ruta: un paciente podía crear una cuenta admin. Se protegió también el alta. FIN diez verifica la operación legítima y corrige el actor de auditoría: antes se enviaba un nombre a una columna numérica. La prioridad deriva del daño no autorizado.


## 7. Auditoría: una corrección parcial
Antonella · 06:00–07:00

- FIN-13: columna IP + req.ip; el encabezado falso no se toma como origen.

- FIN-14: el rol QA aún puede modificar eventos → FAIL.

- FIN-15: si falla auditoría, el cambio de rol permanece → FAIL.

- Próximo cambio: mínimo privilegio y transacción completa en PUT.

Visual: Cliente → proxy confiable → Express → transacción → auditoría protegida.

La auditoría muestra por qué no debo declarar resuelto todo un servicio por una sola captura verde. Agregué ip_origen y el evento de actualización médica usa req.ip. El caso trece comprueba que un encabezado de origen falso no se adopta cuando no hay proxy confiable configurado. Sin embargo, el caso catorce demuestra que el rol usado en QA todavía puede editar auditoria. El caso quince provoca un rechazo controlado del evento, solo en el laboratorio: el PUT devuelve quinientos, pero el rol ya cambió porque no hay una transacción completa. Por eso la corrección es parcial. La transacción agregada al borrado no resuelve automáticamente el cambio de rol. Faltan permisos mínimos y atomicidad en esa ruta.


## 8. JMeter real: carga y estrés
Antonella · 07:00–08:00

- 50 usuarios: 350 muestras; p95 5031 ms; HTTP errores 0.

- 200 usuarios: 1727 muestras; p95 5034 ms; HTTP errores 0.

- Se observaron 200 hilos; duración y perfil registrados.

- delayMiddleware(5000) explica la espera; no un índice faltante.

Visual: Barra comparativa objetivo 300 ms / demora artificial 5.000 / p95 8.698.

JMeter ejecutó dos perfiles reales, carga con cincuenta usuarios y estrés con doscientos. Las muestras confirman el máximo de hilos alcanzado. No hubo errores HTTP, pero p95 estuvo cerca de cinco segundos, superior al criterio histórico de trescientos milisegundos. Por eso la prueba de rendimiento falla aunque la respuesta sea doscientos. La ruta incorpora delayMiddleware de cinco mil milisegundos, una causa coherente con el resultado. El escenario usa una operación y un token QA compartido: no representa todas las tareas clínicas ni doscientas cuentas diferentes. Conservé JMX, JTL y HTML. No atribuyo estas mediciones a la ráfaga Node anterior ni las interpreto como capacidad productiva sostenida.


## 9. Normativa: controles verificables
Antonella · 08:00–09:00

- ZAP: 6 tipos de alerta; revisión contextual, no intrusión probada.

- Sonar de cierre: EJECUTADA; ver tarea y métricas actuales.

- Ley 19.628 aplicable; transición Ley 21.719: 01 dic 2026.

- Ley 21.663 según sujeto; ISO y WCAG no certificados por scanner.

Visual: Matriz norma → control → evidencia y línea temporal de transición.

Los resultados se interpretan según su alcance. ZAP encontró alertas de CORS y cabeceras, además de una alerta informativa; no equivalen automáticamente a intrusiones. SonarQube aporta la tarea y las métricas de su análisis, sin sustituir los defectos de ejecución. La Ley diecinueve mil seiscientos veintiocho es aplicable hoy. La entrada general de las modificaciones de la Ley veintiún mil setecientos diecinueve figura el primero de diciembre de dos mil veintiséis en la fuente oficial consultada. En ciberseguridad deben verificarse los sujetos obligados y la significancia del incidente; no todo bug se reporta a ANCI. ISO e indicadores de accesibilidad guían criterios, pero una captura o un scanner no certifican cumplimiento integral.


## 10. Reservas, mantenimiento y cierre
Antonella · 09:00–10:00

- Mejoras verificadas por caso, no certificación completa.

- Reservas abiertas: auditoría, baja lógica, credenciales y rendimiento.

- Cada corrección futura debe repetir caso afectado y regresión.

- Dictamen académico con reservas; producción sigue BLOQUEADA.

Visual: Gate cerrado y hoja de ruta: corregir → retestar → revisar → autorizar.

Concluyo que hubo mejoras verificables en permisos y parte de la auditoría, pero siguen existiendo reservas demostradas. El reporte no reduce la evaluación a listar herramientas ni afirma que todos los errores se arreglaron. Para cada caso puedo mostrar requisito, resultado inicial, causa, archivo cambiado, retest y estado final. Las correcciones pendientes necesitan una iteración coherente: privacidad de credenciales, conservación clínica, auditoría protegida y transaccional, y rendimiento sin demora artificial. El plan de mantenimiento exige regresión por cambio y evidencias por versión. Mantengo certificado con reservas como denominación académica solicitada y bloqueo de producción. La mejora medida no equivale a certificación legal ni autorización de uso clínico.


## Pregunta 1: ¿Por qué siguen quedando errores si ya hicieron correcciones?

Se aplicaron cambios acotados y se mantuvieron los mismos oráculos. 7 casos pasaron de FAIL a PASS y 5 permanecen FAIL. No se afirma que lo no abordado sea imposible de corregir. El parche de IP no resuelve permisos de auditoría ni atomicidad; hash, baja lógica y rendimiento requieren otra intervención coherente. Cada pendiente tiene causa y propuesta de retest. Producción permanece bloqueada.

Apoyo: JSON antes/después y matriz FIN-01 a FIN-20.


## Pregunta 2: ¿Dónde está exactamente la SQLi de la línea 42 y por qué no la detectó SonarQube?

No podemos afirmar ese hallazgo: BACKEND/src/controllers/examenes.controller.js no existe en el árbol revisado. En BACKEND/src/routes/examenes.js se observan parámetros $1/$2 y campos dinámicos limitados por una lista permitida. node-postgres separa datos del SQL; una prepared statement con nombre no es requisito para que esa parametrización sea segura. Los identificadores dinámicos necesitan allowlist. Debemos identificar versión, entrada y consulta insegura antes de atribuir SQLi. Cero vulnerabilidades SAST detectadas no elimina puntos ciegos ni sustituye pruebas manuales y DAST.

Apoyo: T1, examen de rutas; no hay prueba SQLi ejecutada.


## Pregunta 3: ¿Cómo saben que el médico escaló si el test anterior devolvía 400?

La campaña nueva corrigió la precondición del test: envió nombre_usuario válido junto con rol_id. FIN-11 llegó a la autorización, respondió 200 en la versión original y la consulta a usuario_roles mostró admin. El retest del mismo payload verifica 403 y medico. No se alteró el resultado antiguo ni se lo presenta retroactivamente como exitoso. FIN-06 devuelve 404 al paciente ajeno y no expone diagnosis; es un control distinto del escalamiento.

Apoyo: FIN-11 y FIN-06; hashes y diff de users.js.


## Pregunta 4: ¿Un trigger puede guardar la IP real e impedir cualquier modificación de la auditoría?

No por sí solo. La base ve la conexión de Express, no la IP HTTP del paciente. Express valida el origen según proxies confiables y pasa actor, request_id e IP a una transacción en una sola conexión; si se usa un trigger, este lee ese contexto transaccional. No se confía ciegamente en X-Forwarded-For ni en inet_client_addr como IP final. Se revocan UPDATE/DELETE al rol de aplicación, se limita quién puede insertar y se agrega copia externa con integridad y retención. Un superusuario de la base sigue siendo un límite de confianza: no prometemos inmutabilidad absoluta.

Apoyo: T2, init.sql:87–93. Propuesta pendiente de implementación.


## Pregunta 5: ¿Qué ley está vigente y debemos reportar cada error a la ANCI?

Al 17 de noviembre de 2026 distinguimos la Ley 19.628 aplicable y la transición de la Ley 21.719, cuya vigencia general figura el 1 de diciembre de 2026 en la fuente oficial consultada. En ciberseguridad debemos determinar si la organización es sujeto obligado; un centro de salud y un proveedor de software no se califican automáticamente de la misma forma. No todo defecto es un incidente significativo. Para sujetos obligados, ante uno de esos incidentes corresponde la alerta temprana dentro de tres horas desde su conocimiento, y las actualizaciones aplicables. La omisión de IP no genera por sí sola una multa automática ni un reporte.

Apoyo: L1–L4. Revalidar vigencia si cambia la fecha de defensa.


## Pregunta 6: ¿Por qué JMeter tiene cero errores HTTP pero la prueba falla?

HTTP 200 indica respuesta funcional, no cumplimiento del tiempo. El JTL registra cero errores HTTP y p95 de unos cinco segundos, superior al objetivo histórico <300 ms. La ruta tiene una demora explícita de 5000 ms. Los perfiles alcanzaron los hilos configurados, pero usan un token QA compartido y una operación, no toda la experiencia clínica ni capacidad productiva prolongada.

Apoyo: JM-01/JM-02, JTL, HTML y código de delay.


## Pregunta 7: ¿Cómo distingues ZAP, SonarQube y Postman sin mezclar resultados?

ZAP observa respuestas de la aplicación en ejecución: aquí DAST pasivo con alertas a revisar. SonarQube estudia patrones del código y deuda técnica. Postman compara HTTP, contenido y tiempos contra aserciones. Una alerta no equivale automáticamente a explotación y un gate verde no sustituye un requisito dinámico fallido. El registro conserva unidades, fecha y artefacto por herramienta; no hay un porcentaje global inventado.

Apoyo: registro maestro y exportaciones de cada herramienta.


## Pregunta 8: ¿La minimización obliga a borrar exámenes y unas pruebas visuales bastan para WCAG AA?

La minimización exige justificar finalidad, campos, permisos y retención; no equivale a borrar indiscriminadamente información clínica. La conservación y los derechos de titulares deben conciliarse con obligaciones sectoriales aplicables, que deben revisarse por separado. Soft delete conserva la fila y reduce pérdida accidental, pero no sustituye una política de supresión ni backups. WCAG 2.1 AA requiere todos los criterios A y AA del alcance: teclado, foco, contraste, etiquetas y errores, entre otros. Automatización parcial y tamaño de letra no bastan; faltan evaluación manual, tecnologías de apoyo y evidencias por criterio.

Apoyo: L1–L2, T4; CP-API-007. No se declara conformidad WCAG completa.

La entrega audiovisual debe mostrar participación real de Antonella Cuvertino. Este paquete no contiene un video ni simula su voz o participación. Grabar con las 10 láminas y el mismo reparto de un minuto por lámina; si el docente fija otra duración para el video, ajustar ese requisito específico. No hay duración de video independiente confirmada en el mensaje recibido.

Preparación: abrir 02_Presentacion_EP6.pdf o el PPTX editable, probar micrófono y compartir una sola ventana. Usar MP4 con pantalla legible (preferentemente 1920×1080) y audio claro. Es una recomendación técnica, no una exigencia adicional de la pauta. No mostrar claves de SonarQube, .env, tokens ni información de pacientes reales.

Storyboard individual: 00:00–01:00 Antonella se presenta y explica la decisión; 01:00–02:00 explica arquitectura; continúa con un minuto por lámina hasta 10:00. Mostrar rostro o identificación según la modalidad de grabación elegida y explicar personalmente el contenido técnico.

La exposición de 10 minutos ya ocupa todo el tiempo. La demo en vivo no se añade sin recortar: si la eligen, reemplazar 30–40 segundos de la lámina 5 por la ejecución preparada de Ejecutar-Pruebas.ps1 y explicar el FAIL de borrado. No ejecutar carga, escaneos ni arranques pesados durante la defensa. Ante fallo de entorno, volver a JSON/PDF identificado como evidencia histórica, sin afirmar que se ejecutó en ese momento.

Ensayo de preguntas (5 minutos): practicar respuestas de 30–40 segundos a cuatro o cinco preguntas elegidas del banco. Antonella debe poder responder preguntas sobre las 10 láminas. Cuando falte evidencia, responder: no está acreditado; este es el control propuesto y este es el artefacto que falta.

Antes de subir: revisar nombre, carrera y fecha; reproducir todo el MP4 para verificar audio y participación; comprobar que los PDF y PPTX coinciden; confirmar en AVA el apartado EP6 indicado por el docente y las restricciones de tamaño/formato. Entregar el informe, las diapositivas utilizadas y el video. El ZIP es soporte adicional si el docente lo admite, no reemplaza esos tres elementos.