const { Pool } = require("pg");
require("dotenv").config();
if (!process.env.DATABASE_URL) throw new Error("Define DATABASE_URL para tu base QA");
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
module.exports = { pool };
