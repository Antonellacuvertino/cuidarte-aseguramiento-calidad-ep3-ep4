const jwt = require("jsonwebtoken");
const { pool } = require("../db");

// Consultar roles vigentes en la base; no confiar en el rol incluido en un JWT antiguo.
module.exports = async function requireAdmin(req, res, next) {
  const header = req.headers.authorization || "";
  let actor;
  try {
    if (!header.startsWith("Bearer ")) throw new Error("Falta sesión");
    actor = jwt.verify(header.slice(7), process.env.JWT_SECRET || "inseguro");
    if (!actor.usuarioId) throw new Error("Falta actor");
  } catch {
    return res.status(401).json({ error: "No autorizado" });
  }
  try {
    const roles = await pool.query(
      `SELECT r.nombre FROM usuario_roles ur
       JOIN roles r ON r.id = ur.rol_id WHERE ur.usuario_id = $1`,
      [actor.usuarioId]
    );
    if (!roles.rows.some((r) => ["admin", "administrador"].includes(r.nombre))) {
      return res.status(403).json({ error: "Solo administradores" });
    }
    req.authUser = actor;
    return next();
  } catch (err) {
    console.error("No se pudieron verificar permisos", err.code);
    return res.status(500).json({ error: "No se pudieron verificar permisos" });
  }
};
