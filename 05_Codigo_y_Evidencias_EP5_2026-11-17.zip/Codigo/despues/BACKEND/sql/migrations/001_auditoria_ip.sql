-- Aplicar de forma explícita en una base existente antes de iniciar esta versión.
-- Este cambio registra origen; NO implementa inmutabilidad ni atomicidad del cambio de rol.
ALTER TABLE auditoria ADD COLUMN IF NOT EXISTS ip_origen INET;
