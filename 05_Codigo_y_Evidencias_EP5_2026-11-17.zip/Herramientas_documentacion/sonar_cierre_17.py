from pathlib import Path
import urllib.request,urllib.parse,base64,json,subprocess,os,time,shutil,datetime
root=Path(__file__).resolve().parents[1];lab=root/'03_LABORATORIO_FINAL';out=lab/'herramientas/SonarQube';out.mkdir(parents=True,exist_ok=True)
base='http://127.0.0.1:9000';project='cuidarte-ep5-20261117';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
cred=json.loads((root/'.qa_tools/sonar_state.json').read_text(encoding='utf-8'));auth=cred['token']+':'
def api(path,data=None):
 headers={'Authorization':'Basic '+base64.b64encode(auth.encode()).decode()}
 req=urllib.request.Request(base+path,data=urllib.parse.urlencode(data).encode() if data is not None else None,headers=headers)
 with urllib.request.urlopen(req,timeout=90) as r:
  text=r.read();return json.loads(text) if text else {}
try:
 ready=False
 for i in range(150):
  try:
   status=json.load(urllib.request.urlopen(base+'/api/system/status',timeout=10))
   if status.get('status')=='UP':ready=True;break
  except Exception:pass
  if i%15==0:print('Esperando inicio de SonarQube...',flush=True)
  time.sleep(2)
 if not ready:raise TimeoutError('SonarQube no está UP')
 print('Servidor UP; validando acceso local...',flush=True)
 if not api('/api/authentication/validate').get('valid'):
  auth='admin:'+cred['password']
  if not api('/api/authentication/validate').get('valid'):raise RuntimeError('Las credenciales locales no corresponden a esta instancia')
  new=api('/api/user_tokens/generate',{'name':'ep5-20261117-'+str(int(time.time()))});cred['token']=new['token'];auth=cred['token']+':'
  (root/'.qa_tools/sonar_cierre_state.json').write_text(json.dumps(cred),encoding='utf-8')
 print('Acceso válido; preparando proyecto de cierre...',flush=True)
 try:api('/api/projects/create',{'project':project,'name':'Cuidarte+ EP5 - cierre 17 noviembre 2026','visibility':'private'})
 except urllib.error.HTTPError as e:
  if e.code!=400:raise
 source=root/'.qa_tools/sonar_cierre_fuente';source.mkdir(exist_ok=True)
 for name in ['BACKEND','FRONTEND']:
  dest=source/name/'src';dest.parent.mkdir(exist_ok=True);shutil.copytree(root/name/'src',dest,dirs_exist_ok=True)
 (source/'sonar-project.properties').write_text(f'sonar.projectKey={project}\nsonar.projectName=Cuidarte EP5 cierre\nsonar.projectVersion=EP5-2026-11-17\nsonar.sources=BACKEND/src,FRONTEND/src\nsonar.sourceEncoding=UTF-8\nsonar.exclusions=**/node_modules/**\n',encoding='utf-8')
 env={**os.environ,'SONAR_TOKEN':cred['token']}
 cmd=['docker.exe','run','--rm','--name','cuidarte-final-scanner','--memory=768m','--cpus=1','-e','SONAR_TOKEN','-e','SONAR_SCANNER_JAVA_OPTS=-Xmx256m','-e','SONAR_HOST_URL=http://host.docker.internal:9000','-v',str(source)+':/usr/src','sonarsource/sonar-scanner-cli:latest','-Dsonar.javascript.node.maxspace=256','-Dsonar.scanner.skipJreProvisioning=true']
 print('Ejecutando escáner oficial sobre código actual...',flush=True)
 with (out/'scanner.log').open('w',encoding='utf-8') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 if p.returncode:raise RuntimeError('El scanner no terminó correctamente; ver scanner.log')
 props=dict(line.split('=',1) for line in (source/'.scannerwork/report-task.txt').read_text().splitlines() if '=' in line)
 task=None
 for _ in range(120):
  task=api('/api/ce/task?id='+props['ceTaskId'])
  if task['task']['status'] in ['SUCCESS','FAILED','CANCELED']:break
  time.sleep(2)
 if task['task']['status']!='SUCCESS':raise RuntimeError('Tarea de análisis: '+task['task']['status'])
 metrics='bugs,vulnerabilities,security_hotspots,code_smells,coverage,ncloc,duplicated_lines_density,security_hotspots_reviewed'
 for filename,path in [('metricas.json','/api/measures/component?component='+project+'&metricKeys='+metrics),('quality_gate.json','/api/qualitygates/project_status?projectKey='+project),('issues.json','/api/issues/search?componentKeys='+project+'&ps=500'),('hotspots.json','/api/hotspots/search?projectKey='+project+'&ps=500')]:
  (out/filename).write_text(json.dumps(api(path),ensure_ascii=False,indent=2),encoding='utf-8')
 (out/'tarea.json').write_text(json.dumps(task,indent=2),encoding='utf-8')
 result={'id':'SAST-01','state':'EJECUTADA','date_start_utc':start,'date_end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tool':'SonarQube '+status.get('version','9.9'),'project':project,'dashboard':base+'/dashboard?id='+project,'ce_status':task['task']['status'],'metrics':{m['metric']:m.get('value') for m in json.loads((out/'metricas.json').read_text(encoding='utf-8'))['component']['measures']},'quality_gate':json.loads((out/'quality_gate.json').read_text(encoding='utf-8'))['projectStatus'],'scope':'Código actual BACKEND/src y FRONTEND/src; no se importó LCOV. No se ejecuta el código durante SAST.'}
 (root/'.qa_tools/Acceso_Sonar_EP5.txt').write_text('Panel: '+result['dashboard']+'\nUsuario: admin\nClave local: '+cred['password']+'\nNo publicar ni incluir en capturas.\n',encoding='utf-8')
except Exception as e:result={'id':'SAST-01','state':'BLOCKED','date_start_utc':start,'reason':str(e),'project':project}
(lab/'resultados/sonar_actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
