from pathlib import Path
import urllib.request,urllib.parse,json,subprocess,time,secrets,datetime,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1];lab=root/'03_LABORATORIO_FINAL';out=lab/'herramientas/ZAP';out.mkdir(parents=True,exist_ok=True)
home=lab/'.runtime/zap_home';home.mkdir(exist_ok=True);key=secrets.token_urlsafe(24);base='http://127.0.0.1:8091';target='http://127.0.0.1:4447'
def api(part,params=None,raw=False):
 q=urllib.parse.urlencode({'apikey':key,**(params or {})});r=urllib.request.urlopen(base+part+'?'+q,timeout=20);data=r.read();return data if raw else json.loads(data)
jar=root/'.qa_tools/herramientas/zap/ZAP_2.17.0/zap-2.17.0.jar'
log=(lab/'.runtime/zap-console.log').open('w',encoding='utf-8');proc=None;start=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 ready=False
 config=home/'config.xml'
 if config.exists():
  saved=ET.parse(config).findtext('.//api/key')
  if saved:
   key=saved
   try:version=api('/JSON/core/view/version/');ready=True
   except Exception:pass
 if not ready:
  proc=subprocess.Popen(['java','-Xms128m','-Xmx384m','-jar',str(jar),'-daemon','-host','127.0.0.1','-port','8091','-dir',str(home),'-config','api.key='+key,'-config','autoupdate.checkOnStart=false','-config','autoupdate.installAddonUpdates=false'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
  (lab/'.runtime/zap_control.json').write_text(json.dumps({'pid':proc.pid,'key':key}),encoding='utf-8')
 for _ in range(120):
  if ready:break
  try:version=api('/JSON/core/view/version/');ready=True;break
  except Exception:
   if proc.poll() is not None:raise RuntimeError('ZAP terminó durante el inicio; ver log privado')
   time.sleep(2)
 if not ready:raise TimeoutError('ZAP no terminó de iniciar')
 auth=urllib.request.Request(target+'/autenticacion/login',data=json.dumps({'nombre_usuario':'admin','password':'Admin'}).encode(),headers={'Content-Type':'application/json'})
 token=json.load(urllib.request.urlopen(auth,timeout=20))['token']
 # SendRequest hace pasar solicitudes concretas por el motor ZAP; no se ejecuta un ataque activo global.
 for path in ['/','/openapi.json','/docs/','/examenes']:
  request=f'GET {target+path} HTTP/1.1\r\nHost: 127.0.0.1:4447\r\n'+(('Authorization: Bearer '+token+'\r\n') if path=='/examenes' else '')+'\r\n'
  api('/JSON/core/action/sendRequest/',{'request':request,'followRedirects':'true'})
 for _ in range(45):
  if int(api('/JSON/pscan/view/recordsToScan/')['recordsToScan'])==0:break
  time.sleep(1)
 alerts=api('/JSON/core/view/alerts/',{'baseurl':target,'start':'0','count':'500'})
 text=json.dumps(alerts,ensure_ascii=False,indent=2).replace(token,'[JWT_OCULTO]').replace(key,'[API_KEY_OCULTA]')
 (out/'alertas_zap.json').write_text(text,encoding='utf-8')
 html=api('/OTHER/core/other/htmlreport/',raw=True).decode('utf-8').replace(token,'[JWT_OCULTO]').replace(key,'[API_KEY_OCULTA]')
 (out/'reporte_zap.html').write_text(html,encoding='utf-8')
 counts={};distinct={}
 for a in alerts.get('alerts',[]):
  risk=a.get('risk','Unknown');counts[risk]=counts.get(risk,0)+1;distinct[a['pluginId']]={'id':a['pluginId'],'name':a['alert'],'risk':risk,'confidence':a.get('confidence'),'url':a.get('url'),'evidence':a.get('evidence'),'solution':a.get('solution')}
 result={'id':'ZAP-01','state':'EJECUTADA','result':'COMPLETADA CON ALERTAS' if distinct else 'COMPLETADA SIN ALERTAS EN ESTE ALCANCE','date_start_utc':start,'date_end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tool':'OWASP ZAP '+version['version'],'scope':'DAST pasivo sobre cuatro rutas conocidas; GET /examenes con JWT QA. No es escaneo activo ni validación exhaustiva de IDOR/SQLi.','alert_instances':len(alerts.get('alerts',[])),'alert_types':len(distinct),'risk_instance_counts':counts,'alerts':list(distinct.values()),'remaining_passive_records':api('/JSON/pscan/view/recordsToScan/')['recordsToScan']}
except Exception as e:result={'id':'ZAP-01','state':'BLOCKED','date_start_utc':start,'reason':str(e)}
finally:
 try:api('/JSON/core/action/shutdown/')
 except Exception:pass
 if proc:
  try:proc.wait(timeout=15)
  except subprocess.TimeoutExpired:proc.terminate()
 log.close()
(lab/'resultados/zap_actual.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8');print(json.dumps(result,indent=2,ensure_ascii=False))
