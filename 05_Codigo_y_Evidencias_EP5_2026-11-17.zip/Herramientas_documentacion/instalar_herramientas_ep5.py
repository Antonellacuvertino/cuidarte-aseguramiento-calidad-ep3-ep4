from pathlib import Path
import urllib.request,hashlib,zipfile,json,time,concurrent.futures
root=Path(__file__).resolve().parents[1];dest=root/'.qa_tools/herramientas';dest.mkdir(exist_ok=True)
items=[('jmeter','https://dlcdn.apache.org/jmeter/binaries/apache-jmeter-5.6.3.zip','sha512','387fadca903ee0aa30e3f2115fdfedb3898b102e6b9fe7cc3942703094bd2e65b235df2b0c6d0d3248e74c9a7950a36e42625fd74425368342c12e40b0163076'),('zap','https://github.com/zaproxy/zaproxy/releases/download/v2.17.0/ZAP_2.17.0_Crossplatform.zip','sha256','94c8f767b1c2e94f0db66b3ae56514d5e3f5a728ee1b6c798e0c8fe2d61fbff0')]
def install(item):
 name,url,algo,digest=item;file=dest/(name+'.zip')
 try:
  if not file.exists() or hashlib.new(algo,file.read_bytes()).hexdigest()!=digest:
   request=urllib.request.Request(url+'?cache='+str(int(time.time())),headers={'User-Agent':'Cuidarte-QA/1.0'})
   with urllib.request.urlopen(request,timeout=90) as r,file.open('wb') as f:
    while chunk:=r.read(1024*1024):f.write(chunk)
  if hashlib.new(algo,file.read_bytes()).hexdigest()!=digest:raise ValueError('No coincide el checksum oficial')
  with zipfile.ZipFile(file) as z:
   if not (dest/name).exists():z.extractall(dest/name)
  return {'tool':name,'status':'INSTALADO','checksum_verified':True,'directory':str(dest/name)}
 except Exception as e:return {'tool':name,'status':'BLOCKED','reason':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(install,items))
(dest/'instalacion.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print(json.dumps(results,indent=2))
