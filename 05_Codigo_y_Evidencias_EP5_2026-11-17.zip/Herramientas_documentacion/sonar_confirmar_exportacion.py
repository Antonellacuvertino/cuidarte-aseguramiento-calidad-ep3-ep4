from pathlib import Path
import json,datetime,urllib.request,base64,concurrent.futures
root=Path(__file__).resolve().parents[1];lab=root/'03_LABORATORIO_FINAL';out=lab/'herramientas/SonarQube';project='cuidarte-ep5-20261117'
current=json.loads((out/'recuperacion_metadata.json').read_text(encoding='utf-8'))['server_current_task'];assert current['status']=='SUCCESS' and current['componentKey']==project
raw=json.loads((out/'metricas.json').read_text(encoding='utf-8'));assert raw['component']['key']==project
gate=json.loads((out/'quality_gate.json').read_text(encoding='utf-8'))['projectStatus']
(out/'tarea.json').write_text(json.dumps({'source_endpoint':'/api/ce/component','task':current},indent=2),encoding='utf-8')
p=root/'.qa_tools/sonar_cierre_state.json';p=p if p.exists() else root/'.qa_tools/sonar_state.json';cred=json.loads(p.read_text(encoding='utf-8'));auth='Basic '+base64.b64encode((cred['token']+':').encode()).decode()
def fetch(item):
 name,path=item
 try:
  with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:9000'+path,headers={'Authorization':auth}),timeout=25) as r:data=json.load(r)
  (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');return{name:'EXPORTADO'}
 except Exception as e:return{name:'EXPORTACION BLOQUEADA: '+type(e).__name__}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:exports=list(pool.map(fetch,[('issues.json','/api/issues/search?componentKeys='+project+'&types=BUG&ps=10'),('hotspots.json','/api/hotspots/search?projectKey='+project+'&ps=10')]))
old=json.loads((lab/'resultados/sonar_actual.json').read_text(encoding='utf-8'))
result={'id':'SAST-01','state':'EJECUTADA','date_start_utc':old['date_start_utc'],'date_end_utc':current['executedAt'],'date_export_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tool':'SonarQube 9.9.8.100196 / scanner oficial','project':project,'dashboard':'http://127.0.0.1:9000/dashboard?id='+project,'ce_status':'SUCCESS','analysis_id':current['analysisId'],'metrics':{m['metric']:m.get('value') for m in raw['component']['measures']},'quality_gate':gate,'detail_exports':exports,'scope':'57 archivos JS y fuentes actuales BACKEND/src + FRONTEND/src; sin LCOV. CE del servidor confirma SUCCESS. El cliente agotó su timeout; la recuperación se documenta. issues.json solicita BUG, no todos los code smells; las métricas sí incluyen el total de la categoría.'}
(lab/'resultados/sonar_actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'.qa_tools/Acceso_Sonar_EP5.txt').write_text('Panel: '+result['dashboard']+'\nUsuario: admin\nClave local: '+cred['password']+'\nNo publicar ni incluir en capturas.\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
