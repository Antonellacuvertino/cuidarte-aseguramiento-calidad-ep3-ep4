from pathlib import Path
import json,time,urllib.request,urllib.parse,base64,datetime,subprocess
root=Path(__file__).resolve().parents[1];lab=root/'03_LABORATORIO_FINAL';out=lab/'herramientas/SonarQube';source=root/'.qa_tools/sonar_cierre_fuente';taskfile=source/'.scannerwork/report-task.txt';project='cuidarte-ep5-20261117'
credfile=root/'.qa_tools/sonar_cierre_state.json'
if not credfile.exists():credfile=root/'.qa_tools/sonar_state.json'
cred=json.loads(credfile.read_text(encoding='utf-8'));auth=base64.b64encode((cred['token']+':').encode()).decode();base='http://127.0.0.1:9000'
def api(path):
 with urllib.request.urlopen(urllib.request.Request(base+path,headers={'Authorization':'Basic '+auth}),timeout=90) as r:return json.load(r)
old=json.loads((lab/'resultados/sonar_actual.json').read_text(encoding='utf-8'));(lab/'resultados/sonar_intento3_cliente_timeout.json').write_text(json.dumps(old,indent=2),encoding='utf-8')
try:
 for i in range(180):
  if taskfile.exists():break
  if i%15==0:print('El scanner sigue en segundo plano; esperando report-task.txt...',flush=True)
  time.sleep(2)
 if not taskfile.exists():raise TimeoutError('No se obtuvo tarea del scanner en el plazo adicional')
 props=dict(x.split('=',1) for x in taskfile.read_text().splitlines() if '=' in x)
 for i in range(120):
  task=api('/api/ce/task?id='+props['ceTaskId']);status=task['task']['status']
  if status in ['SUCCESS','FAILED','CANCELED']:break
  time.sleep(2)
 if status!='SUCCESS':raise RuntimeError('Compute Engine: '+status)
 metrics='bugs,vulnerabilities,security_hotspots,code_smells,coverage,ncloc,duplicated_lines_density,security_hotspots_reviewed'
 for filename,path in [('metricas.json','/api/measures/component?component='+project+'&metricKeys='+metrics),('quality_gate.json','/api/qualitygates/project_status?projectKey='+project),('issues.json','/api/issues/search?componentKeys='+project+'&ps=500'),('hotspots.json','/api/hotspots/search?projectKey='+project+'&ps=500')]:
  (out/filename).write_text(json.dumps(api(path),ensure_ascii=False,indent=2),encoding='utf-8')
 (out/'tarea.json').write_text(json.dumps(task,indent=2),encoding='utf-8')
 result={'id':'SAST-01','state':'EJECUTADA','date_start_utc':old['date_start_utc'],'date_end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tool':'SonarQube 9.9.8.100196 / scanner oficial','project':project,'dashboard':base+'/dashboard?id='+project,'ce_status':status,'metrics':{m['metric']:m.get('value') for m in json.loads((out/'metricas.json').read_text(encoding='utf-8'))['component']['measures']},'quality_gate':json.loads((out/'quality_gate.json').read_text(encoding='utf-8'))['projectStatus'],'scope':'BACKEND/src y FRONTEND/src actuales; no LCOV. Cliente Docker agotó 300 s, pero el análisis continuó y CE confirmó SUCCESS. No se cambian resultados para ocultar el timeout.'}
 (root/'.qa_tools/Acceso_Sonar_EP5.txt').write_text('Panel: '+result['dashboard']+'\nUsuario: admin\nClave local: '+cred['password']+'\nNo publicar ni incluir en capturas.\n',encoding='utf-8')
except Exception as e:result={**old,'reason':'Recuperación: '+str(e)}
(lab/'resultados/sonar_actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
