# Grabar hoy · 17 noviembre 2026

## Preparación antes de grabar
Abre Docker y comprueba la app QA en http://127.0.0.1:3344/login. Usa admin / Admin o medico / medico, con mayúsculas exactas. Son cuentas de la actividad recreadas en QA. localhost:3333 corresponde al entorno histórico; no cambies de puerto durante la explicación.

## Deja las evidencias ordenadas
Abre Abrir-Evidencias.ps1 y el registro maestro. Ten preparados la presentación, la colección/entorno de Postman, sus JSON, el HTML de JMeter, el reporte ZAP y el panel SonarQube. No inicies una carga larga mientras grabas: muestra la corrida fechada y sus parámetros.

## Prueba técnica de 20 segundos
Con tu grabador de pantalla, registra tu voz y una ventana de prueba. Reproduce el archivo y comprueba audio, legibilidad y ausencia de claves/tokens. La grabación debe mostrar tu participación real. Usa los ajustes y formato que acepte AVA; MP4 es una opción habitual, no una nueva exigencia de la rúbrica.

## Cómo mostrar Postman
Importa herramientas/Postman/Cuidarte_EP5.postman_collection.json y el entorno despues.postman_environment.json. Para la demostración breve elige PM-03 (clave incorrecta), que no modifica datos. Muestra estado y Test Results; evita el cuerpo de un login correcto porque contiene JWT. La corrida automatizada acreditada es Newman y su JSON. Para repetir toda la colección, prepara nuevos objetivos con scripts/postman_real.cjs.

## Cómo mostrar JMeter
Abre el plan estres_200.jmx para enseñar 200 hilos, rampa de 20 s y duración programada de 60 s. Después abre su HTML y JTL. Di: 1727 muestras, máximo observado 200, cero errores HTTP y p95 5034 ms. El objetivo <300 ms falla. No lo confundas con 200 personas ni con una meseta de cinco minutos.

## Cómo mostrar ZAP y SonarQube
ZAP: abre reporte_zap.html, explica 15 instancias/6 tipos y el alcance pasivo de cuatro rutas. No llames intrusión a cada alerta. SonarQube: muestra el proyecto de cierre y la tarea/metricas JSON correspondiente; diferencia bug, smell, hotspot y vulnerabilidad clasificada. Si un análisis figura bloqueado, explica su log y no uses cifras históricas como nuevas.

## Qué captura tomar tú en VS Code
Compara version_antes/BACKEND/src/routes/users.js con BACKEND/src/routes/users.js. Captura requireAdmin, el control isAdmin y usuarioId numérico; para IP muestra la migración y el evento de la rama médica. No captures db.js, .env ni el archivo de acceso privado de SonarQube.

## Cierre y entrega hoy
Concluye con las reservas abiertas: auditoría, baja lógica, credenciales y latencia. No digas que son imposibles de corregir. Graba alrededor de diez minutos como ensayo de la defensa de 10 + 5 de preguntas; la pauta no aporta una duración independiente para el video. Revisa el MP4 completo y sube informe EP5, diapositivas EP6 y video individual en el apartado indicado por el docente.

## Recorrido por minuto
Tiempo | Pantalla | Qué explicar
00:00–01:00 | Lámina 1 | Nombre, evaluación y decisión de no liberar.
01:00–02:00 | Lámina 2 / login | Puertos QA y credenciales exactas de actividad.
02:00–03:00 | Lámina 3 | Diagrama local y controles; Actions pendiente.
03:00–04:00 | Lámina 4 / Postman | Finalidad de herramientas; 9 requests /12 aserciones.
04:00–05:00 | Lámina 5 / comparación | 20 casos Node y diferencia con las aserciones Postman.
05:00–06:00 | Lámina 6 / diff | Permisos corregidos: evidencia antes, código, retest.
06:00–07:00 | Lámina 7 / FIN-15 | IP parcial; rollback y permisos aún fallan.
07:00–08:00 | Lámina 8 / JMeter HTML | 50/200 hilos, p95, cero HTTP errores y SLO fallido.
08:00–09:00 | Lámina 9 / ZAP y Sonar | Alcance de alertas y métricas; límites normativos.
09:00–10:00 | Lámina 10 | Mantenimiento, responsables, reservas y siguiente iteración.