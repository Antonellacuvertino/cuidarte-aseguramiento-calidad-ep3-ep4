const fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'../..');process.env.NODE_PATH=path.join(root,'.qa_tools/api/node_modules');require('module').Module._initPaths();
const newman=require(path.join(root,'.qa_tools/newman/node_modules/newman'));const {Pool}=require('pg');
const lab=path.join(__dirname,'..'),folder=path.join(lab,'herramientas/Postman');fs.mkdirSync(folder,{recursive:true});
function item(name,method,url,body,tests,auth){return{name,event:[{listen:'test',script:{type:'text/javascript',exec:tests}}],request:{method,header:[...(body?[{key:'Content-Type',value:'application/json'}]:[]),...(auth?[{key:'Authorization',value:'Bearer {{'+auth+'}}'}]:[])],url:'{{base}}'+url,...(body?{body:{mode:'raw',raw:JSON.stringify(body)}}:{})}}}
const collection={info:{name:'Cuidarte+ EP5 - Postman con credenciales de actividad',schema:'https://schema.getpostman.com/json/collection/v2.1.0/collection.json'},item:[
item('PM-01 API disponible','GET','/',null,["pm.test('Estado 200',()=>pm.response.to.have.status(200));","pm.test('Servicio ok',()=>pm.expect(pm.response.json().status).eq('ok'));"]),
item('PM-02 Login admin de actividad','POST','/autenticacion/login',{nombre_usuario:'admin',password:'Admin'},["pm.test('Estado 200',()=>pm.response.to.have.status(200));","const t=pm.response.json().token;pm.test('JWT recibido',()=>pm.expect(t).to.be.a('string'));pm.collectionVariables.set('adminToken',t);"]),
item('PM-03 Clave incorrecta','POST','/autenticacion/login',{nombre_usuario:'admin',password:'Incorrecta'},["pm.test('Rechaza credencial: 401',()=>pm.response.to.have.status(401));"]),
item('PM-04 Login medico de actividad','POST','/autenticacion/login',{nombre_usuario:'medico',password:'medico'},["pm.test('Estado 200',()=>pm.response.to.have.status(200));pm.collectionVariables.set('medicoToken',pm.response.json().token);"]),
item('PM-05 Medico no se asigna admin','PUT','/usuarios/{{medicoId}}',{nombre_usuario:'medico',rol_id:1},["pm.test('Cambio de rol denegado: 403',()=>pm.response.to.have.status(403));"],'medicoToken'),
item('PM-06 Admin cambia rol con payload mínimo','PUT','/usuarios/{{destinoId}}',{rol_id:2},["pm.test('Actualización permitida: 200',()=>pm.response.to.have.status(200));"],'adminToken'),
item('PM-07 Rendimiento de listado','GET','/examenes',null,["pm.test('Estado funcional 200',()=>pm.response.to.have.status(200));","pm.test('Latencia menor de 300 ms',()=>pm.expect(pm.response.responseTime).to.be.below(300));"],'adminToken'),
item('PM-08 Sin sesión no elimina usuario','DELETE','/usuarios/{{eliminarId}}',null,["pm.test('Autenticación requerida: 401',()=>pm.response.to.have.status(401));"]),
item('PM-09 Intento SQLi en login','POST','/autenticacion/login',{nombre_usuario:"inexistente' OR '1'='1",password:'Incorrecta'},["pm.test('No evade autenticación: 401',()=>pm.response.to.have.status(401));"])
]};
fs.writeFileSync(path.join(folder,'Cuidarte_EP5.postman_collection.json'),JSON.stringify(collection,null,2));
async function main(){
for(const phase of ['antes','despues']){
 const pool=new Pool({connectionString:`postgres://qa:qa_final_sintetica@127.0.0.1:15444/cuidarte_final_${phase}`});
 try{
 const db=await pool.query('SELECT current_database() AS db');if(db.rows[0].db!==`cuidarte_final_${phase}`)throw Error('Solo QA');
 const medico=(await pool.query("SELECT id FROM usuarios WHERE nombre_usuario='medico'")).rows[0].id;
 const ids={};for(const key of ['destino','eliminar']){const name=`pm_${key}_${Date.now()}`;const q=await pool.query('INSERT INTO usuarios(nombre_usuario,contrasena,correo) VALUES($1,$2,$3) RETURNING id',[name,'DemoCuidarte2026!',name+'@example.test']);ids[key]=q.rows[0].id;await pool.query('INSERT INTO usuario_roles(usuario_id,rol_id) VALUES($1,3)',[ids[key]]);}
 const environment={name:'Cuidarte QA '+phase,values:[{key:'base',value:'http://127.0.0.1:'+(phase==='antes'?4446:4447),enabled:true},{key:'medicoId',value:medico,enabled:true},{key:'destinoId',value:ids.destino,enabled:true},{key:'eliminarId',value:ids.eliminar,enabled:true}]};
 fs.writeFileSync(path.join(folder,phase+'.postman_environment.json'),JSON.stringify(environment,null,2));
 const summary=await new Promise((resolve,reject)=>newman.run({collection,environment,reporters:[],timeoutRequest:20000},(e,s)=>e?reject(e):resolve(s)));
 const executions=summary.run.executions.map(e=>({id:e.item.name.split(' ')[0],name:e.item.name,http:e.response?.code,response_ms:e.response?.responseTime,assertions:(e.assertions||[]).map(a=>({name:a.assertion,status:a.error?'FAIL':'PASS',...(a.error?{message:a.error.message}:{})})),...(e.requestError?{error:e.requestError.message}:{})}));
 const output={phase,date_utc:new Date().toISOString(),tool:'Postman Collection v2.1 ejecutada con Newman',version:require(path.join(root,'.qa_tools/newman/node_modules/newman/package.json')).version,stats:summary.run.stats,executions,scope:'Credenciales de actividad recreadas exclusivamente en QA; JWT y cuerpos de login excluidos de este reporte.'};
 fs.writeFileSync(path.join(lab,'resultados','postman_'+phase+'.json'),JSON.stringify(output,null,2));console.log(phase,JSON.stringify(output.stats));
 }finally{
  await pool.query('DELETE FROM usuario_roles WHERE usuario_id=(SELECT id FROM usuarios WHERE nombre_usuario=$1)',['medico']);await pool.query("INSERT INTO usuario_roles(usuario_id,rol_id) SELECT id,2 FROM usuarios WHERE nombre_usuario='medico'");await pool.end();
 }
}
}
main().catch(e=>{console.error(e.message);process.exitCode=1});
