const path=require('path'),fs=require('fs');const root=path.resolve(__dirname,'../..');process.env.NODE_PATH=path.join(root,'.qa_tools/api/node_modules');require('module').Module._initPaths();const{chromium}=require('playwright');
const lab=path.join(__dirname,'..'),results=[];
async function main(){
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',args:['--disable-gpu','--renderer-process-limit=1']});
 try{const context=await browser.newContext({viewport:{width:1440,height:1000}});const page=await context.newPage();
  const jm=JSON.parse(fs.readFileSync(path.join(lab,'resultados/jmeter_actual.json')));
  const cases=[['11_jmeter_200.png','http://127.0.0.1:8799/'+jm.results[1].evidence_directory.replaceAll('\\','/')+'/HTML/index.html'],['12_zap_alertas.png','http://127.0.0.1:8799/herramientas/ZAP/reporte_zap.html'],['13_registro_maestro.png','http://127.0.0.1:8799/Registro_Maestro_EP5_2026-11-17.html']];
  for(const[file,url]of cases){try{const r=await page.goto(url,{waitUntil:'load',timeout:60000});if(!r.ok())throw Error('HTTP '+r.status());await page.screenshot({path:path.join(lab,'capturas',file),fullPage:file!=='13_registro_maestro.png'});results.push({file,status:'CAPTURADA',source:url})}catch(e){results.push({file,status:'BLOCKED',error:e.message})}}
  const sp=path.join(root,'.qa_tools/sonar_cierre_state.json'),cred=JSON.parse(fs.readFileSync(fs.existsSync(sp)?sp:path.join(root,'.qa_tools/sonar_state.json')));
  try{await context.request.post('http://127.0.0.1:9000/api/authentication/login',{form:{login:'admin',password:cred.password}});await page.goto('http://127.0.0.1:9000/dashboard?id=cuidarte-ep5-20261117',{waitUntil:'domcontentloaded',timeout:90000});await page.getByText('Cuidarte EP5 cierre',{exact:true}).first().waitFor({timeout:60000});await page.screenshot({path:path.join(lab,'capturas/14_sonarqube_actual.png'),fullPage:true});results.push({file:'14_sonarqube_actual.png',status:'CAPTURADA',source:'Dashboard real de SonarQube del proyecto de cierre'});}catch(e){results.push({file:'14_sonarqube_actual.png',status:'BLOCKED',error:e.message})}
 }finally{await browser.close()}
}
main().catch(e=>{results.push({status:'BLOCKED',error:e.message});process.exitCode=2}).finally(()=>{const out={date_utc:new Date().toISOString(),tool:'Playwright Edge - capturas de reportes originales',results};fs.writeFileSync(path.join(lab,'resultados/capturas_herramientas_17.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));});
