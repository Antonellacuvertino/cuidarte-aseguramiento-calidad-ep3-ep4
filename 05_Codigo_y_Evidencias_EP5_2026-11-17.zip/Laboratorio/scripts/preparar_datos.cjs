const path=require('path'),fs=require('fs');
const root=path.resolve(__dirname,'../..');process.env.NODE_PATH=path.join(root,'.qa_tools/api/node_modules');require('module').Module._initPaths();
const {Pool}=require('pg');
const phase=process.argv[2];if(!['antes','despues'].includes(phase))throw Error('Fase inválida');
const database='cuidarte_final_'+phase;
const pool=new Pool({connectionString:`postgres://qa:qa_final_sintetica@127.0.0.1:15444/${database}`});
async function main(){
 const db=await pool.query('SELECT current_database() AS db');if(db.rows[0].db!==database)throw Error('Base no autorizada');
 const state={phase,database,base:'http://127.0.0.1:'+(phase==='antes'?4446:4447),users:{},patients:{},roles:{}};
 const r=await pool.query('SELECT id,nombre FROM roles');for(const row of r.rows)state.roles[row.nombre]=Number(row.id);
 for(const key of ['admin','medico','a','b','descartable','victima']){
  const name='qa_final_'+key;
  const u=await pool.query('INSERT INTO usuarios(nombre_usuario,contrasena,correo) VALUES($1,$2,$3) ON CONFLICT(nombre_usuario) DO UPDATE SET contrasena=EXCLUDED.contrasena RETURNING id',[name,'DemoCuidarte2026!',name+'@example.test']);
  const id=u.rows[0].id;state.users[key]={id,name};
  await pool.query('DELETE FROM usuario_roles WHERE usuario_id=$1',[id]);
  await pool.query('INSERT INTO usuario_roles(usuario_id,rol_id) VALUES($1,$2)',[id,state.roles[key==='admin'?'admin':key==='medico'?'medico':'paciente']]);
 }
 for(const key of ['a','b']){
  const p=await pool.query("INSERT INTO pacientes(rut,primer_nombre,apellido_paterno,fecha_nacimiento,sexo,email,usuario_id) VALUES($1,'Paciente','Sintetico','1980-01-01','O',$2,$3) ON CONFLICT(rut) DO UPDATE SET usuario_id=EXCLUDED.usuario_id RETURNING id",['QA-FINAL-'+key,`qa_final_${key}@example.test`,state.users[key].id]);state.patients[key]=p.rows[0].id;
 }
 const e=await pool.query("INSERT INTO examen_medico(tipo_examen_medico_id,paciente_id,diagnosis) VALUES(1,$1,'EXAMEN SINTETICO FINAL') RETURNING id",[state.patients.a]);state.exam=e.rows[0].id;
 fs.writeFileSync(path.join(__dirname,'../.runtime',phase+'.json'),JSON.stringify(state,null,2));console.log('Datos QA preparados: '+database);
}
main().catch(e=>{console.error(e.message);process.exitCode=1}).finally(()=>pool.end());
