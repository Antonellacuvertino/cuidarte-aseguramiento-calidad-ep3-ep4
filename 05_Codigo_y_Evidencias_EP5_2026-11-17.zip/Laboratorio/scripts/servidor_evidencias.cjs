const http=require('http'),fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const mime={'.html':'text/html; charset=utf-8','.json':'application/json; charset=utf-8','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf'};
http.createServer((req,res)=>{
 if(req.method!=='GET'){res.writeHead(405).end();return}
 let url;try{url=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname)}catch{res.writeHead(400).end();return}
 if(url==='/')url='/Recorrido_Pruebas.html';
 if(!/^\/(Recorrido_Pruebas\.html|Registro_Maestro_EP5_2026-11-17\.html|herramientas\/|capturas\/|resultados\/)/.test(url)||url.includes('.runtime')){res.writeHead(403).end();return}
 const file=path.resolve(root,'.'+url);if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return}
 fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end('No encontrado');return}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'text/plain; charset=utf-8','Cache-Control':'no-store'});res.end(data)});
}).listen(8799,'127.0.0.1',()=>console.log('Cuidarte evidencias: http://127.0.0.1:8799'));
