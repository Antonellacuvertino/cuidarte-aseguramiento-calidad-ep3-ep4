const fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'../..');process.env.NODE_PATH=path.join(root,'.qa_tools/api/node_modules');require('module').Module._initPaths();const{Pool}=require('pg');
async function main(){
 const lab=path.join(__dirname,'..'),b=JSON.parse(fs.readFileSync(path.join(lab,'resultados/antes.json'))),a=JSON.parse(fs.readFileSync(path.join(lab,'resultados/despues.json')));
 if(b.results.length!==20||a.results.length!==20)throw Error('Faltan casos');
 const improved=[],regressions=[];
 for(let i=0;i<20;i++){const x=b.results[i],y=a.results[i];if(x.id!==y.id||x.expected!==y.expected||x.requirement!==y.requirement)throw Error('Oráculos distintos: '+x.id);if(x.status==='FAIL'&&y.status==='PASS')improved.push(x.id);if(x.status==='PASS'&&y.status!=='PASS')regressions.push(x.id);}
 const environments=[];
 for(const phase of ['antes','despues']){
  const pool=new Pool({connectionString:`postgres://qa:qa_final_sintetica@127.0.0.1:15444/cuidarte_final_${phase}`});
  try{const q=await pool.query("SELECT COUNT(*)::int AS n FROM pg_trigger WHERE tgname='qa_final_fallo_auditoria'");const u=await pool.query('SELECT current_database() AS db,current_user AS role');if(q.rows[0].n!==0)throw Error('Quedó trigger de fallo instalado');environments.push({...u.rows[0],temporary_failure_trigger_removed:true});}finally{await pool.end()}
 }
 const out={date_utc:new Date().toISOString(),same_20_oracles:true,improved,regressions,environments};fs.writeFileSync(path.join(lab,'resultados/validacion_comparacion.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));if(regressions.length)process.exitCode=1;
}
main().catch(e=>{console.error(e.message);process.exitCode=1});
