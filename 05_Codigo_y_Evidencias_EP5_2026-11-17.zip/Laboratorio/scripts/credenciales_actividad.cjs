const fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'../..');process.env.NODE_PATH=path.join(root,'.qa_tools/api/node_modules');require('module').Module._initPaths();const{Pool}=require('pg');
async function main(){const results=[];
 for(const phase of ['antes','despues']){
  const database='cuidarte_final_'+phase,pool=new Pool({connectionString:`postgres://qa:qa_final_sintetica@127.0.0.1:15444/${database}`});
  try{const db=await pool.query('SELECT current_database() AS db');if(db.rows[0].db!==database)throw Error('Solo QA');
   for(const [name,password,role] of [['admin','Admin','admin'],['medico','medico','medico']]){
    const existed=await pool.query('SELECT id FROM usuarios WHERE nombre_usuario=$1',[name]);
    const u=await pool.query('INSERT INTO usuarios(nombre_usuario,contrasena,correo) VALUES($1,$2,$3) ON CONFLICT(nombre_usuario) DO UPDATE SET contrasena=EXCLUDED.contrasena RETURNING id',[name,password,`actividad_${name}@example.test`]);
    await pool.query('DELETE FROM usuario_roles WHERE usuario_id=$1',[u.rows[0].id]);await pool.query('INSERT INTO usuario_roles(usuario_id,rol_id) SELECT $1,id FROM roles WHERE nombre=$2',[u.rows[0].id,role]);
    const r=await fetch('http://127.0.0.1:'+(phase==='antes'?4446:4447)+'/autenticacion/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nombre_usuario:name,password}),signal:AbortSignal.timeout(20000)});const body=await r.json();
    results.push({phase,username:name,role,http:r.status,jwt_received:!!body.token,account_setup:existed.rowCount?'Credencial de demostración actualizada solo en QA':'Cuenta de demostración creada solo en QA',origin:'Credenciales declaradas en actividad 01-10; no se verificó producción 3333',date_utc:new Date().toISOString()});
   }
  }finally{await pool.end()}
 }
 fs.writeFileSync(path.join(__dirname,'../resultados/credenciales_actividad.json'),JSON.stringify({date_utc:new Date().toISOString(),results},null,2));console.log(JSON.stringify(results,null,2));
}
main().catch(e=>{console.error(e.message);process.exitCode=1});
