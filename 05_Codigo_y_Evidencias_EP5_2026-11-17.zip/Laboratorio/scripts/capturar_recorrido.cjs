const fs=require('fs'),path=require('path');const {pathToFileURL}=require('url');
const root=path.resolve(__dirname,'../..');process.env.NODE_PATH=path.join(root,'.qa_tools/api/node_modules');require('module').Module._initPaths();
const {chromium}=require('playwright');const lab=path.join(root,'03_LABORATORIO_FINAL'),results=[];
const actividad=process.argv.includes('--actividad');const adminName=actividad?'admin':'qa_final_admin';const adminPassword=actividad?'Admin':'DemoCuidarte2026!';
async function main(){
 const edge='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
 const browser=await chromium.launch({headless:true,...(fs.existsSync(edge)?{executablePath:edge}:{}),args:['--disable-gpu','--disable-software-rasterizer','--disable-extensions','--renderer-process-limit=1']});
 try{
  const context=await browser.newContext({viewport:{width:1440,height:1050},locale:'es-CL'});const page=await context.newPage();page.setDefaultTimeout(30000);
  try{
   await page.goto('http://127.0.0.1:3344/login',{waitUntil:'domcontentloaded',timeout:90000});
   await page.locator('#nombre_usuario').waitFor({timeout:90000});
   await page.screenshot({path:path.join(lab,'capturas/01_login_app.png'),fullPage:true});
   await page.locator('#nombre_usuario').fill(adminName);await page.locator('#password').fill('Incorrecta');
   const bad=page.waitForResponse(r=>r.url().includes('/autenticacion/login')&&r.request().method()==='POST');
   await page.getByTestId('button-login').click();const response=await bad;await page.getByText('Credenciales inválidas',{exact:true}).first().waitFor();
   const messageCount=await page.getByText('Credenciales inválidas',{exact:true}).count();
   await page.screenshot({path:path.join(lab,'capturas/02_login_incorrecto.png'),fullPage:true});results.push({id:'UI-01',title:'Login incorrecto visible',status:response.status()===401?'PASS':'FAIL',http:response.status(),visible_message:'Credenciales inválidas'});
   results.push({id:'UI-03',title:'Aviso de error no duplicado',status:messageCount===1?'PASS':'FAIL',expected_messages:1,observed_messages:messageCount,scope:'Hallazgo UI adicional; no se suma a los 20 casos API'});
   await page.locator('#password').fill(adminPassword);const good=page.waitForResponse(r=>r.url().includes('/autenticacion/login')&&r.request().method()==='POST');
   await page.getByTestId('button-login').click();const valid=await good;await page.waitForURL('**/home',{timeout:60000});
   await page.locator('body').waitFor();await page.screenshot({path:path.join(lab,'capturas/03_app_admin.png'),fullPage:true});
   results.push({id:'UI-02',title:'Login correcto y home',status:valid.status()===200?'PASS':'FAIL',http:valid.status(),url:page.url(),scope:'Llegada a home; no valida todos los recorridos E2E'});
   if(actividad){
    await context.clearCookies();await page.evaluate(()=>localStorage.clear());await page.goto('http://127.0.0.1:3344/login');
    await page.locator('#nombre_usuario').fill('medico');await page.locator('#password').fill('medico');const ok=page.waitForResponse(r=>r.url().includes('/autenticacion/login')&&r.request().method()==='POST');await page.getByTestId('button-login').click();const r=await ok;await page.waitForURL('**/home');await page.screenshot({path:path.join(lab,'capturas/03b_app_medico.png'),fullPage:true});results.push({id:'UI-04',title:'Login médico de la actividad y home',http:r.status(),status:r.status()===200?'PASS':'FAIL',scope:'Cuenta recreada exclusivamente en QA según actividad 01-10'});
   }
  }catch(e){results.push({id:'UI-ENTORNO',status:'BLOCKED',error:e.message});await page.screenshot({path:path.join(lab,'capturas/UI_bloqueada.png')}).catch(()=>{});}
  await page.goto(pathToFileURL(path.join(lab,'Recorrido_Pruebas.html')).href,{waitUntil:'load'});
  await page.screenshot({path:path.join(lab,'capturas/04_resumen_pruebas.png'),fullPage:true});
  for(const [id,file] of [['FIN-08','05_borrado_comparado.png'],['FIN-11','06_roles_comparados.png'],['FIN-13','07_auditoria_ip.png'],['FIN-15','08_rollback_pendiente.png'],['FIN-18','09_rendimiento_pendiente.png']]){
   await page.evaluate(id=>window.mostrarCaso(id),id);await page.screenshot({path:path.join(lab,'capturas',file),fullPage:true});
  }
  results.push({id:'CAPTURAS-REPORTE',status:'PASS',scope:'Capturas del HTML generado de JSON reales, no captura de un escáner.'});
 }finally{await browser.close()}
}
main().catch(e=>{results.push({id:'NAVEGADOR',status:'BLOCKED',error:e.message});process.exitCode=2}).finally(()=>{
 const report={date_utc:new Date().toISOString(),tool:'Playwright Chromium headless',credentials_profile:actividad?'Actividad 01-10: admin/Admin y medico/medico, recreados en QA':'Fixture qa_final',results,summary:{pass:results.filter(x=>x.status==='PASS').length,fail:results.filter(x=>x.status==='FAIL').length,blocked:results.filter(x=>x.status==='BLOCKED').length}};
 fs.writeFileSync(path.join(lab,'resultados/recorrido_ui.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
});
