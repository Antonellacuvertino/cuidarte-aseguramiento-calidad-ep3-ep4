# Prompt para NotebookLM · video para estudiar y ensayar

Actúa como tutor de Seguridad y Calidad de Software y entrenador de defensa oral. Crea un video educativo para explicarme qué debo comprender y decir al ensayar mi presentación. El video será material de estudio; la entrega al profesor la grabaré yo con mi propia voz.

Usa únicamente el informe EP5, la presentación EP6, la guía de defensa y las evidencias que adjunto. Soy Antonella Cuvertino, de Duoc UC, Ingeniería Informática, Desarrollo de Software, sección 02V. El proyecto es Cuidarte+ y la asignatura es ISY1102. No confundas una plantilla de portada con otra asignatura.

Organiza la explicación siguiendo las diez diapositivas, con un objetivo de diez minutos de exposición. Para cada lámina:

1. Explica la idea en lenguaje sencillo y define los términos técnicos.
2. Propón lo que yo podría decir en primera persona, sin sonar como una lectura del informe.
3. Indica qué captura, log o reporte debo mostrar y dónde encontrarlo en las fuentes; no inventes páginas.
4. Explica el requisito, qué se obtuvo, la causa, la prioridad y el resultado del retest o el pendiente.
5. Advierte una confusión frecuente que debo evitar.

Diferencia Docker/Node.js como entorno, VS Code como revisión, Postman/Newman para API, JMeter para carga/estrés, ZAP para DAST pasivo y SonarQube para SAST. Explica las siglas y qué no demuestra cada herramienta.

Respeta las unidades y fechas: los veinte casos Node comparan 8 PASS/12 FAIL antes con 15 PASS/5 FAIL después; Postman contiene nueve solicitudes y doce aserciones por fase. No mezcles esos totales con muestras JMeter, alertas ZAP o métricas Sonar. Usa las fechas reales de cada artefacto, aunque la entrega esté fechada el 17 de noviembre de 2026.

Explica por qué cero errores HTTP en JMeter no aprueba un p95 de unos cinco segundos cuando el objetivo documentado es menor de 300 ms. Distingue alerta, vulnerabilidad confirmada, bug, smell y hotspot. Un gate OK sin condiciones y cero vulnerabilidades clasificadas no certifican seguridad integral.

Muestra mejoras verificadas y reservas abiertas: permisos/inmutabilidad de auditoría, rollback del cambio de rol, baja lógica, hash de contraseñas, latencia y aviso duplicado en UI. No digas que lo pendiente es imposible de corregir. Si falta evidencia, clasifícalo como pendiente y no inventes resultados. GitHub Actions, WCAG completo, restauración y DAST activo exhaustivo no deben presentarse como ejecutados.

Explica la normativa según la fecha y las fuentes, sin afirmar cumplimiento completo ni multas automáticas. Cierra con mantenimiento, siguientes pasos y la decisión de producción bloqueada.

Después de la explicación, plantea ocho preguntas difíciles del profesor con respuestas argumentadas. Ayúdame a responder con esta estructura: requisito → evidencia → causa → acción → retest o pendiente. El objetivo es que comprenda y pueda defender el proyecto completo, no que memorice frases sin entenderlas.
