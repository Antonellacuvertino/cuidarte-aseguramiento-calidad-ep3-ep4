﻿$ErrorActionPreference='Stop'
$lab=$PSScriptRoot
$root=Split-Path -Parent $lab
& docker.exe info --format '{{.ServerVersion}}' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Primero abre Docker Desktop.' }
$existing=& docker.exe ps -a --filter 'name=^cuidarte-final-db$' --format '{{.Names}}'
if ($existing -eq 'cuidarte-final-db') { & docker.exe start cuidarte-final-db | Out-Null } else {
 & docker.exe run -d --name cuidarte-final-db --memory=256m --cpus=1 -p 127.0.0.1:15444:5432 -e POSTGRES_USER=qa -e POSTGRES_PASSWORD=qa_final_sintetica -e POSTGRES_DB=postgres postgres:15-alpine | Out-Null
 if ($LASTEXITCODE -ne 0) {throw 'No se pudo crear PostgreSQL QA.'}
}
for($i=0;$i -lt 40;$i++) {& docker.exe exec cuidarte-final-db pg_isready -U qa 2>$null | Out-Null;if($LASTEXITCODE -eq 0){break};Start-Sleep -Seconds 1}
foreach($phase in @('antes','despues')) {
 $database='cuidarte_final_'+$phase
 $exists=& docker.exe exec cuidarte-final-db psql -U qa -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$database'"
 if ($LASTEXITCODE -ne 0) {throw 'No se pudo consultar PostgreSQL.'}
 $source=if($phase -eq 'antes'){Join-Path $lab 'version_antes\BACKEND'}else{Join-Path $root 'BACKEND'}
 if(($exists -join '') -ne '1') {
  & docker.exe exec cuidarte-final-db createdb -U qa $database
  if($LASTEXITCODE -ne 0){throw 'No se pudo crear la base de fase.'}
  $schema=Join-Path $source 'sql\init.sql'
  & docker.exe cp $schema 'cuidarte-final-db:/tmp/schema-final.sql'
  & docker.exe exec cuidarte-final-db psql -U qa -d $database -v ON_ERROR_STOP=1 -f /tmp/schema-final.sql | Out-Null
  if($LASTEXITCODE -ne 0){throw 'No se pudo cargar el esquema.'}
 }
 if($phase -eq 'despues') {
  $migration=Join-Path $root 'BACKEND\sql\migrations\001_auditoria_ip.sql'
  if(Test-Path -LiteralPath $migration) {
   & docker.exe cp $migration 'cuidarte-final-db:/tmp/migracion-final.sql'
   & docker.exe exec cuidarte-final-db psql -U qa -d $database -v ON_ERROR_STOP=1 -f /tmp/migracion-final.sql | Out-Null
   if($LASTEXITCODE -ne 0){throw 'No se pudo aplicar la migracion de IP.'}
  }
 }
 & node (Join-Path $lab 'scripts\preparar_datos.cjs') $phase
 if($LASTEXITCODE -ne 0){throw 'No se pudo preparar el fixture.'}
 $port=if($phase -eq 'antes'){4446}else{4447}
 $pidFile=Join-Path $lab ('.runtime\api-'+$phase+'.json')
 $old=if(Test-Path -LiteralPath $pidFile){Get-Content -LiteralPath $pidFile -Raw | ConvertFrom-Json}else{$null}
 if($old) {
  $process=Get-Process -Id $old.id -ErrorAction SilentlyContinue
  if($process -and $process.StartTime.ToUniversalTime().ToString('o') -eq $old.started){Stop-Process -Id $process.Id -Force; $process.WaitForExit(5000) | Out-Null; Start-Sleep -Milliseconds 500}
 }
 $probe=New-Object System.Net.Sockets.TcpClient
 try{$probe.Connect('127.0.0.1',$port);throw "Puerto $port ocupado por otro proceso."}catch [System.Net.Sockets.SocketException]{}finally{$probe.Dispose()}
 $env:DATABASE_URL="postgres://qa:qa_final_sintetica@127.0.0.1:15444/$database"
 $env:NODE_PATH=Join-Path $root '.qa_tools\api\node_modules'
 $env:JWT_SECRET='qa_final_jwt_solo_datos_sinteticos'
 $env:PORT="$port"
 $env:NODE_OPTIONS='--max-old-space-size=256'
 $app=Join-Path $source 'src\app.js'
 $process=Start-Process -FilePath (Get-Command node.exe).Source -ArgumentList ('"'+$app+'"') -WorkingDirectory $source -WindowStyle Hidden -RedirectStandardOutput (Join-Path $lab ".runtime\$phase.stdout.log") -RedirectStandardError (Join-Path $lab ".runtime\$phase.stderr.log") -PassThru
 @{id=$process.Id;started=$process.StartTime.ToUniversalTime().ToString('o');script=$app} | ConvertTo-Json | Set-Content -LiteralPath $pidFile -Encoding UTF8
 $ready=$false
 for($i=0;$i -lt 30;$i++){try{Invoke-RestMethod "http://127.0.0.1:$port/" -TimeoutSec 2 | Out-Null;$ready=$true;break}catch{Start-Sleep -Milliseconds 500}}
 if(-not $ready){throw "API $phase no responde; revisa .runtime."}
 Write-Host "API $phase lista: http://127.0.0.1:$port"
}
& node (Join-Path $lab 'scripts\credenciales_actividad.cjs')
if($LASTEXITCODE -ne 0){throw 'No se pudieron preparar/verificar las cuentas de la actividad en QA.'}
