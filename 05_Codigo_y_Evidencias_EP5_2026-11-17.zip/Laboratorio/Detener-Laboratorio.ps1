﻿$ErrorActionPreference='Stop'
foreach($name in @('api-antes','api-despues','frontend')){
 $file=Join-Path $PSScriptRoot ('.runtime\'+$name+'.json')
 if(Test-Path -LiteralPath $file){
  $info=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json
  $p=Get-Process -Id $info.id -ErrorAction SilentlyContinue
  if($p -and $p.StartTime.ToUniversalTime().ToString('o') -eq $info.started){Stop-Process -Id $p.Id -Force}
 }
}
& docker.exe stop --timeout 15 cuidarte-final-db
Write-Host 'Solo se detuvo este laboratorio; no se borraron bases ni se detuvo SonarQube.'
