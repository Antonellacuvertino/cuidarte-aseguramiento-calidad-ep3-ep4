# Recorrido real de pruebas · Antonella Cuvertino

## Resultados medidos

Antes: {'total': 20, 'pass': 8, 'fail': 12, 'blocked': 0}. Después: {'total': 20, 'pass': 15, 'fail': 5, 'blocked': 0}.

## 1. Preparar entorno

Abrir Docker Desktop. En PowerShell: powershell -NoProfile -ExecutionPolicy Bypass -File .\03_LABORATORIO_FINAL\Iniciar-Laboratorio.ps1. Levanta API antes 4446, API después 4447 y bases QA distintas en 15444. No usa los puertos de producción ni resetea bases ajenas.

## 2. Ejecutar antes

Ejecutar: .\03_LABORATORIO_FINAL\Ejecutar-Pruebas.ps1 -Fase antes. Guardar consola y resultados/antes.json. Exit code 1 significa que hay pruebas FAIL. No editar el JSON ni cambiar el resultado esperado.

## 3. Revisar causa y parche

Comparar las rutas originales y actuales. Antes de explicar una corrección, identificar el requisito, la evidencia de HTTP y persistencia, la condición del código y el archivo cambiado. La versión anterior queda conservada para comparar.

## 4. Ejecutar después

Ejecutar: .\03_LABORATORIO_FINAL\Ejecutar-Pruebas.ps1 -Fase despues. Mantener los mismos 20 casos. Abrir resultados/despues.json y comparar. Si se repite una fase, conservar previamente una copia de su JSON fechado; el script reemplaza el último registro de esa fase.

## 5. Ver la app y el reporte

Ejecutar Abrir-App.ps1 y abrir http://127.0.0.1:3344/login. Perfiles de la actividad recreados en QA: admin/Admin y medico/medico; respetar mayúsculas. Los scripts internos también usan fixtures qa_final. Abrir Abrir-Evidencias.ps1 para los reportes. Tras nuevas corridas, regenerar la documentación.

## 6. Explicar resultados abiertos

No decir “no se puede arreglar”. Indicar si no se abordó o si el parche es parcial y qué falta para cerrar el requisito. API disponible no significa funcionalidad correcta; 500 no garantiza rollback. En auditoría, IP, inmutabilidad y atomicidad son propiedades diferentes.

## 7. Capturar y entregar

Guardar las capturas indicadas con nombre, caso, fase y fecha. Cada imagen debe permitir leer requisito, esperado, observado y evidencia posterior. No mostrar tokens, claves ni pacientes reales. Entregar informe, diapositivas, evidencias y video personal conforme a AVA. El video debe grabarlo Antonella; no se incluye una participación simulada.

## Capturas necesarias

### 01_login_app.png · Inicio de la app

Abrir http://127.0.0.1:3344/login. Capturar URL, formulario y contexto QA, sin escribir la clave en pantalla.

### 02_login_incorrecto.png · Validación visible de login

Introducir usuario sintético y clave incorrecta; capturar mensaje visible sin secretos. Vincular con FIN-03; la captura UI es una comprobación distinta del HTTP automatizado.

### 03_app_admin.png · Recorrido real de la aplicación

Ingresar como admin/Admin, o medico/medico para el otro perfil, recreados solo en QA; capturar home. No afirmar un E2E completo por llegar a home.

### 04_resumen_pruebas.png · Resumen antes / después

Abrir Recorrido_Pruebas.html, Todos los casos. Mostrar los dos totales y la fecha registrada. Explicar que es un reporte de los JSON, no un nuevo escaneo.

### 05_borrado_comparado.png · Defecto corregido: borrado anónimo

Seleccionar FIN-08. Mostrar 200 y rows_after=0 antes; 401 y fila conservada después. Relacionar NFR-SEG-4 y protección previa a DELETE.

### 06_roles_comparados.png · Defecto corregido: escalamiento

Seleccionar FIN-11. Mostrar payload válido, respuesta y roles_after en ambas fases. No usar el 400 de octubre como prueba de explotación.

### 07_auditoria_ip.png · Corrección parcial de auditoría

Seleccionar FIN-13. Mostrar ausencia/presencia de ip_origen y el XFF de prueba. Explicar que no prueba inmutabilidad.

### 08_rollback_pendiente.png · Fallo persistente ante error controlado

Seleccionar FIN-15. Mostrar HTTP 500 y roles_before/after. Explicar trigger temporal de QA, su retiro y falta de transacción en PUT.

### 09_rendimiento_pendiente.png · Demora con causa identificada

Seleccionar FIN-18 y abrir examenes.js en VS Code para capturar delayMiddleware(5000). No llamarlo prueba JMeter ni capacidad de 200 usuarios.

### 10_cambio_codigo.png · Cambios de código

En VS Code comparar version_antes/BACKEND/src/routes/users.js con BACKEND/src/routes/users.js. Capturar requireAdmin, isAdmin y actor usuarioId. Añadir migración IP si se explica ese parche. No capturar db.js, .env, JWT o contraseñas.

## Cómo explicar cada caso

- FIN-08: CORREGIDO. DELETE se ejecutaba antes de autenticar. Se exige sesión y admin antes de mutar; el retest verifica 401 y fila intacta.

- FIN-09: CORREGIDO. No había control de rol. Además, se enviaba un nombre de usuario a una columna BIGINT de auditoría: podía borrar y luego fallar. El retest exige 403 y fila intacta.

- FIN-10: CORREGIDO. La auditoría recibía nombreUsuario en vez de usuarioId. Se usa el ID numérico y una transacción para borrado más evento; el admin debe conservar su operación legítima.

- FIN-11: CORREGIDO. isAdminOrMedico permitía que un médico modificara su propio rol. Se restringe a isAdmin y se comprueba el rol posterior con un payload válido.

- FIN-12: CORREGIDO. rol_id no estaba declarado en updateUserSchema. Se declara como entero positivo; deja de rechazarse la solicitud legítima antes de llegar a autorización.

- FIN-13: CORREGIDO EN ESTE ALCANCE. Se agrega ip_origen INET y se registra req.ip para el evento de actualización médica. Con trust proxy desactivado no se cree el encabezado XFF de prueba. No demuestra trazabilidad detrás de cualquier proxy ni de todas las rutas.

- FIN-14: ABIERTO · NO ABORDADO EN ESTA ITERACIÓN. El rol configurado para QA conserva permisos para modificar auditoria. Agregar IP no cambia privilegios. Se necesita un rol aplicativo mínimo distinto del propietario, migraciones separadas y política de integridad/retención; no se revocan permisos a ciegas durante esta campaña.

- FIN-15: ABIERTO · CORRECCIÓN PARCIAL DE AUDITORÍA. La ruta de cambio de rol sigue usando pool.query separados sin transacción. Al rechazar controladamente el evento en QA, el rol ya cambió. Requiere client único + BEGIN/COMMIT/ROLLBACK para todo el flujo; no se afirma que el parche IP resuelva atomicidad.

- FIN-16: ABIERTO · NO ABORDADO EN ESTA ITERACIÓN. DELETE elimina físicamente examen_medico. Una baja lógica exige migración y actualizar listados, consultas, descargas y conservación. Cambiar solo DELETE no constituye una solución consistente.

- FIN-17: ABIERTO · NO ABORDADO EN ESTA ITERACIÓN. Registro persiste la clave en texto claro y login la compara directamente. Corregir exige hashing en alta/cambio, verificación segura y migración o reseteo de cuentas existentes. No basta cifrar una fila del fixture ni cambiar el test.

- FIN-18: ABIERTO · CAUSA IDENTIFICADA. GET /examenes tiene delayMiddleware(5000), que añade cinco segundos. El resultado incumple <300 ms. Un índice o un pool mayor no elimina esa espera; retirar simulación y repetir carga es el siguiente cambio propuesto, no una imposibilidad técnica.

- FIN-20: CORREGIDO. POST /usuarios autenticaba pero no exigía admin, permitiendo crear una cuenta privilegiada. Se agrega requireAdmin antes de validación e inserción; el paciente debe recibir 403 sin nueva fila.