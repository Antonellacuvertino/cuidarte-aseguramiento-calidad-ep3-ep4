﻿$ErrorActionPreference='Stop'
Start-Process -FilePath (Join-Path $PSScriptRoot 'Recorrido_Pruebas.html')
