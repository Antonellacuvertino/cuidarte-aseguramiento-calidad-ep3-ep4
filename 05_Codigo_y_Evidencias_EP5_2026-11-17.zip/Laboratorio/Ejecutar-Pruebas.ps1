﻿param([ValidateSet('antes','despues')][string]$Fase='despues')
$ErrorActionPreference='Stop'
Write-Host "Cuidarte+ - campaña $Fase. Solo bases QA sintéticas."
& node (Join-Path $PSScriptRoot 'scripts\campana.cjs') $Fase
$resultado=$LASTEXITCODE
if($resultado -eq 1){Write-Host 'Hay pruebas FAIL: son defectos observados, no un error del script.'}
if($resultado -eq 2){Write-Host 'Hay pruebas BLOCKED: revisar precondiciones y entorno.'}
Write-Host ('Resultado JSON: '+(Join-Path $PSScriptRoot "resultados\$Fase.json"))
exit $resultado
