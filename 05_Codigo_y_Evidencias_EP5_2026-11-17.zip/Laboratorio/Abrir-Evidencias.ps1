$ErrorActionPreference='Stop'
$url='http://127.0.0.1:8799'
$ready=$false
try{$r=Invoke-WebRequest $url -UseBasicParsing -TimeoutSec 2;if($r.Content -like '*Cuidarte*'){$ready=$true}else{throw 'Puerto 8799 ocupado por otra aplicación.'}}catch [System.Net.WebException]{}
if(-not $ready){
 $script=Join-Path $PSScriptRoot 'scripts\servidor_evidencias.cjs'
 $p=Start-Process -FilePath (Get-Command node.exe).Source -ArgumentList ('"'+$script+'"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot '.runtime\evidencias.stdout.log') -RedirectStandardError (Join-Path $PSScriptRoot '.runtime\evidencias.stderr.log') -PassThru
 @{id=$p.Id;started=$p.StartTime.ToUniversalTime().ToString('o');script=$script}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot '.runtime\evidencias.json') -Encoding UTF8
}
Start-Process $url
