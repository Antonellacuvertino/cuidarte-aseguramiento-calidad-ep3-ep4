# Informe final EP5 / EP6


Duoc UC
ISY1102: Seguridad y Calidad en el Desarrollo de Software
Encargo 3 · Evaluación Parcial 5 / Presentación EP6
Informe de seguridad y calidad en el desarrollo de software
Caso: Cuidarte+ · CreaLab SpA
Antonella Cuvertino · QA Lead / DevSecOps Engineer
Docente: LUIS MANUEL YAGI FIGUEROA
Sección: 02V
Carrera: Ingeniería Informática, Desarrollo de Software
Fecha de presentación: 17 de noviembre de 2026
Preparación documental: 16 de noviembre de 2026
CERTIFICADO CON RESERVAS · PRODUCCIÓN BLOQUEADA


## 1. Introducción

Cuidarte+ (CreaLab SpA) gestiona exámenes, pacientes y documentos clínicos con React, Express y PostgreSQL. Este informe corresponde al Encargo 3 de ISY1102 y apoya la presentación EP6. Se prepara el 16 de noviembre de 2026 para la defensa del 17 de noviembre. Las evidencias de ejecución reutilizadas están fechadas el 20 de octubre de 2026; no se atribuyen a una nueva campaña.

Dictamen académico solicitado: CERTIFICADO CON RESERVAS. Decisión operativa: BLOQUEADO PARA PRODUCCIÓN. El rótulo no representa certificación oficial, cumplimiento legal integral ni autorización de uso clínico. El informe anterior mantenía no certificado: sin retests de cierre no se acredita un avance técnico que permita levantar el bloqueo.

El alcance comprende revisión documental, lectura del código y análisis de evidencias locales. No incluye nuevas ejecuciones de Jest, Cypress, SCA, ZAP ni JMeter ni un workflow de Actions operativo. Se diferencian resultados confirmados, riesgos de revisión estática, inconsistencias y controles propuestos.

docker-compose.yml declara frontend 3333→80, backend 4444→4000 y PostgreSQL ${PORT_POSTGRES:-15442}→5432. Las variables locales pueden modificar el puerto publicado. La evidencia QA usa API 4445 y base aislada 15443; la interfaz de práctica usa 3334. SonarQube se conserva por separado en 9000 y no forma parte de los tres servicios del Compose original. No se afirma que estos servicios estén actualmente encendidos.

PostgreSQL usa su protocolo, por lo que localhost:5432 no es una interfaz HTTP. En un contenedor localhost designa al propio contenedor; la API debe conectar a la base mediante el nombre de servicio y puerto interno. Separar red, volúmenes y datos sintéticos permite repetir las pruebas sin usar historias clínicas reales.

Los scripts locales de 02_DEMOSTRACION preparan QA y ejecutan cuatro pruebas: login correcto, login incorrecto, acceso entre pacientes y persistencia tras borrado. El último registro tiene 3 PASS y 1 FAIL, distinto del conjunto histórico de 12 verificaciones. No sumar ambas campañas como casos únicos. El arranque y las pruebas deben realizarse antes de grabar; no modificar las evidencias históricas para aparentar resultados actuales.

Feedback recibido para Antonella: 80,0/100; nota 5,5. El docente valoró claridad, orden y comprensión general y pidió fundamentar con precisión qué requisito se valida, cuál es la evidencia y por qué la acción es prioritaria. Por ello cada ficha identifica requisito, fuente, interpretación, impacto y condición de cierre. Antonella asume la presentación individual y el dominio del proyecto completo.

No se adjuntó la ERS completa en esta solicitud. Los identificadores RF/NFR se heredan de los antecedentes y necesitan ratificación contra la versión docente. No se declara cobertura del 100% de la ERS. La pauta EP5 presenta una referencia interna a Evaluación Parcial 3; se sigue su contenido y la instrucción posterior del docente: informe, diapositivas y video.

Ajuste | Antes / contexto | Corrección aplicada

Evidencia | Herramientas listadas como configuradas | Estado por herramienta y artefacto verificable.

SQLi / IDOR | Explotaciones afirmadas sin versión reproducible | No corroborar una SQLi inexistente; limitar el PASS al escenario probado.

Escalamiento | CSV dice éxito; JSON muestra 400 | Reclasificar como riesgo en código, pendiente de retest.

Carga | 200 usuarios JMeter; umbral 450 ms | Lote Node, p95 8.698 ms; criterio histórico <300 ms.

Auditoría | logs_auditoria y cambio exitoso | Tabla auditoria sin IP; cambio de rol no acreditado en JSON.

Normativa | Ley futura presentada como vigente | Corte normativo y aplicación condicionada por sujeto.


## 2. Criterios de calidad

Los criterios siguientes operacionalizan los antecedentes del caso clínico. Los identificadores RF/NFR son heredados, no una transcripción certificada de una ERS completa disponible. Cada criterio se vincula a una prueba y a una condición medible; la severidad determina el orden de corrección, no modifica el resultado observado.

El sistema debe proteger datos de salud, controlar permisos por función y titularidad, conservar integridad, manejar errores sin revelar SQL/credenciales y permitir recuperación de incidentes. La calidad incluye usabilidad, rendimiento, estabilidad, confiabilidad y mantenibilidad; no se reduce a un número del análisis estático.

Corte de consulta: 16 de noviembre de 2026. Ley 19.628: régimen de protección de datos aplicable a la fecha; la información de salud exige tratamiento justificado y resguardo de confidencialidad [L1]. El informe no evalúa integralmente obligaciones sanitarias, contratos ni fichas clínicas; requieren revisión adicional.

Ley 21.719: preparación para su vigencia general del 1 de diciembre de 2026 según la versión oficial consultada [L2]. Se proponen inventario de datos, minimización, gestión de derechos, base de licitud y seguridad por diseño. No se presenta como un régimen general ya vigente. Verificar nuevamente la fecha si cambia el momento de entrega.

Ley 21.663: determinar si CreaLab o su cliente corresponde a institución obligada por servicios esenciales y si existe calificación OIV. La prestación institucional de salud está contemplada; no se infiere automáticamente que todo proveedor es OIV. Un defecto no equivale por sí mismo a un incidente significativo. Para sujetos obligados, la alerta temprana por incidentes significativos tiene plazo máximo de tres horas desde su conocimiento [L3–L4]. El reporte debe respetar las reglas de omisión de datos personales. La falta de IP no determina automáticamente infracción ni multa.

La retención de datos clínicos, logs y respaldos debe conciliarse con finalidad y obligaciones sectoriales. Soft delete no es una política integral de supresión. Docker, SonarQube o un gate verde no demuestran cumplimiento legal. Se requiere evidencia de controles y evaluación del contexto de tratamiento.

Dimensión / referencia | Criterio verificable | Caso / estado

Adecuación funcional e integridad | Examen creado y adjunto íntegro; baja lógica conserva la fila. | CP-API-006 PASS; 007 FAIL.

Acceso / NFR-SEG-4 | Anónimo no muta; paciente no accede a recurso ajeno; solo admin gestiona roles. | CP-API-004 PASS parcial; 010 por reproducir; 012 FAIL.

Protección de credenciales | Persistencia con hash adaptativo; verificación segura. | CP-API-008 FAIL.

Trazabilidad / RF-5.1 | Actor, operación, hora y origen validado; cambio y evento atómicos. | CP-API-009: esquema sin IP; flujo bloqueado por validación.

Eficiencia / NFR-PERF-1 | Umbral histórico <300 ms; p95 propuesto por acordar. | CP-API-011 FAIL; lote Node FAIL.

Usabilidad y accesibilidad | WCAG 2.1 AA: evaluar criterios A/AA aplicables, tareas y ayudas. | Sin evaluación completa acreditada.

Estabilidad y confiabilidad | Sin errores inesperados y restauración íntegra; medir RPO/RTO. | Cero errores en ráfaga no prueba estabilidad; restauración pendiente.

Mantenibilidad | Regresión por versión, dependencias revisadas, hotspots evaluados. | SAST histórico; gates CI aún propuestos.


## 3. Plan de pruebas

Plan mixto y basado en riesgo. Las automatizaciones históricas ejecutadas corresponden a scripts Node y SonarQube. El pipeline de herramientas adicionales es el diseño objetivo; una corrida ausente permanece pendiente, sin inventar resultados. Se priorizan autorización destructiva, confidencialidad clínica, integridad y auditoría antes de rendimiento y apariencia.


## 3.1 Estrategia de pruebas

Etapas: confirmar versión de requisitos y commit; preparar QA aislado y datos sintéticos; diseñar casos y resultados esperados; ejecutar y conservar evidencia; clasificar discrepancias; proponer o implementar cambios autorizados; repetir casos afectados y regresión; aprobar o bloquear la liberación. La revisión manual interpreta impactos y falsos positivos; la automatización obtiene resultados repetibles.

Criterios de entrada: alcance autorizado, esquema limpio o restaurado, cuentas sintéticas de admin/médico/pacientes, API saludable, herramientas instaladas, configuración y versiones registradas, respaldo recuperable. Para DAST activo y carga, confirmar entorno desechable y ventana de ejecución. Si una precondición falla, marcar BLOCKED y no inferir una vulnerabilidad.

Criterios de salida: completar la matriz comprometida; cero defectos críticos de autorización/integridad abiertos; evidencia de auditoría, credenciales y rendimiento; trazabilidad de correcciones y retests; revisión de riesgos y aprobación del responsable. La decisión actual no cumple esos criterios y mantiene producción bloqueada.

Diagrama del diseño objetivo: push/pull_request → checkout e instalación reproducible → pruebas Jest + SCA + SAST → entorno Docker aislado → Cypress y DAST → archivo de evidencias y gate → aprobación de responsables → despliegue. JMeter se ejecutaría de forma programada/manual en entorno dedicado; no en cada commit. Cada resultado debe conservar commit, fecha, versión de herramientas, configuración, escenario, resultado y hash del artefacto.

Controles transversales: secretos fuera del repositorio; datos sintéticos; roles mínimos; limpieza del entorno tras las pruebas; retención de artefactos acordada y acceso restringido. Una caída del escáner es ERROR/BLOCKED; no es aprobación. Una advertencia se evalúa con contexto, no se oculta con continue-on-error en un gate obligatorio.

No hay workflow ejecutado acreditado en este árbol. Para implementarlo se requieren lockfiles controlados, scripts de prueba, runner, alcance autorizado de DAST y un SonarQube alcanzable. Un runner alojado por GitHub no puede usar el localhost del computador de Antonella. Alternativas: servicio en el propio runner, servicio remoto accesible o runner propio aislado [T5]. El diagrama vectorial se incorpora a la presentación y a este informe.


## 3.2 Tipos de prueba

Tipo | Objetivo y motivo | Aplicación

Funcional | Validar login, examen, adjunto y baja conforme al negocio. | API 001/002/003/006/007.

Seguridad | Autenticación, autorización, credenciales, SQLi y auditoría. | API 004/005/008/009/010/012; SAST histórico; DAST/SCA propuestos.

Integración | Correlacionar HTTP, JWT, persistencia y eventos PostgreSQL. | Consultas posteriores a modificaciones y hash de adjunto.

Usabilidad / accesibilidad | Validar tareas clínicas y barreras de teclado, foco, contraste y formularios. | Revisión WCAG manual y automática propuesta, sin conformidad acreditada.

Rendimiento | Medir latencia y degradación bajo un perfil reproducible. | API 011 y ráfaga Node histórica; JMeter propuesto.

Confiabilidad / estabilidad | Verificar consistencia, recuperación y tolerancia a fallos. | Rollback, restauración y meseta de carga propuestas.

Regresión / E2E | Asegurar que cambios no rompan recorridos de usuario. | Scripts API disponibles; Cypress propuesto.


## 3.3 Criterios de aceptación

PASS exige coincidencia de respuesta, contenido y estado persistido; un 200 aislado no acredita éxito del requisito. FAIL indica incumplimiento del oráculo de prueba, no necesariamente explotación. BLOCKED corresponde a precondiciones fallidas o impedimento del entorno. NOT RUN significa caso diseñado sin ejecución. Inconcluyente se usa en la interpretación técnica de una evidencia que no ejercitó la acción pretendida, sin modificar retrospectivamente el resumen original.

Casos de autorización: sin token → 401; no autorizado → 403 o 404 deliberado que no exponga existencia/datos; fila y permisos intactos. Casos de persistencia: verificar SELECT antes/después. Adjuntos: bytes/hash y control del titular. Auditoría: evento y cambio atómicos con origen validado. Contraseñas: nunca iguales al texto de entrada. Rendimiento: ratificar el umbral histórico antes de ejecutar la nueva campaña.

SQLi requiere demostrar una ruta vulnerable con entradas controladas; no basta encontrar backticks o concatenación de fragmentos de SQL permitidos. IDOR exige evidencia de acceso no autorizado a un objeto específico. Un hotspot SAST requiere revisión; un gate sin condiciones no es criterio de aceptación del producto.


## 3.4 Herramientas utilizadas

Herramientas ejecutadas históricamente: Node.js v22.16.0 y fetch/pg; PostgreSQL 15.19 en QA; SonarQube 9.9.8.100196 y Scanner CLI 8.1.0.6389 según el expediente previo. React/Express describen la aplicación evaluada. Las versiones declaradas en package.json no equivalen por sí solas a versiones resueltas instaladas.

Recursos humanos: Antonella coordina QA, evidencia y gates DevSecOps, diseña casos, revisa cumplimiento y presenta la defensa individual; desarrollo corrige y el responsable del producto decide liberación. No atribuirle ejecuciones personales que el log identifica solo como automatización asistida.

Recursos técnicos: Windows con PowerShell, Docker Desktop, Node, navegador para UI, PostgreSQL y SonarQube. El equipo local tiene recursos limitados: evitar carga sostenida junto con escáneres durante la defensa. Registrar navegador/versión al ejecutar una futura campaña E2E. QA no usa datos clínicos reales. Los puertos y redes se detallan en la introducción.

Herramienta | Qué verifica / evidencia requerida | Estado acreditado

Node API | HTTP, permisos y persistencia; JSON por caso | Ejecutado históricamente.

Jest | Unidad/integración; JUnit y LCOV | Propuesto; sin instalación ni corrida acreditada.

Cypress | Recorridos E2E; reporte y capturas | Propuesto; sin corrida acreditada.

SonarQube | SAST y mantenibilidad; métricas/issues/hotspots | Escaneo histórico real.

npm audit / Snyk | Dependencias conocidas; JSON y lockfile | Propuesto; sin reporte acreditado.

OWASP ZAP | DAST con sesión y alcance; HTML/JSON | Propuesto; baseline pasivo no basta [T8].

Apache JMeter | 200 usuarios sostenidos; JTL/HTML y recursos | Propuesto; Node no es JMeter [T7].


## 4. Diseño de casos de prueba

Se documentan los 12 casos históricos con los campos de la plantilla: ID, nombre, requerimiento, descripción, precondiciones, pasos, resultado esperado, criterio de aceptación y datos de prueba. Los pasos siguientes permiten preparar una nueva corrida; no significan que se haya repetido durante esta adaptación. Los identificadores y roles se obtienen del fixture de QA, no de datos personales.

El objetivo de los casos 009 y 010 se conserva, pero los nuevos pasos deben evitar el error de precondición que produjo 400: incluir campos de perfil válidos que acepte updateUserSchema junto con rol_id y una cuenta descartable. No llamar PASS de seguridad a un rechazo de validación que no llega a autorización. El payload definitivo debe contrastarse con el esquema vigente antes de repetir.

SQLi, matriz extendida de IDOR, SCA, DAST autenticado, JMeter sostenido, accesibilidad y restauración constituyen cobertura adicional propuesta. Sus fichas y artefactos requieren una nueva campaña y no incrementan el total histórico de 12 casos ejecutados.


## 4.1 CP-API-001 · Login válido y JWT

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-001 / Login válido y JWT / RF-1.1

DESCRIPCIÓN | Comprobar autenticación y firma del JWT.

PRECONDICIONES | Cuenta sintética activa y secreto de QA controlado.

PASOS | 1. POST /autenticacion/login con credenciales del fixture. 2. Comprobar HTTP y token. 3. Verificar firma y claims esperados sin mostrar el token.

RESULTADO ESPERADO | HTTP 200 y JWT verificable.

CRITERIO DE ACEPTACIÓN | Respuesta correcta, firma válida y usuario correspondiente.

DATOS DE PRUEBA | Cuenta sintética de admin; contraseña del fixture QA, no transcrita en evidencias.


## 4.2 CP-API-002 · Credenciales inválidas

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-002 / Credenciales inválidas / RF-1.1

DESCRIPCIÓN | Rechazar autenticación con contraseña incorrecta.

PRECONDICIONES | Cuenta válida preparada; no bloqueada por otra prueba.

PASOS | 1. POST /autenticacion/login con usuario válido y contraseña incorrecta. 2. Revisar estado y cuerpo. 3. Verificar ausencia de JWT.

RESULTADO ESPERADO | HTTP 401; sin token ni detalle sensible.

CRITERIO DE ACEPTACIÓN | No se concede sesión y no se revela información interna.

DATOS DE PRUEBA | Usuario del fixture; password=Incorrecta.


## 4.3 CP-API-003 · Campos obligatorios de examen

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-003 / Campos obligatorios de examen / RF-3.1

DESCRIPCIÓN | Rechazar creación incompleta y evitar persistencia.

PRECONDICIONES | Sesión médico de QA; contador o identificador de control previo.

PASOS | 1. POST /examenes con cuerpo vacío. 2. Revisar error de validación. 3. Confirmar que no se creó examen.

RESULTADO ESPERADO | HTTP 400; sin inserción.

CRITERIO DE ACEPTACIÓN | Error identifica campos requeridos sin modificar datos.

DATOS DE PRUEBA | JSON {}; token médico sintético.


## 4.4 CP-API-004 · IDOR por paciente ajeno

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-004 / IDOR por paciente ajeno / NFR-SEG-4

DESCRIPCIÓN | Validar aislamiento del acceso por paciente.

PRECONDICIONES | Pacientes A y B sintéticos; identificador A conocido; token B.

PASOS | 1. GET /examenes/paciente/<id_A> autenticado como B. 2. Revisar HTTP y ausencia de contenido clínico ajeno. 3. Conservar evidencia del escenario concreto.

RESULTADO ESPERADO | HTTP 403 en esta ruta; sin datos de A.

CRITERIO DE ACEPTACIÓN | B no obtiene registros de A. No generalizar el resultado a todas las rutas.

DATOS DE PRUEBA | A y B del fixture; no usar IDs de pacientes reales.


## 4.5 CP-API-005 · JWT alterado y vencido

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-005 / JWT alterado y vencido / NFR-SEG-9

DESCRIPCIÓN | Rechazar tokens cuya integridad o vigencia no es válida.

PRECONDICIONES | Dos tokens sintéticos: firma alterada y expiración pasada.

PASOS | 1. Invocar ruta protegida con token alterado. 2. Repetir con vencido. 3. Revisar ambas respuestas y ausencia de datos.

RESULTADO ESPERADO | HTTP 401 en ambos intentos.

CRITERIO DE ACEPTACIÓN | Ningún token inválido concede acceso.

DATOS DE PRUEBA | JWT de QA generado para prueba; no conservar su valor en el informe.


## 4.6 CP-API-006 · Registro y adjunto PDF

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-006 / Registro y adjunto PDF / RF-3.1; RF-4.3/4.4

DESCRIPCIÓN | Validar creación, integridad del adjunto y aislamiento de descarga.

PRECONDICIONES | Médico, titular y paciente ajeno; tipo de examen y PDF sintético disponibles.

PASOS | 1. Crear examen de A. 2. Subir qa_sintetico.pdf por la ruta de documentos correspondiente. 3. Descargar como titular y comparar hash. 4. Intentar descarga como B.

RESULTADO ESPERADO | 201 al crear/subir; 200 propio, bytes íntegros; 403 ajeno.

CRITERIO DE ACEPTACIÓN | Estados, contenido/hash y autorización correctos en las cuatro operaciones.

DATOS DE PRUEBA | Tipo de examen=1 en fixture; PDF de prueba de 61 bytes, no historia clínica.


## 4.7 CP-API-007 · Persistencia de borrado lógico

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-007 / Persistencia de borrado lógico / RF-3.3

DESCRIPCIÓN | Comprobar que la baja conserva el registro clínico con marca lógica.

PRECONDICIONES | Examen descartable de QA; admin autenticado; SELECT previo.

PASOS | 1. Contar fila por ID. 2. DELETE /examenes/<id> como admin. 3. SELECT posterior incluyendo filas de baja. 4. Comprobar marca lógica y política de consulta.

RESULTADO ESPERADO | La fila permanece con marca de baja.

CRITERIO DE ACEPTACIÓN | HTTP esperado y fila conservada; no basta recibir deleted=true.

DATOS DE PRUEBA | Examen sintético creado para esta corrida; ID dinámico.


## 4.8 CP-API-008 · Contraseña con hash adaptativo

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-008 / Contraseña con hash adaptativo / NFR-SEG-2

DESCRIPCIÓN | Validar que el secreto persistido no es texto claro.

PRECONDICIONES | Cuenta sintética y lectura restringida de su registro en QA.

PASOS | 1. Crear cuenta descartable con clave conocida del fixture. 2. Leer solo el campo necesario. 3. Comparar en memoria con la entrada y reconocer formato seguro. 4. Probar login.

RESULTADO ESPERADO | Hash adaptativo; distinto de entrada; login seguro.

CRITERIO DE ACEPTACIÓN | Sin texto claro. El caso histórico esperaba bcrypt; Argon2id requiere actualizar el oráculo acordado.

DATOS DE PRUEBA | Clave sintética conocida; guardar solo booleanos, nunca imprimir el secreto.


## 4.9 CP-API-009 · Auditoría de cambio de rol con origen

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-009 / Auditoría de cambio de rol con origen / RF-5.1

DESCRIPCIÓN | Validar trazabilidad completa de un cambio privilegiado.

PRECONDICIONES | Admin y usuario descartable; payload aceptado por validador; esquema inspeccionable.

PASOS | 1. Preparar perfil válido junto con rol_id. 2. Cambiar rol como admin. 3. Consultar rol y evento asociado. 4. Revisar origen validado, actor, hora y correlación. 5. Forzar rollback controlado en prueba separada.

RESULTADO ESPERADO | Cambio autorizado y evento íntegro con origen; rollback atómico.

CRITERIO DE ACEPTACIÓN | Misma transacción, contexto confiable y evento no modificable por rol aplicativo. Si hay 400 previo, el flujo no fue ejercitado.

DATOS DE PRUEBA | Cuenta descartable; rol médico/admin del fixture; contexto de proxy explícito.


## 4.10 CP-API-010 · Médico no puede asignarse administrador

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-010 / Médico no puede asignarse administrador / NFR-SEG-4

DESCRIPCIÓN | Impedir escalamiento de privilegios por edición del perfil.

PRECONDICIONES | Médico sin admin; payload aceptado que incluye campo de perfil válido y rol_id admin; rol previo registrado.

PASOS | 1. Autenticar como médico. 2. PUT /usuarios/<id_propio> con payload válido y rol_id admin. 3. Revisar respuesta. 4. Consultar usuario_roles y conservar estado.

RESULTADO ESPERADO | HTTP 403 y rol médico conservado.

CRITERIO DE ACEPTACIÓN | Denegación de autorización efectiva; 400 por validación no confirma la protección de roles.

DATOS DE PRUEBA | Médico sintético y IDs resueltos en QA. No reenviar la solicitud histórica incompleta.


## 4.11 CP-API-011 · Latencia de consulta menor de 300 ms

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-011 / Latencia de consulta menor de 300 ms / NFR-PERF-1

DESCRIPCIÓN | Contrastar latencia observada con el objetivo histórico.

PRECONDICIONES | API y base de QA saludables; token permitido; reloj monotónico; entorno registrado.

PASOS | 1. Medir GET /examenes autorizado. 2. Revisar HTTP. 3. Registrar duración. 4. Repetir campaña separada para percentiles y carga.

RESULTADO ESPERADO | HTTP 200 y menos de 300 ms en el caso histórico.

CRITERIO DE ACEPTACIÓN | Ambas condiciones satisfechas; no confundir una medición con capacidad sostenida.

DATOS DE PRUEBA | Datos sintéticos; registrar volumen y recursos. JMeter posterior usa perfil específico.


## 4.12 CP-API-012 · Eliminar usuario sin autenticar

Campo | Definición

ID / NOMBRE / REQUERIMIENTO | CP-API-012 / Eliminar usuario sin autenticar / NFR-SEG-4

DESCRIPCIÓN | Impedir operación destructiva anónima.

PRECONDICIONES | Usuario descartable de QA sin dependencias clínicas reales; SELECT previo; solicitud sin Authorization.

PASOS | 1. Confirmar fila objetivo. 2. DELETE /usuarios/<id> sin token. 3. Revisar HTTP y cuerpo. 4. Consultar persistencia.

RESULTADO ESPERADO | HTTP 401 y cuenta intacta.

CRITERIO DE ACEPTACIÓN | No muta ninguna fila ni se generan efectos destructivos sin autenticación.

DATOS DE PRUEBA | Cuenta efímera creada para el caso; nunca una cuenta de personas reales.


## 5. Ejecución de pruebas

Los resultados siguientes provienen del expediente histórico. Durante la preparación de esta entrega no se repitieron pruebas destructivas ni carga, ni se modificó la aplicación. Separar siempre la fecha de redacción de la fecha de ejecución. La evidencia original se conserva en el ZIP con hashes de integridad.


## 5.1 Resumen de ejecución

E1 (api/resultados_api.json): 12 verificaciones, 6 PASS y 6 FAIL según el resumen original. Los PASS incluyen login, credenciales inválidas, validación de campos, bloqueo entre pacientes, JWT inválido/vencido y documento sintético. CP-API-004 retorna 403 en consulta por paciente; no prueba exhaustivamente GET /examenes/:id. Los FAIL requieren interpretar tanto código HTTP como persistencia y precondiciones.

CP-API-007: borrado devuelve 200 y quedan cero filas, incompatible con borrado lógico. CP-API-008: contraseña igual a entrada y sin formato bcrypt; evidencia de texto claro, sin imprimir la contraseña. CP-API-012: DELETE de usuario sin token devuelve 200 y borra la cuenta sintética. CP-API-011: 5.120 ms contra criterio histórico <300 ms.

CP-API-009 devuelve 400 al intentar cambiar rol; su inspección del esquema demuestra ausencia de columna IP, pero no demuestra un cambio de rol exitoso ni su auditoría. CP-API-010 devuelve 400 y conserva medico; no demuestra escalamiento. El CSV Registro_defectos.csv describe éxito en ambos y contradice el JSON. Se conserva el resumen 6/6 como dato histórico, sin contar estos dos casos como explotaciones confirmadas.

E2 (SonarQube): 1 bug, 72 code smells, 3 security hotspots, 0 vulnerabilidades clasificadas, 0,0% de cobertura y 14,5% de duplicación. Los hotspots requieren revisión humana; no equivalen automáticamente a vulnerabilidades explotables. Los temas registrados son límites de subida, CORS y huella Express. El bug CSS se refiere a familia de fuente genérica ausente.

Quality Gate: OK, conditions=[]. Ese estado no evaluó condiciones explícitas y no justifica liberación. Sin LCOV, coverage=0 no implica que las comprobaciones API no se ejecutaran: mide otra dimensión. Las capturas de métricas que se incluyan deben identificarse como exportación de datos, nunca como una captura inventada de la UI.

Total del conjunto histórico: 12 diseñados, 12 ejecutados, 6 PASS, 6 FAIL, 0 BLOCKED, 0 sin ejecutar. SonarQube es un análisis separado y la carga Node una medición adicional, no nuevos PASS funcionales. La demo de cuatro casos es otra campaña y no se suma a los 12. Herramientas propuestas sin corrida: Jest, Cypress, SCA, ZAP y JMeter; no existe una cifra de casos ejecutados atribuible a ellas.


## 5.2 Detalle de ejecución de casos

E1 corresponde al JSON api/resultados_api.json incluido en soporte. El campo executor original dice “Automatización QA asistida; validar por integrantes”. No contiene identidad personal verificable del operador, por lo que no se atribuye la ejecución humana a una operadora identificada. Antonella asume la revisión y defensa de los resultados y debe validar la ejecución si la pauta exige una firma personal.

Las fechas de cada fila son UTC según el JSON, no horarios locales reconstruidos. Para cada FAIL se adjunta evidencia del estado persistido o del error recibido. Casos 009 y 010: el rechazo de validación impide concluir éxito o fracaso del flujo de autorización pretendido; la interpretación y el retest propuesto están explícitos.

Caso / fecha UTC | Resultado y evidencia concreta | Incidente / ejecutor

CP-API-001
Login válido y JWT
2026-10-20T16:11:19.418Z | PASS · HTTP 200; firma válida=true
E1: cases[0].evidence | Sin incidente demostrado.
Automatización QA asistida, según E1.

CP-API-002
Credenciales inválidas
2026-10-20T16:11:19.577Z | PASS · HTTP 401
E1: cases[1].evidence | Sin incidente demostrado.
Automatización QA asistida, según E1.

CP-API-003
Campos obligatorios de examen
2026-10-20T16:11:24.620Z | PASS · HTTP 400
E1: cases[2].evidence | Sin incidente demostrado.
Automatización QA asistida, según E1.

CP-API-004
IDOR por paciente ajeno
2026-10-20T16:11:32.164Z | PASS · HTTP 403
E1: cases[3].evidence | Sin incidente demostrado.
Automatización QA asistida, según E1.

CP-API-005
JWT alterado y vencido
2026-10-20T16:11:32.243Z | PASS · Alterado 401; vencido 401
E1: cases[4].evidence | Sin incidente demostrado.
Automatización QA asistida, según E1.

CP-API-006
Registro y adjunto PDF
2026-10-20T16:11:37.826Z | PASS · Crear 201; subir 201; propio 200; ajeno 403
E1: cases[5].evidence | Sin incidente demostrado.
Automatización QA asistida, según E1.

CP-API-007
Persistencia de borrado lógico
2026-10-20T16:11:38.149Z | FAIL · HTTP 200; filas persistidas=0
E1: cases[6].evidence | DEF-003
Automatización QA asistida, según E1.

CP-API-008
Contraseña con hash adaptativo
2026-10-20T16:11:38.167Z | FAIL · Formato bcrypt=false; igualdad con entrada=true
E1: cases[7].evidence | DEF-002
Automatización QA asistida, según E1.

CP-API-009
Auditoría de cambio de rol con origen
2026-10-20T16:11:39.269Z | FAIL · HTTP 400; columnas=id, usuario_id, accion, fecha_hora
E1: cases[8].evidence | DEF-001 (ausencia estructural; flujo inconcluyente)
Automatización QA asistida, según E1.

CP-API-010
Médico no puede asignarse administrador
2026-10-20T16:11:39.365Z | FAIL · HTTP 400; roles=medico
E1: cases[9].evidence | DEF-005 (riesgo estático; explotación no confirmada)
Automatización QA asistida, según E1.

CP-API-011
Latencia de consulta menor de 300 ms
2026-10-20T16:11:44.487Z | FAIL · HTTP 200; 5120 ms
E1: cases[10].evidence | DEF-004
Automatización QA asistida, según E1.

CP-API-012
Eliminar usuario sin autenticar
2026-10-20T16:11:44.577Z | FAIL · HTTP 200; filas restantes=0
E1: cases[11].evidence | DEF-006
Automatización QA asistida, según E1.


## 5.3 Criticidad de incidentes

Severidad expresa impacto en el sistema clínico; prioridad expresa orden de atención. Un riesgo crítico potencial se distingue de un incidente explotado. La pérdida de integridad o confidencialidad puede ser crítica aunque el sistema siga respondiendo. El nivel no se deduce automáticamente de una ley, una multa o un código HTTP.

Nivel | Descripción / impacto | Evidencia requerida

CRÍTICO | Acción no autorizada destructiva o compromiso grave de información clínica; bloquea liberación. | Reproducción controlada y persistencia/privilegio afectado. Si solo hay código, indicar riesgo pendiente.

GRAVE | Pérdida de trazabilidad, integridad parcial, credenciales expuestas o rendimiento fuera del requisito. | Dato persistido, esquema o métrica que incumple el criterio y contexto.

MODERADO | Defecto secundario con impacto limitado y alternativa operativa segura. | Caso reproducible y alcance limitado.

LEVE | Apariencia o texto sin afectar seguridad ni operación esencial. | Captura o evidencia visual contextualizada.


## 5.3.1 Clasificación de los hallazgos

Caso / hallazgo | Resultado o estado | Impacto / prioridad

CP-API-012 · DEF-006 | 200 anónimo y fila eliminada; confirmado. | CRÍTICO · P0 · acción destructiva.

CP-API-010 · DEF-005 | 400 conserva médico; riesgo en código. | CRÍTICO potencial · P0 · reproducir y corregir autorización.

CP-API-008 · DEF-002 | Persistencia igual a la entrada; confirmado. | GRAVE · P0 · exposición de credenciales.

CP-API-007 · DEF-003 | Borrado físico; confirmado. | GRAVE · P1 · integridad clínica.

CP-API-009 · DEF-001 | Esquema sin IP; flujo de rol no ejercitado. | GRAVE · P1 · trazabilidad incompleta.

CP-API-011 · DEF-004 | 5.120 ms; lote p95 8.698 ms. | GRAVE · P1 · demora operativa.

SQLi / IDOR declarados | SQLi no corroborada; IDOR bloqueado en caso probado. | Riesgos de alto impacto si se demuestran; ampliar cobertura.

Hotspots / CSS | 3 pendientes de revisión / 1 bug de fuente genérica. | No asignar criticidad explotable sin contexto; CSS leve preliminar.


## 6. Propuesta de mejora

Prioridades propuestas: P0 impide liberación por posibilidad de daño o acceso no autorizado; P1 corrige trazabilidad, integridad y rendimiento antes de levantar las reservas. No se asigna CVSS numérico sin análisis del vector. Antonella coordina la evidencia DevSecOps y valida escenarios y cumplimiento; desarrollo implementa y el responsable del producto autoriza.

Riesgo / requisito | Evidencia y estado | Mitigación / cierre

SQLi / NFR-SEG | Controlador y línea declarados no existen. examenes.js usa $1/$2. No corroborada. | Conservar parámetros y allowlist; localizar fuente insegura si existe; pruebas adversas de entradas [T1].

IDOR / NFR-SEG-4 | CP-API-004 PASS; examenes.js:219,239 filtra paciente. Alcance parcial. | RBAC + propiedad por recurso; matriz roles×verbos×titularidad, sin devolver datos ajenos [T3].

DEF-006 / P0 | CP-API-012: sin token, 200 y cero filas. Confirmado. | Autenticación y admin antes de DELETE. Anónimo 401, no admin 403, fila intacta.

DEF-005 / P0 | users.js:453–529 admite médico en cambio de rol. Riesgo estático; CP-API-010 inconcluyente. | Solo admin cambia roles; repetir con payload válido; verificar rol y revocación de sesiones.

DEF-002 / P0 | CP-API-008: texto claro. Confirmado. | Hash adaptativo Argon2id/bcrypt, migración, comparación segura y prueba de login.

DEF-001 / P1 | init.sql:88 y CP-API-009: esquema sin IP. Cambio de rol no acreditado. | Actor/IP validada/request_id, transacción y restricciones. Pruebas de rollback y encabezado falso.

DEF-003 / P1 | CP-API-007: fila desaparece. Confirmado. | Soft delete y política de conservación; consultas excluyen baja, fila recuperable según permisos.

DEF-004 / P1 | 5.120 ms; lote Node p95 8.698 ms; delay de 5.000 ms. | Quitar simulación, perfilar SQL/pool y JMeter. Cumplir umbral acordado sin errores.


## 6.1 Remediación técnica y validación de cierre

Para DEF-001 se agregaría un evento estructurado con actor, recurso, acción, resultado, hora UTC, IP de origen validada y request_id. La IP es un dato contextual que puede corresponder a NAT/proxy; no prueba identidad por sí sola. No se registrarán JWT, contraseñas ni contenido clínico innecesario.

Express debe usar req.ip con trust proxy limitado a la topología real; el último proxy confiable debe reemplazar encabezados aportados por clientes [T2]. Fuera de esa topología, usar el origen de socket y no creer encabezados arbitrarios. Un trigger no conoce la IP HTTP; la aplicación debe pasar el contexto validado con SET LOCAL/set_config(..., true) parametrizado dentro de una transacción, usando pool.connect y un solo client hasta COMMIT/ROLLBACK.

El cambio de rol y su evento deben confirmar o revertir juntos. Revocar UPDATE/DELETE de auditoria al rol aplicativo, separar el rol propietario y los privilegios de migración, y proteger copias externas con verificación de integridad. Un trigger o una tabla append-only por permisos no impiden por sí solos la manipulación por un superusuario. El período de retención y la supresión necesitan política aprobada y revisión sectorial.

Autorización: separar actualizar perfil de administrar roles; exigir admin de forma explícita para rol_id. Verificar pertenencia del recurso en cada operación clínica. El JWT identifica la sesión; no autoriza automáticamente una acción. Usar denegación por defecto, pruebas negativas y registro de denegaciones sin filtrar información sensible.


## 6.2 Rendimiento, usabilidad y confiabilidad

E3: carga_200_real.json identifica la herramienta como Node.js fetch. El lote alcanza max_in_flight=200, dura 9.321 ms y reporta p50=8.537 ms, p95=8.698 ms, p99=8.713 ms y cero errores. No es JMeter ni prueba prolongada de 200 usuarios. El campo users=200 del JSON no cambia la naturaleza de la medición.

En examenes.js:46,99,330 hay delayMiddleware(5000). Retirar o desactivar esa simulación en el entorno objetivo es previo a la optimización. El esquema ya contiene índice por paciente; no duplicarlo por intuición. Analizar planes de ejecución con datos representativos, esperas, CPU, memoria, I/O y pool. El límite global de conexiones debe contemplar réplicas de API y reserva operativa; un pool mayor no garantiza menor latencia.

Perfil JMeter propuesto: 200 usuarios virtuales, rampa 60 s, meseta 5 min y pausas entre operaciones. Mezcla inicial a acordar: 70% consulta propia, 20% listado autorizado y 10% creación sintética. Las sesiones usan cuentas/token propios y verifican estado, cuerpo y ausencia de datos ajenos. Medir por transacción, no mezclar login y descarga en un único p95. Tres repeticiones comparables; limpiar solo datos de la corrida. Conservar JMX, JTL, dashboard HTML y telemetría.

Criterio histórico: menos de 300 ms. Se propone operacionalizarlo como p95 por operación y cero errores inesperados, sujeto a aprobación docente/ERS. El contexto nuevo indica 450 ms sin justificación de cambio; no se sustituye silenciosamente. Recursos limitados del computador pueden sesgar los resultados; la medición de capacidad necesita un generador aislado del objetivo.

ISO/IEC 25010:2011 se usa por continuidad con los antecedentes; es una edición retirada y existe ISO/IEC 25010:2023 [T6]. No se presenta 2011 como edición vigente ni se mezclan sus categorías con las nuevas. Adecuación funcional se relaciona con persistencia y permisos; eficiencia con latencia/recursos; seguridad con autorización/auditoría; usabilidad con pruebas de tareas. WCAG 2.1 AA requiere todos los criterios A y AA del alcance, con teclado, foco, contraste, formularios, errores, lector de pantalla y revisión manual [T4]. No existe evidencia suficiente para declarar conformidad completa.


## 6.3 Plan de mantenimiento y mejora continua

Plan de preservación de calidad: las frecuencias son una propuesta del equipo, no plazos legales. Cada defecto se gestiona con responsable, impacto, prioridad, versión afectada, cambio implementado, evidencia anterior/posterior y aprobación. No se cierra por modificar código sin repetir el caso que fallaba.

Definition of Done propuesta: cero fallos críticos de autorización y persistencia; credenciales protegidas; auditoría transaccional; riesgos SQLi/IDOR revisados; hotspots evaluados; reportes SCA/DAST sin riesgos de bloqueo sin resolver; cobertura y rendimiento acordados cumplidos. Si una herramienta no se ejecuta, el gate queda bloqueado o requiere una excepción explícita documentada; nunca se inventa un PASS.

Frecuencia / disparador | Acción y responsable | Evidencia / respuesta

Cada PR / push | Antonella: CI, pruebas, SAST/SCA y secretos | Reportes por commit; bloquear fallos críticos.

Semanal | Antonella + desarrollo: nuevas CVE y dependencias | Triage y parche priorizado; regresión.

Cada release | Antonella: E2E, autorización, DAST y carga representativa | Acta de gate y aprobación del producto.

Mensual | Operaciones + equipo: restauración aislada | Integridad restaurada; registrar RPO/RTO medidos, metas por acordar.

Trimestral | Antonella: roles, retención, accesibilidad e imágenes | Revisión de accesos, política, WCAG y componentes soportados.

Incidente / cambio legal | Responsable institucional + cumplimiento | Contener, preservar evidencia, evaluar reporte y actualizar controles.


## 6.4 Dictamen, reservas y trazabilidad docente

Dictamen académico solicitado: CERTIFICADO CON RESERVAS. Decisión operativa: BLOQUEADO PARA PRODUCCIÓN. El rótulo no representa certificación oficial, cumplimiento legal integral ni autorización de uso clínico. El informe anterior mantenía no certificado: sin retests de cierre no se acredita un avance técnico que permita levantar el bloqueo.

La pauta EP5 asigna IE1 30% (enfoques), IE3 14% (diagrama), IE5 24% (automatización), IE7 20% (mantenimiento) e IE9 12% (documentación). La ponderación de presentación 24% proviene de la instrucción pegada por la estudiante; no se confunde con IE5 24%. El encargo es grupal y la defensa individual. Se preparan 10 minutos de exposición y 5 de preguntas.

Entrega docente: informe, diapositivas utilizadas y video con participación de Antonella Cuvertino. Este paquete incluye el guion de grabación; el video debe grabarlo la estudiante. Institución: Duoc UC. Carrera: Ingeniería Informática, Desarrollo de Software.

Pendientes técnicos antes de afirmar implementación completa: ejecutar herramientas propuestas y guardar artefactos, corregir defectos y repetir pruebas, resolver contradicciones del CSV, ratificar ERS y umbrales, revisar obligaciones sectoriales y confirmar criterios de gate. La documentación es una preparación sustentada; no acredita que estos trabajos ya se hayan realizado.

Indicador | Ubicación actual del informe | Lámina

IE1 · enfoques 30% | 3.2–3.4 y 5.1 | 3–6

IE3 · diagramas 14% | 3.1: pipeline vectorial | 2–3,7

IE5 · automatización 24% | 4: fichas; 5.1–5.2: resultados | 4–5,8

IE7 · mantenimiento 20% | 6.3: frecuencia, responsables y cierre | 10

IE9 · documentación 12% | Índice, evidencia, matriz y fuentes | Todas

[L1] Ley 19.628, versión aplicable antes del cambio de régimen. https://www.bcn.cl/leychile/navegar?idNorma=141599&idVersion=2026-11-16

[L2] Ley 21.719, disposiciones y vigencia diferida. https://www.bcn.cl/leychile/navegar?f=2026-12-01&i=1209272

[L3] Ley 21.663, ámbito, deberes e incidentes. https://www.bcn.cl/leychile/navegar?i=1202434

[L4] ANCI: obligación de reportar incidentes significativos. https://anci.gob.cl/noticias/obligacion-de-reportar/

[T1] node-postgres: consultas parametrizadas y prepared statements. https://node-postgres.com/features/queries

[T2] Express: configuración segura detrás de proxies. https://expressjs.com/en/guide/behind-proxies/

[T3] OWASP Top 10:2021, A01 Broken Access Control. https://top10.owasp.org/2021/A01_2021-Broken_Access_Control/

[T4] W3C: WCAG 2.1, conformidad nivel AA. https://www.w3.org/TR/2023/REC-WCAG21-20230921/

[T5] GitHub: runners propios y conectividad. https://docs.github.com/en/actions/reference/runners/self-hosted-runners

[T6] ISO/IEC 25010:2011, modelo empleado en los antecedentes. https://www.iso.org/standard/35733.html

[T7] Apache JMeter: ejecución no gráfica y resultados. https://jmeter.apache.org/usermanual/get-started.html

[T8] OWASP ZAP: baseline pasivo y límites. https://www.zaproxy.org/docs/docker/baseline-scan/