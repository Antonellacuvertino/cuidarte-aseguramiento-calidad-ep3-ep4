# Guion de defensa y video

10 minutos + 5 minutos de preguntas.


## 1. Cuidarte+ | decisión de liberación
Antonella · 00:00–01:00

- Exámenes y fichas médicas: confidencialidad, integridad y disponibilidad.

- Antonella Cuvertino: QA, DevSecOps y revisión de cumplimiento.

- Certificado con reservas: dictamen académico condicionado.

- Producción BLOQUEADA hasta cerrar riesgos y verificar regresión.

Visual: Tarjeta de decisión con bloqueo de producción y responsable individual.

Buenos días. Soy Antonella Cuvertino. Presento la evaluación final de Cuidarte+, un sistema que trata información clínica. Nuestro objetivo es decidir si existen condiciones verificables para liberar, y cómo mantener esas condiciones. Aplicamos el feedback recibido: para cada conclusión indicaremos el requisito, la evidencia concreta y la razón de su prioridad. Utilizamos resultados históricos del veinte de octubre y una revisión actual del código; no los presentamos como una nueva ejecución. El dictamen académico solicitado es certificado con reservas, con producción bloqueada. Esa denominación no constituye una certificación legal ni una autorización operativa. Primero explicaremos el entorno y el pipeline; después, los resultados, mitigaciones y condiciones de cierre.


## 2. Arquitectura y alcance de la evidencia
Antonella · 01:00–02:00

- React → Express → PostgreSQL; SonarQube analiza el código.

- Compose: web 3333; API 4444 → 4000; PostgreSQL 15442 → 5432.

- QA aislada: web 3334, API 4445, PostgreSQL 15443.

- PostgreSQL usa protocolo PostgreSQL: no es una página HTTP.

Visual: Diagrama de cuatro nodos con puertos de host y contenedor diferenciados.

La aplicación separa React, Express y PostgreSQL. El Compose declara el frontend en el puerto tres tres tres tres y la API en cuatro cuatro cuatro cuatro, dirigida al puerto interno cuatro mil. La base publica por defecto quince mil cuatrocientos cuarenta y dos hacia cinco mil cuatrocientos treinta y dos; este último es el puerto interno, no una dirección HTTP. La evidencia histórica proviene de un entorno QA separado, con datos sintéticos y API en cuatro cuatro cuatro cinco. SonarQube utiliza el puerto nueve mil. Dentro de Docker se usan nombres de servicio: localhost identifica el contenedor actual. Esta distinción permite reproducir pruebas sin confundir el laboratorio con producción.


## 3. Pipeline DevSecOps: diseño objetivo
Antonella · 02:00–03:00

- Push / pull request → instalación reproducible y revisión de secretos.

- Jest + SCA + SonarQube → entorno Docker efímero.

- Cypress + ZAP autenticado → JMeter programado / manual.

- Evidencias por commit → decisión humana → despliegue bloqueado.

Visual: Flujo por etapas con gate que conecta permisos, datos sintéticos y trazabilidad.

Este diagrama muestra el pipeline objetivo, no una ejecución de GitHub Actions que no podamos acreditar. Un push o pull request dispara instalación reproducible, revisión de secretos, pruebas Jest, análisis de dependencias y SonarQube. En un entorno efímero se ejecutan Cypress y ZAP con identidades de prueba. La carga de doscientos usuarios se reserva para ejecución programada o manual en infraestructura dedicada, para no bloquear cada commit ni saturar el equipo. Cada resultado debe vincularse al commit y conservarse sin datos clínicos ni tokens. Un runner de GitHub no accede al localhost de mi computador; requiere su propio SonarQube o conectividad controlada. La decisión final de liberar exige evidencias y aprobación.


## 4. Automatización: función y estado real
Antonella · 03:00–04:00

- Ejecutado: scripts Node de API y análisis SonarQube.

- Jest / Cypress: diseño pendiente de implementación y ejecución.

- npm audit o Snyk: inventario y reporte SCA pendientes.

- ZAP / JMeter: pendientes; no sustituirlos por resultados Node.

Visual: Matriz de seis herramientas: función, evidencia esperada y estado.

Cada herramienta responde una pregunta distinta. Jest comprueba unidades y, con una base de prueba, integración; su evidencia será JUnit y LCOV. Cypress valida recorridos reales del navegador y sus estados visibles. SonarQube revisa patrones del código y dependencias de flujo que soporte su analizador; no reemplaza la autorización de negocio. npm audit o Snyk identifica riesgos conocidos en dependencias, sin afirmar explotabilidad automáticamente. ZAP observa la aplicación en ejecución; un baseline pasivo no equivale a un examen activo autenticado. JMeter mide comportamiento bajo un perfil de carga documentado. Actualmente acreditamos scripts Node y SonarQube; las otras herramientas están propuestas. Esta separación evita que una lista de tecnologías se confunda con cobertura demostrada.


## 5. Resultados: evidencia antes que etiquetas
Antonella · 04:00–05:00

- API: 12 verificaciones → 6 PASS / 6 FAIL; revisar semántica de fallos.

- SonarQube: 1 bug, 72 smells, 3 hotspots, 0 vulnerabilidades detectadas.

- Cobertura 0,0%: no se importó LCOV; gate OK sin condiciones.

- CP-API-010: HTTP 400; el CSV sobreafirma escalamiento exitoso.

Visual: Indicadores API y SAST con nota sobre gate y discrepancia documental.

El resumen crudo conserva doce verificaciones con seis aprobadas y seis fallidas. Debemos interpretar cada fallo: una respuesta distinta de la esperada no prueba por sí sola una explotación. SonarQube reporta un bug, setenta y dos code smells y tres hotspots por revisar, sin vulnerabilidades clasificadas. Eso significa que el analizador no detectó vulnerabilidades en ese alcance; no demuestra seguridad integral. La cobertura aparece en cero porque no se importó LCOV y el gate está en OK con una lista vacía de condiciones. Además, el CSV dice que un médico obtuvo rol administrador, pero el JSON muestra HTTP cuatrocientos y mantiene el rol médico. Corregimos esa afirmación y exigimos reproducción.


## 6. Matriz de riesgos y mitigación prioritaria
Antonella · 05:00–06:00

- SQLi declarada: no corroborada; consultas observadas con $1 / $2.

- IDOR en /examenes/:id: filtro de titular; ampliar pruebas por recurso.

- Crítico confirmado: DELETE /usuarios/:id sin token elimina la fila.

- Roles: riesgo en código; exigir admin y reproducir con payload válido.

Visual: Matriz estado / prioridad / corrección / criterio de cierre.

La primera prioridad confirmada es la eliminación anónima de usuarios: la prueba esperaba cuatrocientos uno, recibió doscientos y la fila desapareció. Debe exigirse autenticación y autorización administrativa antes de modificar datos. La inyección SQL del archivo y línea indicados no está corroborada: ese controlador no existe en esta versión y las consultas examinadas usan parámetros. La mantenemos como riesgo a validar, no como vulnerabilidad demostrada. En la ruta de exámenes por identificador existe un filtro de paciente, y la prueba entre pacientes bloqueó el acceso en otra ruta. Eso no cubre todos los recursos. Finalmente, el código permite al médico cambiar su propio rol; requiere corrección preventiva y reproducción con un cuerpo aceptado por el validador.


## 7. DEF-001: auditoría confiable y atómica
Antonella · 06:00–07:00

- Tabla real: auditoria; no registra IP del cliente.

- Capturar req.ip con proxy confiable; no aceptar X-Forwarded-For a ciegas.

- Cambio + evento en una transacción y una conexión.

- Rol aplicativo sin UPDATE / DELETE de auditoría; retención controlada.

Visual: Cliente → proxy confiable → Express → transacción → auditoría protegida.

El requisito de trazabilidad exige reconstruir quién cambió qué y desde dónde. La tabla real se llama auditoria y el esquema solo contiene identificador, usuario, acción y fecha. Esto demuestra ausencia estructural de IP, pero la prueba de cambio de rol devolvió cuatrocientos; no acredita un cambio exitoso auditado. La mitigación debe capturar req.ip con una política explícita de proxies confiables. Copiar cualquier X-Forwarded-For permitiría falsificar el origen. Un trigger de PostgreSQL no conoce por sí solo la IP HTTP: Express debe transmitir un contexto validado dentro de la misma conexión y transacción. Restringiremos modificación de eventos y verificaremos rollback, suplantación de encabezados y conservación. La IP aporta contexto; no identifica inequívocamente a una persona.


## 8. DEF-004: rendimiento con causa y medida
Antonella · 07:00–08:00

- 200 solicitudes Node: p95 = 8.698 ms; 0 errores; lote de 9,3 s.

- Hay delayMiddleware(5000): índices no eliminan esa demora.

- Meta histórica <300 ms; 450 ms del contexto no está aprobado.

- JMeter: 200 usuarios, rampa 60 s, meseta 5 min, p95 y errores.

Visual: Barra comparativa objetivo 300 ms / demora artificial 5.000 / p95 8.698.

La evidencia de carga es un lote Node de doscientas solicitudes simultáneas que duró aproximadamente nueve segundos. El percentil noventa y cinco fue ocho mil seiscientos noventa y ocho milisegundos, sin errores. No equivale a doscientos usuarios sostenidos en JMeter. En el código existe una demora intencional de cinco segundos antes de varias operaciones; por ello, agregar índices no resuelve la causa principal. Primero retiraremos esa simulación del entorno objetivo, después revisaremos planes de ejecución e índices existentes y dimensionaremos el pool con mediciones. El antecedente usa menos de trescientos milisegundos; los cuatrocientos cincuenta del contexto requieren acuerdo. Proponemos JMeter con rampa, meseta y métricas de aplicación y base, conservando JTL y reporte HTML.


## 9. Normativa: controles verificables
Antonella · 08:00–09:00

- Ley 19.628: régimen aplicable; confidencialidad de información de salud.

- Ley 21.719: preparar transición; vigencia general 01 dic 2026 [L2].

- Ley 21.663: verificar sujeto obligado; incidente significativo ≠ todo defecto.

- ISO/IEC 25010:2011 + WCAG 2.1 AA: objetivos con evidencia pendiente.

Visual: Matriz norma → control → evidencia y línea temporal de transición.

Al corte de preparación, la Ley diecinueve mil seiscientos veintiocho es el régimen aplicable. La Ley veintiún mil setecientos diecinueve tiene entrada general prevista para el primero de diciembre de dos mil veintiséis según el texto oficial consultado; planificamos la transición sin presentarla como vigente hoy. Para la Ley de Ciberseguridad debemos verificar el encuadre de CreaLab y del prestador de salud. La falta de una IP no determina automáticamente una infracción ni una multa. Los incidentes significativos activan deberes de reporte para sujetos obligados; no se reporta cada defecto como incidente. ISO e indicadores de accesibilidad orientan pruebas, pero no permiten declarar conformidad completa sin evaluar el alcance y todos los criterios aplicables.


## 10. Reservas, mantenimiento y cierre
Antonella · 09:00–10:00

- P0: cerrar borrado anónimo y riesgo de privilegios; proteger credenciales.

- Validar SQLi e IDOR, completar auditoría y regresión negativa.

- Cada PR: controles; semanal: dependencias; mensual: restauración.

- Liberar solo con evidencias por versión y aprobación de responsables.

Visual: Gate cerrado y hoja de ruta: corregir → retestar → revisar → autorizar.

Nuestro dictamen académico es certificado con reservas, con producción bloqueada. Las reservas solicitadas abarcan SQLi, IDOR y auditoría, pero las dos primeras requieren validación del alcance y no pueden presentarse como explotaciones comprobadas. Agregamos los riesgos confirmados de borrado anónimo, credenciales sin hash y eliminación física de exámenes, además del riesgo de privilegios observado en código. Como responsable de la evaluación, coordinaré gates, evidencias, casos, trazabilidad y cumplimiento; el responsable del producto aprobará la liberación. Proponemos controles en cada pull request, revisión semanal de dependencias y ejercicio mensual de restauración. El cierre exige correcciones, regresión negativa, auditoría íntegra y pruebas de carga representativas. Conozco el proyecto completo y puedo defender el requisito, la evidencia y la prioridad de cada decisión.


## Pregunta 1: ¿Cómo certifican con reservas si hay riesgos críticos y el informe anterior decía no certificado?

El rótulo solicitado es un dictamen académico condicionado. Conservamos la decisión operativa de no liberar; no hay certificación externa ni aceptación de riesgo clínico. El informe previo no certificado y el nuevo rótulo no demuestran una mejora técnica: no se ha acreditado cierre de defectos. El gate permanece cerrado por el borrado anónimo confirmado, credenciales inseguras y demás reservas. Solo cambiará la decisión operativa con retests por versión y aprobación documentada.

Apoyo: CP-API-012, CP-API-008, láminas 1 y 10.


## Pregunta 2: ¿Dónde está exactamente la SQLi de la línea 42 y por qué no la detectó SonarQube?

No podemos afirmar ese hallazgo: BACKEND/src/controllers/examenes.controller.js no existe en el árbol revisado. En BACKEND/src/routes/examenes.js se observan parámetros $1/$2 y campos dinámicos limitados por una lista permitida. node-postgres separa datos del SQL; una prepared statement con nombre no es requisito para que esa parametrización sea segura. Los identificadores dinámicos necesitan allowlist. Debemos identificar versión, entrada y consulta insegura antes de atribuir SQLi. Cero vulnerabilidades SAST detectadas no elimina puntos ciegos ni sustituye pruebas manuales y DAST.

Apoyo: T1, examen de rutas; no hay prueba SQLi ejecutada.


## Pregunta 3: Si el paciente B recibió 403, ¿por qué hablan de IDOR y de riesgo de roles?

Ese 403 valida únicamente el escenario ejercitado de consulta por paciente; no acredita todos los endpoints y verbos. GET /examenes/:id aplica además un filtro por paciente y puede devolver 404 sin filtrar datos ajenos. Deben probarse titular, otro paciente, anónimo, médico y admin, también en actualización, borrado y adjuntos. RBAC resuelve funciones; el control de propiedad resuelve recursos. Por separado, users.js permite el cambio de rol propio a un médico por isAdminOrMedico. La prueba guardada quedó en 400 y no demuestra escalamiento exitoso. Es un riesgo de código pendiente de reproducción.

Apoyo: T3, CP-API-004 y CP-API-010, users.js:453–529.


## Pregunta 4: ¿Un trigger puede guardar la IP real e impedir cualquier modificación de la auditoría?

No por sí solo. La base ve la conexión de Express, no la IP HTTP del paciente. Express valida el origen según proxies confiables y pasa actor, request_id e IP a una transacción en una sola conexión; si se usa un trigger, este lee ese contexto transaccional. No se confía ciegamente en X-Forwarded-For ni en inet_client_addr como IP final. Se revocan UPDATE/DELETE al rol de aplicación, se limita quién puede insertar y se agrega copia externa con integridad y retención. Un superusuario de la base sigue siendo un límite de confianza: no prometemos inmutabilidad absoluta.

Apoyo: T2, init.sql:87–93. Propuesta pendiente de implementación.


## Pregunta 5: ¿Qué ley está vigente y debemos reportar cada error a la ANCI?

Al 16 de noviembre de 2026 distinguimos la Ley 19.628 aplicable y la transición de la Ley 21.719, cuya vigencia general figura el 1 de diciembre de 2026 en la fuente oficial consultada. En ciberseguridad debemos determinar si la organización es sujeto obligado; un centro de salud y un proveedor de software no se califican automáticamente de la misma forma. No todo defecto es un incidente significativo. Para sujetos obligados, ante uno de esos incidentes corresponde la alerta temprana dentro de tres horas desde su conocimiento, y las actualizaciones aplicables. La omisión de IP no genera por sí sola una multa automática ni un reporte.

Apoyo: L1–L4. Revalidar vigencia si cambia la fecha de defensa.


## Pregunta 6: ¿Por qué JMeter 200 usuarios e índices no bastan para demostrar rendimiento?

Porque todavía no existe un JTL ni una ejecución JMeter acreditada. El lote Node de 200 solicitudes mide una ráfaga breve: p95 8.698 ms y cero errores. Usuarios virtuales requieren sesiones, mezcla de operaciones, rampa, tiempo de espera y meseta. El delay de 5.000 ms establece una demora base que no desaparece con índices. Después de retirarlo, revisaremos EXPLAIN ANALYZE en QA, volumen, CPU, locks y espera del pool; ya existe índice por paciente. El objetivo histórico es menor de 300 ms; cualquier umbral de 450 ms debe aprobarse explícitamente.

Apoyo: carga_200_real.json, delayMiddleware, DEF-004.


## Pregunta 7: ¿Cómo llega GitHub Actions a SonarQube en localhost y qué ocurre si falla un escáner?

localhost del runner no es mi computador. Proponemos levantar SonarQube y la app en la red efímera del runner, o usar un servicio alcanzable mediante conectividad autorizada. Un runner propio requiere aislamiento y no debe ejecutar código de forks no confiables con secretos. Un error de conexión es ERROR/BLOCKED, nunca PASS. El gate combina exit codes, calidad de datos y reglas explícitas: cero fallos críticos de autorización, hotspots revisados y cobertura del código nuevo acordada. Los tokens se guardan como secretos y el despliegue permanece bloqueado hasta completar evidencia.

Apoyo: T5; quality_gate.json tiene conditions vacío. Diseño no desplegado.


## Pregunta 8: ¿La minimización obliga a borrar exámenes y unas pruebas visuales bastan para WCAG AA?

La minimización exige justificar finalidad, campos, permisos y retención; no equivale a borrar indiscriminadamente información clínica. La conservación y los derechos de titulares deben conciliarse con obligaciones sectoriales aplicables, que deben revisarse por separado. Soft delete conserva la fila y reduce pérdida accidental, pero no sustituye una política de supresión ni backups. WCAG 2.1 AA requiere todos los criterios A y AA del alcance: teclado, foco, contraste, etiquetas y errores, entre otros. Automatización parcial y tamaño de letra no bastan; faltan evaluación manual, tecnologías de apoyo y evidencias por criterio.

Apoyo: L1–L2, T4; CP-API-007. No se declara conformidad WCAG completa.

La entrega audiovisual debe mostrar participación real de Antonella Cuvertino. Este paquete no contiene un video ni simula su voz o participación. Grabar con las 10 láminas y el mismo reparto de un minuto por lámina; si el docente fija otra duración para el video, ajustar ese requisito específico. No hay duración de video independiente confirmada en el mensaje recibido.

Preparación: abrir 02_Presentacion_EP6.pdf o el PPTX editable, probar micrófono y compartir una sola ventana. Usar MP4 con pantalla legible (preferentemente 1920×1080) y audio claro. Es una recomendación técnica, no una exigencia adicional de la pauta. No mostrar claves de SonarQube, .env, tokens ni información de pacientes reales.

Storyboard individual: 00:00–01:00 Antonella se presenta y explica la decisión; 01:00–02:00 explica arquitectura; continúa con un minuto por lámina hasta 10:00. Mostrar rostro o identificación según la modalidad de grabación elegida y explicar personalmente el contenido técnico.

La exposición de 10 minutos ya ocupa todo el tiempo. La demo en vivo no se añade sin recortar: si la eligen, reemplazar 30–40 segundos de la lámina 5 por la ejecución preparada de Ejecutar-Pruebas.ps1 y explicar el FAIL de borrado. No ejecutar carga, escaneos ni arranques pesados durante la defensa. Ante fallo de entorno, volver a JSON/PDF identificado como evidencia histórica, sin afirmar que se ejecutó en ese momento.

Ensayo de preguntas (5 minutos): practicar respuestas de 30–40 segundos a cuatro o cinco preguntas elegidas del banco. Antonella debe poder responder preguntas sobre las 10 láminas. Cuando falte evidencia, responder: no está acreditado; este es el control propuesto y este es el artefacto que falta.

Antes de subir: revisar nombre, carrera y fecha; reproducir todo el MP4 para verificar audio y participación; comprobar que los PDF y PPTX coinciden; confirmar en AVA el apartado EP6 indicado por el docente y las restricciones de tamaño/formato. Entregar el informe, las diapositivas utilizadas y el video. El ZIP es soporte adicional si el docente lo admite, no reemplaza esos tres elementos.