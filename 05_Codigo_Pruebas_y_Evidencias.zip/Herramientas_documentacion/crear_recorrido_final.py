from pathlib import Path
import sys,json,html,difflib,zipfile,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.qa_tools/python'));sys.path.insert(0,str(ROOT/'.qa_tools'))
from actualizar_con_campana import CAUSES,observado
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from xml.sax.saxutils import escape
lab=ROOT/'03_LABORATORIO_FINAL';out=ROOT/'ENTREGA_FINAL_EP5_EP6'
before=json.loads((lab/'resultados/antes.json').read_text(encoding='utf-8'));after=json.loads((lab/'resultados/despues.json').read_text(encoding='utf-8'))
assert before['summary']['total']==after['summary']['total']==20
b={r['id']:r for r in before['results']};a={r['id']:r for r in after['results']}
rows=[{'id':cid,'title':r['title'],'requirement':r['requirement'],'steps':r['steps'],'expected':r['expected'],'before':b[cid],'after':r,'cause':CAUSES.get(cid,('CONTROL CONSERVADO','Sigue pasando en el alcance definido.'))} for cid,r in a.items()]
data=json.dumps({'before':before,'after':after,'rows':rows},ensure_ascii=False).replace('<','\\u003c')
report='''<!doctype html><html lang="es"><meta charset="utf-8"><title>Cuidarte+ | Recorrido de pruebas reales</title><style>
*{box-sizing:border-box}body{font:17px Arial;margin:0;color:#15324a;background:#edf3f7}header{background:#102a43;color:white;padding:25px 40px}h1{font-size:30px;margin:8px 0}header p{margin:5px 0}main{max-width:1400px;margin:auto;padding:25px}.summary{display:flex;gap:20px}.summary article{background:white;padding:18px 25px;flex:1;border-left:6px solid #007f83}.summary strong{font-size:28px}button,select{padding:13px;margin:16px 7px 16px 0;border:1px solid #007f83;background:white;color:#15324a;font-size:16px;border-radius:5px;cursor:pointer}table{width:100%;border-collapse:collapse;background:white;font-size:15px}th,td{text-align:left;padding:12px;border-bottom:1px solid #d8e2e9;vertical-align:top}th{background:#dbe9ef}.PASS{color:#00695c;font-weight:bold}.FAIL{color:#a7353c;font-weight:bold}.BLOCKED{color:#9b6600;font-weight:bold}.panel{background:white;padding:25px;margin-top:20px}pre{font:14px Consolas,monospace;white-space:pre-wrap;word-break:break-word;background:#f2f5f8;padding:15px}.columns{display:grid;grid-template-columns:1fr 1fr;gap:20px}.note{font-size:14px;color:#435b70}a{color:#007f83}.hidden{display:none}h2{font-size:24px}#causa{border-left:5px solid #e3a62f;padding:15px;background:#fff9eb}
</style><header><p>ANTONELLA CUVERTINO · DUOC UC · ISY1102 · SECCIÓN 02V</p><h1>Cuidarte+ · pruebas, correcciones y retest</h1><p>Reporte generado desde los JSON reales. No es una captura de SonarQube, Jest ni JMeter.</p></header><main><section class="summary" id="summary"></section><p class="note" id="dates"></p><button onclick="verTabla()">Todos los casos</button><button onclick="mostrarCaso('FIN-08')">1. Borrado anónimo</button><button onclick="mostrarCaso('FIN-11')">2. Cambio de rol</button><button onclick="mostrarCaso('FIN-13')">3. IP y auditoría</button><button onclick="mostrarCaso('FIN-15')">4. Error que persiste</button><a href="http://127.0.0.1:3344/login" target="_blank">Abrir app QA</a><select id="selector" onchange="mostrarCaso(this.value)"></select><section id="tabla"></section><section id="detalle" class="panel hidden"></section><p class="note">Antes: API 4446. Después: API 4447. Base QA: 15444. La fecha del reporte no sustituye la fecha UTC de ejecución. Repetir: Ejecutar-Pruebas.ps1 -Fase antes o despues.</p></main><script>const DATA=__DATA__;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
document.querySelector('#summary').innerHTML=[['ANTES',DATA.before],['DESPUÉS',DATA.after]].map(([name,d])=>`<article>${name}<br><strong>${d.summary.pass} PASS / ${d.summary.fail} FAIL</strong><br>${d.summary.total} casos · ${d.summary.blocked} bloqueados</article>`).join('');
document.querySelector('#dates').textContent='Ejecución UTC: antes '+DATA.before.date_utc+' · después '+DATA.after.date_utc;
document.querySelector('#selector').innerHTML=DATA.rows.map(r=>`<option value="${r.id}">${r.id} · ${esc(r.title)}</option>`).join('');
document.querySelector('#tabla').innerHTML='<table><thead><tr><th>Caso / requisito</th><th>Objetivo</th><th>Antes</th><th>Después</th><th>Estado</th></tr></thead><tbody>'+DATA.rows.map(r=>`<tr onclick="mostrarCaso('${r.id}')" style="cursor:pointer"><td>${r.id}<br>${esc(r.requirement)}</td><td>${esc(r.title)}</td><td class="${r.before.status}">${r.before.status}</td><td class="${r.after.status}">${r.after.status}</td><td>${esc(r.cause[0])}</td></tr>`).join('')+'</tbody></table>';
function verTabla(){document.querySelector('#tabla').classList.remove('hidden');document.querySelector('#detalle').classList.add('hidden')}
function mostrarCaso(id){let r=DATA.rows.find(r=>r.id===id);document.querySelector('#selector').value=id;document.querySelector('#tabla').classList.add('hidden');let el=document.querySelector('#detalle');el.classList.remove('hidden');el.innerHTML=`<h2>${r.id} · ${esc(r.title)}</h2><p><b>Requisito:</b> ${esc(r.requirement)}</p><p><b>Recorrido:</b> ${esc(r.steps)}</p><p><b>Esperado:</b> ${esc(r.expected)}</p><div class="columns">${[['ANTES',r.before],['DESPUÉS',r.after]].map(([name,x])=>`<article><h3>${name} · <span class="${x.status}">${x.status}</span></h3><pre>${esc(JSON.stringify(x.evidence||x.error,null,2))}</pre><p class="note">${esc(x.date_utc)}</p></article>`).join('')}</div><div id="causa"><b>${esc(r.cause[0])}</b><p>${esc(r.cause[1])}</p></div>`;window.scrollTo(0,0)}
</script></html>'''.replace('__DATA__',data)
(lab/'Recorrido_Pruebas.html').write_text(report,encoding='utf-8')
capture_plan=[
 ('01_login_app.png','Inicio de la app','Abrir http://127.0.0.1:3344/login. Capturar URL, formulario y contexto QA, sin escribir la clave en pantalla.'),
 ('02_login_incorrecto.png','Validación visible de login','Introducir usuario sintético y clave incorrecta; capturar mensaje visible sin secretos. Vincular con FIN-03; la captura UI es una comprobación distinta del HTTP automatizado.'),
 ('03_app_admin.png','Recorrido real de la aplicación','Ingresar como qa_final_admin; capturar pantalla principal con sesión QA. Recorrer usuarios/exámenes según menú disponible. No afirmar un E2E completo por llegar a home.'),
 ('04_resumen_pruebas.png','Resumen antes / después','Abrir Recorrido_Pruebas.html, Todos los casos. Mostrar los dos totales y la fecha registrada. Explicar que es un reporte de los JSON, no un nuevo escaneo.'),
 ('05_borrado_comparado.png','Defecto corregido: borrado anónimo','Seleccionar FIN-08. Mostrar 200 y rows_after=0 antes; 401 y fila conservada después. Relacionar NFR-SEG-4 y protección previa a DELETE.'),
 ('06_roles_comparados.png','Defecto corregido: escalamiento','Seleccionar FIN-11. Mostrar payload válido, respuesta y roles_after en ambas fases. No usar el 400 de octubre como prueba de explotación.'),
 ('07_auditoria_ip.png','Corrección parcial de auditoría','Seleccionar FIN-13. Mostrar ausencia/presencia de ip_origen y el XFF de prueba. Explicar que no prueba inmutabilidad.'),
 ('08_rollback_pendiente.png','Fallo persistente ante error controlado','Seleccionar FIN-15. Mostrar HTTP 500 y roles_before/after. Explicar trigger temporal de QA, su retiro y falta de transacción en PUT.'),
 ('09_rendimiento_pendiente.png','Demora con causa identificada','Seleccionar FIN-18 y abrir examenes.js en VS Code para capturar delayMiddleware(5000). No llamarlo prueba JMeter ni capacidad de 200 usuarios.'),
 ('10_cambio_codigo.png','Cambios de código','En VS Code comparar version_antes/BACKEND/src/routes/users.js con BACKEND/src/routes/users.js. Capturar requireAdmin, isAdmin y actor usuarioId. Añadir migración IP si se explica ese parche. No capturar db.js, .env, JWT o contraseñas.'),
]
steps=[
 ('1. Preparar entorno','Abrir Docker Desktop. En PowerShell: powershell -NoProfile -ExecutionPolicy Bypass -File .\\03_LABORATORIO_FINAL\\Iniciar-Laboratorio.ps1. Levanta API antes 4446, API después 4447 y bases QA distintas en 15444. No usa los puertos de producción ni resetea bases ajenas.'),
 ('2. Ejecutar antes','Ejecutar: .\\03_LABORATORIO_FINAL\\Ejecutar-Pruebas.ps1 -Fase antes. Guardar consola y resultados/antes.json. Exit code 1 significa que hay pruebas FAIL. No editar el JSON ni cambiar el resultado esperado.'),
 ('3. Revisar causa y parche','Comparar las rutas originales y actuales. Antes de explicar una corrección, identificar el requisito, la evidencia de HTTP y persistencia, la condición del código y el archivo cambiado. La versión anterior queda conservada para comparar.'),
 ('4. Ejecutar después','Ejecutar: .\\03_LABORATORIO_FINAL\\Ejecutar-Pruebas.ps1 -Fase despues. Mantener los mismos 20 casos. Abrir resultados/despues.json y comparar. Si se repite una fase, conservar previamente una copia de su JSON fechado; el script reemplaza el último registro de esa fase.'),
 ('5. Ver la app y el reporte','Ejecutar Abrir-App.ps1 y abrir http://127.0.0.1:3344/login. Cuenta QA: qa_final_admin; la contraseña sintética está indicada en el script de arranque. Abrir Recorrido_Pruebas.html para los resultados comparados. El reporte es estático: tras nuevas corridas, regenerarlo con .qa_tools/crear_recorrido_final.py.'),
 ('6. Explicar resultados abiertos','No decir “no se puede arreglar”. Indicar si no se abordó o si el parche es parcial y qué falta para cerrar el requisito. API disponible no significa funcionalidad correcta; 500 no garantiza rollback. En auditoría, IP, inmutabilidad y atomicidad son propiedades diferentes.'),
 ('7. Capturar y entregar','Guardar las capturas indicadas con nombre, caso, fase y fecha. Cada imagen debe permitir leer requisito, esperado, observado y evidencia posterior. No mostrar tokens, claves ni pacientes reales. Entregar informe, diapositivas, evidencias y video personal conforme a AVA. El video debe grabarlo Antonella; no se incluye una participación simulada.'),
]
md=['# Recorrido real de pruebas · Antonella Cuvertino','## Resultados medidos',f'Antes: {before["summary"]}. Después: {after["summary"]}.']
for title,body in steps:md.extend(['## '+title,body])
md.append('## Capturas necesarias')
for name,title,body in capture_plan:md.extend(['### '+name+' · '+title,body])
md.append('## Cómo explicar cada caso')
for cid,(state,cause) in CAUSES.items():md.append(f'- {cid}: {state}. {cause}')
(lab/'00_EMPIEZA_AQUI.md').write_text('\n\n'.join(md),encoding='utf-8')
for name,font in [('Arial','arial.ttf'),('ArialBold','arialbd.ttf')]:pdfmetrics.registerFont(TTFont(name,'C:/Windows/Fonts/'+font))
body=ParagraphStyle('body',fontName='Arial',fontSize=11,leading=16.5,spaceAfter=10)
head=ParagraphStyle('head',fontName='ArialBold',fontSize=12,leading=18,spaceBefore=10,spaceAfter=9,keepWithNext=True,textColor=colors.HexColor('#102A43'))
def p(t,style=body):return Paragraph(escape(t),style)
story=[p('Cuidarte+ · Recorrido de pruebas y capturas',head),p('Antonella Cuvertino · Duoc UC · Ingeniería Informática, Desarrollo de Software · ISY1102 · 02V'),p(f'Antes: {before["summary"]}. Después: {after["summary"]}.')]
ui_path=lab/'resultados/recorrido_ui.json'
if ui_path.exists():
 ui=json.loads(ui_path.read_text(encoding='utf-8'))
 story.extend([p('Recorrido UI: campaña adicional',head),p('El navegador verificó el rechazo de contraseña incorrecta y el ingreso a home cuando constan como PASS en recorrido_ui.json. UI-03 registra dos avisos de error en lugar de uno: el interceptor de lib/api.jsx y el catch de Login.jsx notifican el mismo fallo. Hallazgo leve, abierto; propuesta: centralizar mensajes y repetir. No se suma a los 20 casos API.')])
for title,txt in steps:story.extend([p(title,head),p(txt)])
story.append(PageBreak());story.append(p('Capturas: qué debe demostrar cada una',head))
for name,title,txt in capture_plan:story.extend([p(name+' · '+title,head),p(txt)])
story.append(PageBreak());story.append(p('Errores, causas y estado del intento',head))
for cid,(state,cause) in CAUSES.items():story.extend([p(cid+' · '+state,head),p(cause)])
captures=[p for p in (lab/'capturas').glob('*.png') if not p.name.startswith('UI_')]
if captures:
 story.append(PageBreak());story.append(p('Capturas obtenidas automáticamente',head));story.append(p('Capturas UI: navegador real. Capturas del reporte: visualización de JSON de la campaña, identificadas como tales. La imagen de diff de VS Code indicada en el plan debe capturarse personalmente si no figura aquí.'))
 for f in sorted(captures):
  from PIL import Image as PILImage
  with PILImage.open(f) as img:w,h=img.size
  width=min(509,w);height=width*h/w
  if height>610:height=610;width=height*w/h
  story.extend([p(f.name,head),Image(str(f),width=width,height=height),PageBreak()])
def foot(c,d):c.setFont('Arial',8);c.drawString(43,23,'Cuidarte+ · Campaña QA antes/después · Antonella Cuvertino');c.drawRightString(A4[0]-43,23,str(d.page))
SimpleDocTemplate(str(out/'04_Recorrido_Pruebas_y_Capturas.pdf'),pagesize=A4,leftMargin=43,rightMargin=43,topMargin=43,bottomMargin=43,author='Antonella Cuvertino').build(story,onFirstPage=foot,onLaterPages=foot)
diff=[]
for rel in ['src/routes/users.js','src/validations/users.js','sql/init.sql']:
 old=(lab/'version_antes/BACKEND'/rel).read_text(encoding='utf-8').splitlines(True);new=(ROOT/'BACKEND'/rel).read_text(encoding='utf-8').splitlines(True)
 diff.extend(difflib.unified_diff(old,new,fromfile='antes/'+rel,tofile='despues/'+rel))
newfile=ROOT/'BACKEND/src/middleware/requireAdmin.js'
diff.extend(difflib.unified_diff([],newfile.read_text(encoding='utf-8').splitlines(True),fromfile='/dev/null',tofile='despues/src/middleware/requireAdmin.js'))
(lab/'resultados/cambios_aplicados.diff').write_text(''.join(diff),encoding='utf-8')
(lab/'capturas/LEEME_CAPTURAS.txt').write_text('\n'.join(f'{n}: {t}. {x}' for n,t,x in capture_plan),encoding='utf-8')
print('Recorrido HTML, guía de capturas, diff y PDF creados.')
