﻿$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
Invoke-RestMethod 'http://127.0.0.1:4447/' -TimeoutSec 5 | Out-Null
$vite=Join-Path $root 'FRONTEND\node_modules\vite\bin\vite.js'
if(-not(Test-Path -LiteralPath $vite)){throw 'Faltan dependencias frontend; usa el respaldo de node_modules de la demo anterior.'}
$pidFile=Join-Path $PSScriptRoot '.runtime\frontend.json'
if(Test-Path -LiteralPath $pidFile){
 $old=Get-Content -LiteralPath $pidFile -Raw | ConvertFrom-Json
 $p=Get-Process -Id $old.id -ErrorAction SilentlyContinue
 if($p -and $p.StartTime.ToUniversalTime().ToString('o') -eq $old.started){Start-Process 'http://127.0.0.1:3344/login';exit 0}
}
$probe=New-Object System.Net.Sockets.TcpClient
try{$probe.Connect('127.0.0.1',3344);throw 'Puerto 3344 ocupado; no se inicia otra instancia.'}catch [System.Net.Sockets.SocketException]{}finally{$probe.Dispose()}
$env:VITE_API_URL='http://127.0.0.1:4447';$env:NODE_OPTIONS='--max-old-space-size=384';$env:GOMAXPROCS='2'
$p=Start-Process -FilePath (Get-Command node.exe).Source -ArgumentList @(('"'+$vite+'"'),'--host','127.0.0.1','--port','3344','--strictPort') -WorkingDirectory (Join-Path $root 'FRONTEND') -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot '.runtime\frontend.stdout.log') -RedirectStandardError (Join-Path $PSScriptRoot '.runtime\frontend.stderr.log') -PassThru
@{id=$p.Id;started=$p.StartTime.ToUniversalTime().ToString('o');script=$vite}|ConvertTo-Json|Set-Content -LiteralPath $pidFile -Encoding UTF8
Write-Host 'App de laboratorio: http://127.0.0.1:3344/login'
Write-Host 'Usuario: qa_final_admin. Clave de datos ficticios: DemoCuidarte2026!'
for($i=0;$i -lt 30;$i++) {
 try{Invoke-WebRequest 'http://127.0.0.1:3344/login' -UseBasicParsing -TimeoutSec 2 | Out-Null; Start-Process 'http://127.0.0.1:3344/login'; break}catch{Start-Sleep -Milliseconds 500}
}
