# Guion de defensa y video

10 minutos + 5 minutos de preguntas.


## 1. Cuidarte+ | decisión de liberación
Antonella · 00:00–01:00

- Antonella Cuvertino · Duoc UC · Ingeniería Informática, Desarrollo de Software.

- 20 casos en versión original y versión con cambios.

- Pruebas → causa → corrección → retest → pendientes.

- Producción BLOQUEADA: mejorar no equivale a cerrar todas las reservas.

Visual: Tarjeta de decisión con bloqueo de producción y responsable individual.

Buenos días. Soy Antonella Cuvertino. Presento una campaña real de pruebas de Cuidarte+, comparando la versión original y una versión con correcciones. El objetivo no es convertir todos los tests en verde, sino validar requisitos, explicar fallos, intentar cambios justificados y comprobar sus efectos. Incorporé el feedback del profesor: señalaré requisito, evidencia y prioridad. Diseñé veinte casos y la automatización asistida los ejecutó en dos bases QA con datos sintéticos. Mostraré resultados que mejoran y otros que permanecen abiertos. Los informes y capturas distinguen evidencia medida de controles todavía propuestos. El dictamen académico mantiene producción bloqueada hasta resolver y verificar las reservas.


## 2. Arquitectura y alcance de la evidencia
Antonella · 01:00–02:00

- Original: API 4446 → cuidarte_final_antes.

- Con cambios: API 4447 → cuidarte_final_despues.

- PostgreSQL QA: 15444; app de práctica: 3344.

- Snapshot y hashes; ningún paciente real ni prueba destructiva en producción.

Visual: Diagrama de cuatro nodos con puertos de host y contenedor diferenciados.

Para comparar preparé dos bases independientes en el mismo PostgreSQL de laboratorio, publicado en el puerto quince mil cuatrocientos cuarenta y cuatro. La API original corre en cuatro cuatro cuatro seis y la corregida en cuatro cuatro cuatro siete. Ambas reciben los mismos roles y datos sintéticos. La interfaz de práctica usa tres tres cuatro cuatro y apunta a la corregida. El snapshot anterior se conserva, así que no confundimos resultados antes y después ni probamos sobre historias clínicas reales. La primera corrida quedó bloqueada por timeout durante presión de memoria; la conservé como incidencia de entorno y repetí sin alterar el criterio. Los JSON identifican fecha, entorno y código.


## 3. Pipeline DevSecOps: diseño objetivo
Antonella · 02:00–03:00

- Push / pull request → instalación reproducible y revisión de secretos.

- Jest + SCA + SonarQube → entorno Docker efímero.

- Cypress + ZAP autenticado → JMeter programado / manual.

- Evidencias por commit → decisión humana → despliegue bloqueado.

Visual: Flujo por etapas con gate que conecta permisos, datos sintéticos y trazabilidad.

Este diagrama muestra el pipeline objetivo, no una ejecución de GitHub Actions que no podamos acreditar. Un push o pull request dispara instalación reproducible, revisión de secretos, pruebas Jest, análisis de dependencias y SonarQube. En un entorno efímero se ejecutan Cypress y ZAP con identidades de prueba. La carga de doscientos usuarios se reserva para ejecución programada o manual en infraestructura dedicada, para no bloquear cada commit ni saturar el equipo. Cada resultado debe vincularse al commit y conservarse sin datos clínicos ni tokens. Un runner de GitHub no accede al localhost de mi computador; requiere su propio SonarQube o conectividad controlada. La decisión final de liberar exige evidencias y aprobación.


## 4. Automatización: función y estado real
Antonella · 03:00–04:00

- Ejecutado: 20 pruebas HTTP/integración con Node + pg, por fase.

- Se verifica HTTP, cuerpo, filas, roles e IP; no solo disponibilidad.

- Playwright: UI y capturas si consta en su evidencia específica.

- Jest, Cypress, ZAP, JMeter y Actions: no atribuir corridas inexistentes.

Visual: Matriz de seis herramientas: función, evidencia esperada y estado.

El recorrido parte por disponibilidad y autenticación; después prueba autorización, persistencia y auditoría. Cada aserción conserva el resultado esperado y el observado. Un doscientos no garantiza seguridad, y un quinientos no asegura que no hubo cambios en la base. Node fetch ejecuta las solicitudes y pg permite comprobar filas y roles. Las cuentas y tokens son de QA; los secretos no se imprimen. Hay casos de regresión para verificar que el administrador sigue operando después de agregar controles. El navegador automatizado y sus capturas, si constan en el registro, aportan evidencia de UI; no sustituyen las aserciones de API. No denomino Jest, Cypress o JMeter a herramientas que no ejecuté.


## 5. Resultados reales: antes y después
Antonella · 04:00–05:00

- ANTES: 8 PASS / 12 FAIL.

- DESPUÉS: 15 PASS / 5 FAIL.

- 7 casos cambian FAIL → PASS; 5 siguen fallando.

- Mismo oráculo; las cifras no incluyen el SAST histórico ni el intento bloqueado.

Visual: Indicadores API y SAST con nota sobre gate y discrepancia documental.

Antes de los cambios, las veinte pruebas dieron 8 aprobadas y 12 fallidas. Después, dieron 15 aprobadas y 5 fallidas. 7 casos pasan de FAIL a PASS manteniendo los mismos criterios. No se cambiaron los tests para mejorar el número. La evidencia está en dos JSON, con fecha y hashes del código. Los controles que ya funcionaban, como login e aislamiento entre pacientes, permiten observar posibles regresiones. El escalamiento de roles ahora sí se reprodujo con un payload válido: la prueba antigua se detenía en validación y no permitía esa conclusión. Los resultados del SonarQube de octubre siguen como antecedente; no son un nuevo escaneo del parche.


## 6. Permisos: defecto, parche y regresión
Antonella · 05:00–06:00

- FIN-08: borrado anónimo 200 y fila eliminada → exigir 401 e intacta.

- FIN-11: médico obtiene admin → exigir 403 y rol conservado.

- FIN-20: paciente crea admin → exigir 403 y sin nueva cuenta.

- FIN-10: admin legítimo sigue operando y registra su ID numérico.

Visual: Matriz estado / prioridad / corrección / criterio de cierre.

El requisito NFR de control de acceso se valida con acciones concretas. En FIN ocho, el anónimo eliminó una cuenta y recibió doscientos. El parche agrega autenticación y rol administrador antes de mutar; el retest debe responder cuatrocientos uno y conservar la fila. FIN once demostró que el médico podía asignarse admin al enviar un perfil válido. Se restringió la edición de roles a administradores y se verificó el rol posterior. FIN veinte detectó otra ruta: un paciente podía crear una cuenta admin. Se protegió también el alta. FIN diez verifica la operación legítima y corrige el actor de auditoría: antes se enviaba un nombre a una columna numérica. La prioridad deriva del daño no autorizado.


## 7. Auditoría: una corrección parcial
Antonella · 06:00–07:00

- FIN-13: columna IP + req.ip; el encabezado falso no se toma como origen.

- FIN-14: el rol QA aún puede modificar eventos → FAIL.

- FIN-15: si falla auditoría, el cambio de rol permanece → FAIL.

- Próximo cambio: mínimo privilegio y transacción completa en PUT.

Visual: Cliente → proxy confiable → Express → transacción → auditoría protegida.

La auditoría muestra por qué no debo declarar resuelto todo un servicio por una sola captura verde. Agregué ip_origen y el evento de actualización médica usa req.ip. El caso trece comprueba que un encabezado de origen falso no se adopta cuando no hay proxy confiable configurado. Sin embargo, el caso catorce demuestra que el rol usado en QA todavía puede editar auditoria. El caso quince provoca un rechazo controlado del evento, solo en el laboratorio: el PUT devuelve quinientos, pero el rol ya cambió porque no hay una transacción completa. Por eso la corrección es parcial. La transacción agregada al borrado no resuelve automáticamente el cambio de rol. Faltan permisos mínimos y atomicidad en esa ruta.


## 8. Fallos abiertos: causa y próximo paso
Antonella · 07:00–08:00

- FIN-16: DELETE físico; la fila clínica desaparece.

- FIN-17: registro guarda clave igual a entrada.

- FIN-18: demora explícita de 5.000 ms; no la elimina un índice.

- No abordados en esta iteración; requieren cambios coherentes y retests.

Visual: Barra comparativa objetivo 300 ms / demora artificial 5.000 / p95 8.698.

Los fallos abiertos tienen causas concretas y no significan que sea imposible corregirlos. El borrado de exámenes usa DELETE físico: el estado posterior pierde la fila. Una baja lógica requiere migración y revisar listados, descargas y retención; cambiar una sola línea no asegura consistencia. El registro persiste la contraseña sin hash y el login la compara directamente. Corregirlo exige actualizar altas, cambios, verificación y cuentas existentes, no modificar únicamente el fixture. El rendimiento sigue fuera del requisito porque la ruta incorpora cinco segundos de demora intencional. No se probaron índices como solución a esa espera. Esos cambios quedaron propuestos para otra iteración, con sus propios criterios de cierre; no se maquillaron los resultados.


## 9. Normativa: controles verificables
Antonella · 08:00–09:00

- Ley 19.628: régimen aplicable; confidencialidad de información de salud.

- Ley 21.719: preparar transición; vigencia general 01 dic 2026 [L2].

- Ley 21.663: verificar sujeto obligado; incidente significativo ≠ todo defecto.

- ISO/IEC 25010:2011 + WCAG 2.1 AA: objetivos con evidencia pendiente.

Visual: Matriz norma → control → evidencia y línea temporal de transición.

Al corte de preparación, la Ley diecinueve mil seiscientos veintiocho es el régimen aplicable. La Ley veintiún mil setecientos diecinueve tiene entrada general prevista para el primero de diciembre de dos mil veintiséis según el texto oficial consultado; planificamos la transición sin presentarla como vigente hoy. Para la Ley de Ciberseguridad debemos verificar el encuadre de CreaLab y del prestador de salud. La falta de una IP no determina automáticamente una infracción ni una multa. Los incidentes significativos activan deberes de reporte para sujetos obligados; no se reporta cada defecto como incidente. ISO e indicadores de accesibilidad orientan pruebas, pero no permiten declarar conformidad completa sin evaluar el alcance y todos los criterios aplicables.


## 10. Reservas, mantenimiento y cierre
Antonella · 09:00–10:00

- Mejoras verificadas por caso, no certificación completa.

- Reservas abiertas: auditoría, baja lógica, credenciales y rendimiento.

- Cada corrección futura debe repetir caso afectado y regresión.

- Dictamen académico con reservas; producción sigue BLOQUEADA.

Visual: Gate cerrado y hoja de ruta: corregir → retestar → revisar → autorizar.

Concluyo que hubo mejoras verificables en permisos y parte de la auditoría, pero siguen existiendo reservas demostradas. El reporte no reduce la evaluación a listar herramientas ni afirma que todos los errores se arreglaron. Para cada caso puedo mostrar requisito, resultado inicial, causa, archivo cambiado, retest y estado final. Las correcciones pendientes necesitan una iteración coherente: privacidad de credenciales, conservación clínica, auditoría protegida y transaccional, y rendimiento sin demora artificial. El plan de mantenimiento exige regresión por cambio y evidencias por versión. Mantengo certificado con reservas como denominación académica solicitada y bloqueo de producción. La mejora medida no equivale a certificación legal ni autorización de uso clínico.


## Pregunta 1: ¿Por qué siguen quedando errores si ya hicieron correcciones?

Se aplicaron cambios acotados y se mantuvieron los mismos oráculos. 7 casos pasaron de FAIL a PASS y 5 permanecen FAIL. No se afirma que lo no abordado sea imposible de corregir. El parche de IP no resuelve permisos de auditoría ni atomicidad; hash, baja lógica y rendimiento requieren otra intervención coherente. Cada pendiente tiene causa y propuesta de retest. Producción permanece bloqueada.

Apoyo: JSON antes/después y matriz FIN-01 a FIN-20.


## Pregunta 2: ¿Dónde está exactamente la SQLi de la línea 42 y por qué no la detectó SonarQube?

No podemos afirmar ese hallazgo: BACKEND/src/controllers/examenes.controller.js no existe en el árbol revisado. En BACKEND/src/routes/examenes.js se observan parámetros $1/$2 y campos dinámicos limitados por una lista permitida. node-postgres separa datos del SQL; una prepared statement con nombre no es requisito para que esa parametrización sea segura. Los identificadores dinámicos necesitan allowlist. Debemos identificar versión, entrada y consulta insegura antes de atribuir SQLi. Cero vulnerabilidades SAST detectadas no elimina puntos ciegos ni sustituye pruebas manuales y DAST.

Apoyo: T1, examen de rutas; no hay prueba SQLi ejecutada.


## Pregunta 3: ¿Cómo saben que el médico escaló si el test anterior devolvía 400?

La campaña nueva corrigió la precondición del test: envió nombre_usuario válido junto con rol_id. FIN-11 llegó a la autorización, respondió 200 en la versión original y la consulta a usuario_roles mostró admin. El retest del mismo payload verifica 403 y medico. No se alteró el resultado antiguo ni se lo presenta retroactivamente como exitoso. FIN-06 devuelve 404 al paciente ajeno y no expone diagnosis; es un control distinto del escalamiento.

Apoyo: FIN-11 y FIN-06; hashes y diff de users.js.


## Pregunta 4: ¿Un trigger puede guardar la IP real e impedir cualquier modificación de la auditoría?

No por sí solo. La base ve la conexión de Express, no la IP HTTP del paciente. Express valida el origen según proxies confiables y pasa actor, request_id e IP a una transacción en una sola conexión; si se usa un trigger, este lee ese contexto transaccional. No se confía ciegamente en X-Forwarded-For ni en inet_client_addr como IP final. Se revocan UPDATE/DELETE al rol de aplicación, se limita quién puede insertar y se agrega copia externa con integridad y retención. Un superusuario de la base sigue siendo un límite de confianza: no prometemos inmutabilidad absoluta.

Apoyo: T2, init.sql:87–93. Propuesta pendiente de implementación.


## Pregunta 5: ¿Qué ley está vigente y debemos reportar cada error a la ANCI?

Al 16 de noviembre de 2026 distinguimos la Ley 19.628 aplicable y la transición de la Ley 21.719, cuya vigencia general figura el 1 de diciembre de 2026 en la fuente oficial consultada. En ciberseguridad debemos determinar si la organización es sujeto obligado; un centro de salud y un proveedor de software no se califican automáticamente de la misma forma. No todo defecto es un incidente significativo. Para sujetos obligados, ante uno de esos incidentes corresponde la alerta temprana dentro de tres horas desde su conocimiento, y las actualizaciones aplicables. La omisión de IP no genera por sí sola una multa automática ni un reporte.

Apoyo: L1–L4. Revalidar vigencia si cambia la fecha de defensa.


## Pregunta 6: ¿Por qué JMeter 200 usuarios e índices no bastan para demostrar rendimiento?

Porque todavía no existe un JTL ni una ejecución JMeter acreditada. El lote Node de 200 solicitudes mide una ráfaga breve: p95 8.698 ms y cero errores. Usuarios virtuales requieren sesiones, mezcla de operaciones, rampa, tiempo de espera y meseta. El delay de 5.000 ms establece una demora base que no desaparece con índices. Después de retirarlo, revisaremos EXPLAIN ANALYZE en QA, volumen, CPU, locks y espera del pool; ya existe índice por paciente. El objetivo histórico es menor de 300 ms; cualquier umbral de 450 ms debe aprobarse explícitamente.

Apoyo: carga_200_real.json, delayMiddleware, DEF-004.


## Pregunta 7: ¿Cómo llega GitHub Actions a SonarQube en localhost y qué ocurre si falla un escáner?

localhost del runner no es mi computador. Proponemos levantar SonarQube y la app en la red efímera del runner, o usar un servicio alcanzable mediante conectividad autorizada. Un runner propio requiere aislamiento y no debe ejecutar código de forks no confiables con secretos. Un error de conexión es ERROR/BLOCKED, nunca PASS. El gate combina exit codes, calidad de datos y reglas explícitas: cero fallos críticos de autorización, hotspots revisados y cobertura del código nuevo acordada. Los tokens se guardan como secretos y el despliegue permanece bloqueado hasta completar evidencia.

Apoyo: T5; quality_gate.json tiene conditions vacío. Diseño no desplegado.


## Pregunta 8: ¿La minimización obliga a borrar exámenes y unas pruebas visuales bastan para WCAG AA?

La minimización exige justificar finalidad, campos, permisos y retención; no equivale a borrar indiscriminadamente información clínica. La conservación y los derechos de titulares deben conciliarse con obligaciones sectoriales aplicables, que deben revisarse por separado. Soft delete conserva la fila y reduce pérdida accidental, pero no sustituye una política de supresión ni backups. WCAG 2.1 AA requiere todos los criterios A y AA del alcance: teclado, foco, contraste, etiquetas y errores, entre otros. Automatización parcial y tamaño de letra no bastan; faltan evaluación manual, tecnologías de apoyo y evidencias por criterio.

Apoyo: L1–L2, T4; CP-API-007. No se declara conformidad WCAG completa.

La entrega audiovisual debe mostrar participación real de Antonella Cuvertino. Este paquete no contiene un video ni simula su voz o participación. Grabar con las 10 láminas y el mismo reparto de un minuto por lámina; si el docente fija otra duración para el video, ajustar ese requisito específico. No hay duración de video independiente confirmada en el mensaje recibido.

Preparación: abrir 02_Presentacion_EP6.pdf o el PPTX editable, probar micrófono y compartir una sola ventana. Usar MP4 con pantalla legible (preferentemente 1920×1080) y audio claro. Es una recomendación técnica, no una exigencia adicional de la pauta. No mostrar claves de SonarQube, .env, tokens ni información de pacientes reales.

Storyboard individual: 00:00–01:00 Antonella se presenta y explica la decisión; 01:00–02:00 explica arquitectura; continúa con un minuto por lámina hasta 10:00. Mostrar rostro o identificación según la modalidad de grabación elegida y explicar personalmente el contenido técnico.

La exposición de 10 minutos ya ocupa todo el tiempo. La demo en vivo no se añade sin recortar: si la eligen, reemplazar 30–40 segundos de la lámina 5 por la ejecución preparada de Ejecutar-Pruebas.ps1 y explicar el FAIL de borrado. No ejecutar carga, escaneos ni arranques pesados durante la defensa. Ante fallo de entorno, volver a JSON/PDF identificado como evidencia histórica, sin afirmar que se ejecutó en ese momento.

Ensayo de preguntas (5 minutos): practicar respuestas de 30–40 segundos a cuatro o cinco preguntas elegidas del banco. Antonella debe poder responder preguntas sobre las 10 láminas. Cuando falte evidencia, responder: no está acreditado; este es el control propuesto y este es el artefacto que falta.

Antes de subir: revisar nombre, carrera y fecha; reproducir todo el MP4 para verificar audio y participación; comprobar que los PDF y PPTX coinciden; confirmar en AVA el apartado EP6 indicado por el docente y las restricciones de tamaño/formato. Entregar el informe, las diapositivas utilizadas y el video. El ZIP es soporte adicional si el docente lo admite, no reemplaza esos tres elementos.